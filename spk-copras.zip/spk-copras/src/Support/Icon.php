<?php

namespace Spk\Support;

use Lucide\IconManager;

final class Icon
{
    private static ?IconManager $manager = null;

    private static function manager(): IconManager
    {
        return self::$manager ??= new IconManager();
    }

    /**
     * Render ikon Lucide sebagai string SVG.
     * Contoh: Icon::render('leaf', 20, 'icon-nav')
     */
    public static function render(string $name, int $size = 20, ?string $class = null): string
    {
        $icon = self::manager()->getIcon($name)->setSize($size);

        if ($class !== null) {
            $icon->addCssClass($class);
        }

        return $icon->render();
    }
}
