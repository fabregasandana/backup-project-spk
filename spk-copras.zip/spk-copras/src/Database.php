<?php

namespace Spk;

use PDO;
use PDOException;
use RuntimeException;
use Spk\Support\Config;

final class Database
{
    private static ?PDO $instance = null;

    public static function connection(): PDO
    {
        return self::$instance ??= self::make();
    }

    private static function make(): PDO
    {
        $db = Config::get('database');

        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $db['host'],
            $db['port'],
            $db['name'],
            $db['charset']
        );

        try {
            return new PDO($dsn, $db['user'], $db['pass'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            throw new RuntimeException(
                'Gagal terhubung ke database. Pastikan MySQL aktif dan database "spk_tps" sudah dibuat. '
                . $e->getMessage()
            );
        }
    }
}
