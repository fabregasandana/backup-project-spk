<?php

namespace Spk\Controller;

use Dompdf\Dompdf;
use Spk\Copras;
use Spk\Repository\AlternatifRepository;
use Spk\Repository\KriteriaRepository;
use Spk\Repository\PenilaianRepository;

use function Spk\Support\capture;

final class LaporanController extends Controller
{
    private array $kriteria;
    private array $alternatif;
    private array $matriks;
    private ?array $hasil;

    public function __construct()
    {
        parent::__construct();

        $this->kriteria = (new KriteriaRepository($this->db))->all();
        $this->alternatif = (new AlternatifRepository($this->db))->all();
        $this->matriks = (new PenilaianRepository($this->db))->matriks();

        $this->hasil = ($this->kriteria !== [] && $this->alternatif !== [])
            ? Copras::hitung($this->kriteria, $this->alternatif, $this->matriks)
            : null;
    }

    public function index(): void
    {
        echo $this->render('index', [
            'print' => isset($_GET['print']),
        ]);
    }

    public function excel(): void
    {
        $nama = 'laporan-spk-tps-' . date('Ymd') . '.xls';

        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $nama . '"');
        header('Pragma: no-cache');

        echo $this->render('excel');
    }

    public function pdf(): void
    {
        $dompdf = new Dompdf();
        $dompdf->loadHtml($this->render('pdf'));
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        $dompdf->stream('laporan-spk-tps-' . date('Ymd') . '.pdf', ['Attachment' => true]);
    }

    private function render(string $template, array $extra = []): string
    {
        $body = capture(APP_ROOT . '/views/laporan/_body.php', [
            'kriteria'   => $this->kriteria,
            'alternatif' => $this->alternatif,
            'matriks'    => $this->matriks,
            'hasil'      => $this->hasil,
        ]);

        return capture(APP_ROOT . "/views/laporan/{$template}.php", array_merge($extra, [
            'body' => $body,
        ]));
    }
}
