<?php

namespace Spk\Controller;

use Spk\Copras;
use Spk\Repository\AlternatifRepository;
use Spk\Repository\KriteriaRepository;
use Spk\Repository\PenilaianRepository;

use function Spk\Support\view;

final class HasilController extends Controller
{
    public function index(): void
    {
        $kriteria = (new KriteriaRepository($this->db))->all();
        $alternatif = (new AlternatifRepository($this->db))->all();
        $matriks = (new PenilaianRepository($this->db))->matriks();

        $hasil = ($kriteria !== [] && $alternatif !== [])
            ? Copras::hitung($kriteria, $alternatif, $matriks)
            : null;

        view('hasil/index', [
            'title'      => 'Hasil Perhitungan COPRAS',
            'active'     => 'hasil',
            'kriteria'   => $kriteria,
            'alternatif' => $alternatif,
            'matriks'    => $matriks,
            'hasil'      => $hasil,
        ]);
    }
}
