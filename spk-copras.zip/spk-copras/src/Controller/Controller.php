<?php

namespace Spk\Controller;

use PDO;
use Spk\Database;

abstract class Controller
{
    protected PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }
}
