<?php

namespace Spk\Controller;

use Spk\Repository\KriteriaRepository;

use function Spk\Support\json;
use function Spk\Support\view;

final class KriteriaController extends Controller
{
    private KriteriaRepository $repo;

    public function __construct()
    {
        parent::__construct();
        $this->repo = new KriteriaRepository($this->db);
    }

    public function index(): void
    {
        view('kriteria/index', [
            'title'    => 'Data Kriteria',
            'active'   => 'kriteria',
            'kriteria' => $this->repo->all(),
        ]);
    }

    public function store(): void
    {
        [$kode, $nama, $atribut, $bobot, $error] = $this->validasi();

        if ($error !== null) {
            json(['success' => false, 'message' => $error], 422);
        }
        if ($this->repo->kodeTerpakai($kode)) {
            json(['success' => false, 'message' => "Kode {$kode} sudah dipakai."], 422);
        }

        $this->repo->create($kode, $nama, $atribut, $bobot);
        json(['success' => true, 'message' => 'Kriteria berhasil ditambahkan.']);
    }

    public function update(array $params): void
    {
        $id = (int) $params['id'];
        if ($this->repo->find($id) === null) {
            json(['success' => false, 'message' => 'Data tidak ditemukan.'], 404);
        }

        [$kode, $nama, $atribut, $bobot, $error] = $this->validasi();

        if ($error !== null) {
            json(['success' => false, 'message' => $error], 422);
        }
        if ($this->repo->kodeTerpakai($kode, $id)) {
            json(['success' => false, 'message' => "Kode {$kode} sudah dipakai."], 422);
        }

        $this->repo->update($id, $kode, $nama, $atribut, $bobot);
        json(['success' => true, 'message' => 'Kriteria berhasil diperbarui.']);
    }

    public function destroy(array $params): void
    {
        $this->repo->delete((int) $params['id']);
        json(['success' => true, 'message' => 'Kriteria berhasil dihapus.']);
    }

    private function validasi(): array
    {
        $kode = trim($_POST['kode'] ?? '');
        $nama = trim($_POST['nama'] ?? '');
        $atribut = $_POST['atribut'] ?? '';
        $bobot = filter_var($_POST['bobot'] ?? '', FILTER_VALIDATE_FLOAT);

        if ($kode === '' || $nama === '') {
            return [$kode, $nama, $atribut, 0.0, 'Kode dan nama kriteria wajib diisi.'];
        }
        if (!in_array($atribut, ['benefit', 'cost'], true)) {
            return [$kode, $nama, $atribut, 0.0, 'Atribut kriteria tidak valid.'];
        }
        if ($bobot === false || $bobot < 0) {
            return [$kode, $nama, $atribut, 0.0, 'Bobot harus berupa angka positif.'];
        }

        return [$kode, $nama, $atribut, $bobot, null];
    }
}
