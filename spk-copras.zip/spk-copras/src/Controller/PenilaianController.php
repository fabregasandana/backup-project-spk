<?php

namespace Spk\Controller;

use Spk\Repository\AlternatifRepository;
use Spk\Repository\KriteriaRepository;
use Spk\Repository\PenilaianRepository;

use function Spk\Support\json;
use function Spk\Support\view;

final class PenilaianController extends Controller
{
    private KriteriaRepository $kriteria;
    private AlternatifRepository $alternatif;
    private PenilaianRepository $penilaian;

    public function __construct()
    {
        parent::__construct();
        $this->kriteria = new KriteriaRepository($this->db);
        $this->alternatif = new AlternatifRepository($this->db);
        $this->penilaian = new PenilaianRepository($this->db);
    }

    public function index(): void
    {
        view('penilaian/index', [
            'title'      => 'Matriks Penilaian',
            'active'     => 'penilaian',
            'kriteria'   => $this->kriteria->all(),
            'alternatif' => $this->alternatif->all(),
            'matriks'    => $this->penilaian->matriks(),
        ]);
    }

    public function simpan(): void
    {
        $nilai = $_POST['nilai'] ?? [];

        if (!is_array($nilai) || $nilai === []) {
            json(['success' => false, 'message' => 'Tidak ada data penilaian.'], 422);
        }

        foreach ($nilai as $key => $val) {
            [$alternatifId, $kriteriaId] = array_map('intval', explode('-', $key));
            $angka = filter_var($val, FILTER_VALIDATE_FLOAT);

            if ($angka === false || $angka < 0) {
                json(['success' => false, 'message' => 'Nilai penilaian harus angka positif.'], 422);
            }

            $this->penilaian->simpan($alternatifId, $kriteriaId, $angka);
        }

        json(['success' => true, 'message' => 'Penilaian berhasil disimpan.']);
    }
}
