<?php

namespace Spk\Controller;

use function Spk\Support\e;
use function Spk\Support\flash;
use function Spk\Support\redirect;

final class AuthController extends Controller
{
    public function showLogin(): void
    {
        if (isset($_SESSION['user_id'])) {
            redirect('/');
        }

        $appName = \Spk\Support\Config::get('app')['name'];
        $flashError = flash('error');
        $oldUsername = e($_SESSION['old_username'] ?? '');
        unset($_SESSION['old_username']);

        require APP_ROOT . '/views/auth/login.php';
    }

    public function login(): void
    {
        $username = trim((string) ($_POST['username'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');

        if ($username === '' || $password === '') {
            flash('error', 'Username dan password wajib diisi.');
            $_SESSION['old_username'] = $username;
            redirect('/login');
        }

        $stmt = $this->db->prepare('SELECT * FROM users WHERE username = :username LIMIT 1');
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch();

        if ($user === false || !password_verify($password, $user['password_hash'])) {
            flash('error', 'Username atau password salah.');
            $_SESSION['old_username'] = $username;
            redirect('/login');
        }

        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $user['id'];
        $_SESSION['user_nama'] = $user['nama'];

        flash('success', 'Selamat datang, ' . $user['nama'] . '!');
        redirect('/');
    }

    public function logout(): void
    {
        $_SESSION = [];
        session_destroy();
        redirect('/login');
    }
}
