<?php

namespace Spk\Controller;

use Spk\Repository\AlternatifRepository;

use function Spk\Support\json;
use function Spk\Support\view;

final class AlternatifController extends Controller
{
    private AlternatifRepository $repo;

    public function __construct()
    {
        parent::__construct();
        $this->repo = new AlternatifRepository($this->db);
    }

    public function index(): void
    {
        view('alternatif/index', [
            'title'      => 'Data Alternatif Lokasi',
            'active'     => 'alternatif',
            'alternatif' => $this->repo->all(),
        ]);
    }

    public function store(): void
    {
        [$kode, $nama, $lokasi, $error] = $this->validasi();

        if ($error !== null) {
            json(['success' => false, 'message' => $error], 422);
        }
        if ($this->repo->kodeTerpakai($kode)) {
            json(['success' => false, 'message' => "Kode {$kode} sudah dipakai."], 422);
        }

        $this->repo->create($kode, $nama, $lokasi);
        json(['success' => true, 'message' => 'Alternatif berhasil ditambahkan.']);
    }

    public function update(array $params): void
    {
        $id = (int) $params['id'];
        if ($this->repo->find($id) === null) {
            json(['success' => false, 'message' => 'Data tidak ditemukan.'], 404);
        }

        [$kode, $nama, $lokasi, $error] = $this->validasi();

        if ($error !== null) {
            json(['success' => false, 'message' => $error], 422);
        }
        if ($this->repo->kodeTerpakai($kode, $id)) {
            json(['success' => false, 'message' => "Kode {$kode} sudah dipakai."], 422);
        }

        $this->repo->update($id, $kode, $nama, $lokasi);
        json(['success' => true, 'message' => 'Alternatif berhasil diperbarui.']);
    }

    public function destroy(array $params): void
    {
        $this->repo->delete((int) $params['id']);
        json(['success' => true, 'message' => 'Alternatif berhasil dihapus.']);
    }

    private function validasi(): array
    {
        $kode = trim($_POST['kode'] ?? '');
        $nama = trim($_POST['nama'] ?? '');
        $lokasi = trim($_POST['lokasi'] ?? '') ?: null;

        if ($kode === '' || $nama === '') {
            return [$kode, $nama, $lokasi, 'Kode dan nama alternatif wajib diisi.'];
        }

        return [$kode, $nama, $lokasi, null];
    }
}
