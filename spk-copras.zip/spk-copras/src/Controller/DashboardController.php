<?php

namespace Spk\Controller;

use Spk\Copras;
use Spk\Repository\AlternatifRepository;
use Spk\Repository\KriteriaRepository;
use Spk\Repository\PenilaianRepository;

use function Spk\Support\view;

final class DashboardController extends Controller
{
    public function index(): void
    {
        $kriteriaRepo = new KriteriaRepository($this->db);
        $alternatifRepo = new AlternatifRepository($this->db);
        $penilaianRepo = new PenilaianRepository($this->db);

        $kriteria = $kriteriaRepo->all();
        $alternatif = $alternatifRepo->all();
        $matriks = $penilaianRepo->matriks();

        $rekomendasi = null;
        if ($kriteria !== [] && $alternatif !== []) {
            $hasil = Copras::hitung($kriteria, $alternatif, $matriks);
            $rekomendasi = $hasil['ranking'][0] ?? null;
        }

        view('dashboard/index', [
            'title'       => 'Dashboard',
            'active'      => 'dashboard',
            'jmlKriteria' => count($kriteria),
            'jmlAlternatif' => count($alternatif),
            'totalBobot'  => $kriteriaRepo->totalBobot(),
            'rekomendasi' => $rekomendasi,
        ]);
    }
}
