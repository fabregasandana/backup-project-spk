<?php

namespace Spk;

/**
 * Perhitungan metode COPRAS (Complex Proportional Assessment).
 *
 * Alur: matriks keputusan -> normalisasi -> matriks terbobot ->
 * jumlah S+ (benefit) & S- (cost) -> nilai prioritas Q -> utilitas N -> peringkat.
 */
final class Copras
{
    /**
     * @param array $kriteria   daftar kriteria (id, atribut, bobot)
     * @param array $alternatif daftar alternatif (id, kode, nama)
     * @param array $matriks    peta [alternatifId][kriteriaId] => nilai
     */
    public static function hitung(array $kriteria, array $alternatif, array $matriks): array
    {
        $bobot = self::normalisasiBobot($kriteria);

        $normal = self::normalisasiMatriks($kriteria, $alternatif, $matriks);
        $terbobot = self::matriksTerbobot($kriteria, $alternatif, $normal, $bobot);

        [$sPlus, $sMinus] = self::jumlahkan($kriteria, $alternatif, $terbobot);
        $q = self::prioritas($alternatif, $sPlus, $sMinus);
        $n = self::utilitas($q);

        return [
            'bobot'       => $bobot,
            'normalisasi' => $normal,
            'terbobot'    => $terbobot,
            'sPlus'       => $sPlus,
            'sMinus'      => $sMinus,
            'q'           => $q,
            'n'           => $n,
            'ranking'     => self::peringkat($alternatif, $q, $n),
        ];
    }

    private static function normalisasiBobot(array $kriteria): array
    {
        $total = array_sum(array_map(fn($k) => (float) $k['bobot'], $kriteria));
        if ($total <= 0) {
            return array_column(
                array_map(fn($k) => ['id' => $k['id'], 'w' => 0.0], $kriteria),
                'w',
                'id'
            );
        }

        $hasil = [];
        foreach ($kriteria as $k) {
            $hasil[(int) $k['id']] = (float) $k['bobot'] / $total;
        }
        return $hasil;
    }

    private static function normalisasiMatriks(array $kriteria, array $alternatif, array $matriks): array
    {
        $kolomTotal = [];
        foreach ($kriteria as $k) {
            $kid = (int) $k['id'];
            $kolomTotal[$kid] = 0.0;
            foreach ($alternatif as $a) {
                $kolomTotal[$kid] += (float) ($matriks[(int) $a['id']][$kid] ?? 0);
            }
        }

        $normal = [];
        foreach ($alternatif as $a) {
            $aid = (int) $a['id'];
            foreach ($kriteria as $k) {
                $kid = (int) $k['id'];
                $nilai = (float) ($matriks[$aid][$kid] ?? 0);
                $normal[$aid][$kid] = $kolomTotal[$kid] > 0 ? $nilai / $kolomTotal[$kid] : 0.0;
            }
        }
        return $normal;
    }

    private static function matriksTerbobot(array $kriteria, array $alternatif, array $normal, array $bobot): array
    {
        $terbobot = [];
        foreach ($alternatif as $a) {
            $aid = (int) $a['id'];
            foreach ($kriteria as $k) {
                $kid = (int) $k['id'];
                $terbobot[$aid][$kid] = ($normal[$aid][$kid] ?? 0.0) * ($bobot[$kid] ?? 0.0);
            }
        }
        return $terbobot;
    }

    private static function jumlahkan(array $kriteria, array $alternatif, array $terbobot): array
    {
        $benefit = [];
        $cost = [];
        foreach ($kriteria as $k) {
            if ($k['atribut'] === 'benefit') {
                $benefit[] = (int) $k['id'];
            } else {
                $cost[] = (int) $k['id'];
            }
        }

        $sPlus = $sMinus = [];
        foreach ($alternatif as $a) {
            $aid = (int) $a['id'];
            $sPlus[$aid] = array_sum(array_map(fn($id) => $terbobot[$aid][$id] ?? 0.0, $benefit));
            $sMinus[$aid] = array_sum(array_map(fn($id) => $terbobot[$aid][$id] ?? 0.0, $cost));
        }
        return [$sPlus, $sMinus];
    }

    private static function prioritas(array $alternatif, array $sPlus, array $sMinus): array
    {
        $nilaiMinus = array_values($sMinus);
        $positif = array_filter($nilaiMinus, fn($v) => $v > 0);

        if ($positif === []) {
            return array_map(fn($v) => $v, $sPlus);
        }

        $sMin = min($positif);
        $totalMinus = array_sum($nilaiMinus);
        $sigma = 0.0;
        foreach ($nilaiMinus as $v) {
            if ($v > 0) {
                $sigma += $sMin / $v;
            }
        }

        $q = [];
        foreach ($alternatif as $a) {
            $aid = (int) $a['id'];
            $sm = $sMinus[$aid];
            if ($sm <= 0 || $sigma <= 0) {
                $q[$aid] = $sPlus[$aid];
                continue;
            }
            $q[$aid] = $sPlus[$aid] + ($sMin * $totalMinus) / ($sm * $sigma);
        }
        return $q;
    }

    private static function utilitas(array $q): array
    {
        $maks = $q === [] ? 0.0 : max($q);
        $n = [];
        foreach ($q as $aid => $nilai) {
            $n[$aid] = $maks > 0 ? ($nilai / $maks) * 100 : 0.0;
        }
        return $n;
    }

    private static function peringkat(array $alternatif, array $q, array $n): array
    {
        $baris = [];
        foreach ($alternatif as $a) {
            $aid = (int) $a['id'];
            $baris[] = [
                'id'         => $aid,
                'kode'       => $a['kode'],
                'nama'       => $a['nama'],
                'q'          => $q[$aid] ?? 0.0,
                'n'          => $n[$aid] ?? 0.0,
            ];
        }

        usort($baris, fn($x, $y) => $y['q'] <=> $x['q']);

        foreach ($baris as $i => $row) {
            $baris[$i]['rank'] = $i + 1;
        }
        return $baris;
    }
}
