<?php

namespace Spk\Repository;

use PDO;

class AlternatifRepository
{
    public function __construct(private PDO $db)
    {
    }

    public function all(): array
    {
        return $this->db->query('SELECT * FROM alternatif ORDER BY id ASC')->fetchAll();
    }

    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM alternatif WHERE id = ?');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function create(string $kode, string $nama, ?string $lokasi): int
    {
        $stmt = $this->db->prepare('INSERT INTO alternatif (kode, nama, lokasi) VALUES (?, ?, ?)');
        $stmt->execute([$kode, $nama, $lokasi]);
        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, string $kode, string $nama, ?string $lokasi): void
    {
        $stmt = $this->db->prepare('UPDATE alternatif SET kode = ?, nama = ?, lokasi = ? WHERE id = ?');
        $stmt->execute([$kode, $nama, $lokasi, $id]);
    }

    public function delete(int $id): void
    {
        $this->db->prepare('DELETE FROM alternatif WHERE id = ?')->execute([$id]);
    }

    public function kodeTerpakai(string $kode, ?int $exceptId = null): bool
    {
        $sql = 'SELECT COUNT(*) FROM alternatif WHERE kode = ?';
        $params = [$kode];
        if ($exceptId !== null) {
            $sql .= ' AND id <> ?';
            $params[] = $exceptId;
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return (int) $stmt->fetchColumn() > 0;
    }
}
