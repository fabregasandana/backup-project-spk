<?php

namespace Spk\Repository;

use PDO;

class KriteriaRepository
{
    public function __construct(private PDO $db)
    {
    }

    public function all(): array
    {
        return $this->db->query('SELECT * FROM kriteria ORDER BY id ASC')->fetchAll();
    }

    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM kriteria WHERE id = ?');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function create(string $kode, string $nama, string $atribut, float $bobot): int
    {
        $stmt = $this->db->prepare(
            'INSERT INTO kriteria (kode, nama, atribut, bobot) VALUES (?, ?, ?, ?)'
        );
        $stmt->execute([$kode, $nama, $atribut, $bobot]);
        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, string $kode, string $nama, string $atribut, float $bobot): void
    {
        $stmt = $this->db->prepare(
            'UPDATE kriteria SET kode = ?, nama = ?, atribut = ?, bobot = ? WHERE id = ?'
        );
        $stmt->execute([$kode, $nama, $atribut, $bobot, $id]);
    }

    public function delete(int $id): void
    {
        $this->db->prepare('DELETE FROM kriteria WHERE id = ?')->execute([$id]);
    }

    public function kodeTerpakai(string $kode, ?int $exceptId = null): bool
    {
        $sql = 'SELECT COUNT(*) FROM kriteria WHERE kode = ?';
        $params = [$kode];
        if ($exceptId !== null) {
            $sql .= ' AND id <> ?';
            $params[] = $exceptId;
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return (int) $stmt->fetchColumn() > 0;
    }

    public function totalBobot(): float
    {
        return (float) $this->db->query('SELECT COALESCE(SUM(bobot), 0) FROM kriteria')->fetchColumn();
    }
}
