<?php

namespace Spk\Repository;

use PDO;

class PenilaianRepository
{
    public function __construct(private PDO $db)
    {
    }

    /**
     * Ambil semua nilai sebagai peta: [alternatifId][kriteriaId] => nilai.
     */
    public function matriks(): array
    {
        $rows = $this->db->query('SELECT alternatif_id, kriteria_id, nilai FROM penilaian')->fetchAll();

        $matriks = [];
        foreach ($rows as $row) {
            $matriks[(int) $row['alternatif_id']][(int) $row['kriteria_id']] = (float) $row['nilai'];
        }
        return $matriks;
    }

    public function simpan(int $alternatifId, int $kriteriaId, float $nilai): void
    {
        $stmt = $this->db->prepare(
            'INSERT INTO penilaian (alternatif_id, kriteria_id, nilai)
             VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE nilai = VALUES(nilai)'
        );
        $stmt->execute([$alternatifId, $kriteriaId, $nilai]);
    }
}
