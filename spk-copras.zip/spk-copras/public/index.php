<?php

declare(strict_types=1);

require __DIR__ . '/../vendor/autoload.php';

// Sajikan berkas statis apa adanya saat dijalankan via `php -S` (server bawaan PHP).
if (PHP_SAPI === 'cli-server') {
    $requested = __DIR__ . parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if (is_file($requested)) {
        return false;
    }
}

use Spk\Controller\AlternatifController;
use Spk\Controller\AuthController;
use Spk\Controller\DashboardController;
use Spk\Controller\HasilController;
use Spk\Controller\KriteriaController;
use Spk\Controller\LaporanController;
use Spk\Controller\PenilaianController;
use Spk\Router;
use Spk\Support\Config;

define('APP_ROOT', dirname(__DIR__));

Config::load(APP_ROOT . '/config/config.php');

// Basis URL mengikuti lokasi folder proyek (mendukung subfolder XAMPP).
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
define('BASE_URL', $scriptDir === '/' ? '' : rtrim($scriptDir, '/'));

session_start();

$router = new Router();

// ---- Rute autentikasi (bebas login) ----
$router->get('/login', fn() => (new AuthController())->showLogin());
$router->post('/login', fn() => (new AuthController())->login());
$router->get('/logout', fn() => (new AuthController())->logout());

// ---- Middleware: semua rute lain wajib login ----
$basePath = rtrim(BASE_URL, '/');
$uriPath = '/' . trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
$routePath = $basePath !== '' && str_starts_with($uriPath, $basePath)
    ? substr($uriPath, strlen($basePath)) ?: '/'
    : $uriPath;

if (!isset($_SESSION['user_id']) && preg_match('#^/login/?$#', $routePath) !== 1) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

$router->get('/', fn() => (new DashboardController())->index());

$router->get('/kriteria', fn() => (new KriteriaController())->index());
$router->post('/kriteria', fn() => (new KriteriaController())->store());
$router->post('/kriteria/{id}/update', fn($p) => (new KriteriaController())->update($p));
$router->post('/kriteria/{id}/delete', fn($p) => (new KriteriaController())->destroy($p));

$router->get('/alternatif', fn() => (new AlternatifController())->index());
$router->post('/alternatif', fn() => (new AlternatifController())->store());
$router->post('/alternatif/{id}/update', fn($p) => (new AlternatifController())->update($p));
$router->post('/alternatif/{id}/delete', fn($p) => (new AlternatifController())->destroy($p));

$router->get('/penilaian', fn() => (new PenilaianController())->index());
$router->post('/penilaian', fn() => (new PenilaianController())->simpan());

$router->get('/hasil', fn() => (new HasilController())->index());

$router->get('/laporan', fn() => (new LaporanController())->index());
$router->get('/laporan/excel', fn() => (new LaporanController())->excel());
$router->get('/laporan/pdf', fn() => (new LaporanController())->pdf());

$router->dispatch($_SERVER['REQUEST_METHOD'], $_SERVER['REQUEST_URI']);
