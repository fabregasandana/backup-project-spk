(function () {
    'use strict';

    const BASE = window.APP?.base ?? '';

    const toast = (icon, title) =>
        Swal.fire({ toast: true, position: 'top-end', icon, title, showConfirmButton: false, timer: 2200, timerProgressBar: true });

    async function post(url, body) {
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            body: body ?? new FormData(),
        });
        const data = await res.json().catch(() => ({ success: false, message: 'Respons tidak valid.' }));
        return { ok: res.ok, data };
    }

    function serializeForm(form) {
        return new FormData(form);
    }

    /* ---------- Modal ---------- */
    function openModal(id) {
        document.getElementById(id)?.removeAttribute('hidden');
    }
    function closeModal(modal) {
        modal?.setAttribute('hidden', '');
    }

    document.addEventListener('click', (e) => {
        const opener = e.target.closest('[data-open-modal]');
        if (opener) {
            const modal = document.getElementById(opener.dataset.openModal);
            fillForm(modal, opener);
            openModal(opener.dataset.openModal);
            return;
        }

        if (e.target.closest('[data-close-modal]') || e.target.classList.contains('modal')) {
            closeModal(e.target.closest('.modal') || document.querySelector('.modal:not([hidden])'));
        }
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeModal(document.querySelector('.modal:not([hidden])'));
    });

    function fillForm(modal, trigger) {
        if (!modal) return;
        const form = modal.querySelector('form');
        const mode = trigger.dataset.mode;
        const title = modal.querySelector('[data-modal-title]');
        if (title) title.textContent = mode === 'edit' ? 'Ubah Data' : 'Tambah Data';

        form.reset();
        if (mode === 'edit') {
            Object.entries(trigger.dataset).forEach(([key, value]) => {
                const input = form.elements[key];
                if (input) input.value = value;
            });
        } else {
            form.elements.id && (form.elements.id.value = '');
        }
    }

    /* ---------- Submit form (CRUD) ---------- */
    document.addEventListener('submit', async (e) => {
        const form = e.target.closest('form[data-create]');
        if (!form) return;
        e.preventDefault();

        const id = form.elements.id?.value;
        const url = id ? `${form.dataset.update}/${id}/update` : form.dataset.create;
        const submitBtn = form.querySelector('button[type="submit"]');

        submitBtn && (submitBtn.disabled = true);
        const { ok, data } = await post(url, serializeForm(form));
        submitBtn && (submitBtn.disabled = false);

        if (ok && data.success) {
            closeModal(form.closest('.modal'));
            toast('success', data.message);
            setTimeout(() => location.reload(), 700);
        } else {
            Swal.fire({ icon: 'error', title: 'Gagal', text: data.message || 'Terjadi kesalahan.', confirmButtonColor: '#16a34a' });
        }
    });

    /* ---------- Delete ---------- */
    document.addEventListener('click', async (e) => {
        const btn = e.target.closest('[data-delete]');
        if (!btn) return;

        const confirm = await Swal.fire({
            title: 'Hapus data?',
            text: `Data "${btn.dataset.label}" akan dihapus permanen.`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Ya, hapus',
            cancelButtonText: 'Batal',
            confirmButtonColor: '#ef4444',
            cancelButtonColor: '#0b130b',
        });
        if (!confirm.isConfirmed) return;

        const { ok, data } = await post(btn.dataset.delete);
        if (ok && data.success) {
            toast('success', data.message);
            setTimeout(() => location.reload(), 700);
        } else {
            Swal.fire({ icon: 'error', title: 'Gagal', text: data.message || 'Terjadi kesalahan.' });
        }
    });

    /* ---------- Chart utilitas ---------- */
    function renderChart() {
        const node = document.getElementById('data-ranking');
        const canvas = document.getElementById('chartUtilitas');
        if (!node || !canvas || typeof Chart === 'undefined') return;

        const rows = JSON.parse(node.textContent);
        new Chart(canvas, {
            type: 'bar',
            data: {
                labels: rows.map((r) => r.label),
                datasets: [{
                    label: 'Nilai Utilitas (%)',
                    data: rows.map((r) => r.nilai),
                    backgroundColor: '#22c55e',
                    borderColor: '#0b130b',
                    borderWidth: 3,
                    borderRadius: 6,
                }],
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    title: { display: true, text: 'Utilitas Tiap Alternatif', font: { size: 15, weight: '700' }, color: '#0b130b' },
                },
                scales: {
                    x: { beginAtZero: true, max: 100, grid: { color: '#dbe7d5' } },
                    y: { grid: { display: false } },
                },
            },
        });
    }

    document.addEventListener('DOMContentLoaded', () => {
        if (window.APP?.flash) toast('success', window.APP.flash);
        renderChart();
    });
})();
