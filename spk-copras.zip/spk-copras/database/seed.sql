USE spk_tps;

-- Kriteria penilaian lokasi TPS 3R (bobot total 100)
INSERT INTO kriteria (kode, nama, atribut, bobot) VALUES
('C1', 'Aksesibilitas',            'benefit', 20.00),
('C2', 'Jarak dari Permukiman',    'benefit', 15.00),
('C3', 'Luas Lahan',               'benefit', 20.00),
('C4', 'Biaya Pengadaan Lahan',    'cost',    15.00),
('C5', 'Potensi Dampak Sosial',    'cost',    15.00),
('C6', 'Dukungan Masyarakat',      'benefit', 15.00);

-- Alternatif kandidat lokasi (studi kasus Kota Bandung)
INSERT INTO alternatif (kode, nama, lokasi) VALUES
('A1', 'Lahan Babakan Siliwangi', 'Jl. Babakan Siliwangi, Kec. Coblong, Kota Bandung'),
('A2', 'Lahan Babakan Sari',      'Kel. Babakan Sari, Kec. Kiaracondong, Kota Bandung'),
('A3', 'Lahan Nyengseret',        'Kel. Nyengseret, Kec. Astanaanyar, Kota Bandung'),
('A4', 'Lahan Cikadut',           'Kel. Cikadut, Kec. Mandalajati, Kota Bandung'),
('A5', 'Lahan Gedebage',          'Kawasan Gedebage, Kec. Gedebage, Kota Bandung');

-- Matriks penilaian (alternatif x kriteria)
-- C1: skor aksesibilitas (0-100)  C2: jarak ke permukiman (meter)
-- C3: luas lahan (m2)              C4: biaya pengadaan (juta rupiah)
-- C5: skor potensi dampak sosial (0-100, makin kecil makin baik)
-- C6: dukungan masyarakat (%)
INSERT INTO penilaian (alternatif_id, kriteria_id, nilai)
SELECT a.id, k.id, v.nilai
FROM (
    SELECT 'A1' AS ak, 'C1' AS kk, 80   AS nilai UNION ALL
    SELECT 'A1', 'C2', 350  UNION ALL
    SELECT 'A1', 'C3', 1200 UNION ALL
    SELECT 'A1', 'C4', 850  UNION ALL
    SELECT 'A1', 'C5', 55   UNION ALL
    SELECT 'A1', 'C6', 70   UNION ALL
    SELECT 'A2', 'C1', 65   UNION ALL
    SELECT 'A2', 'C2', 600  UNION ALL
    SELECT 'A2', 'C3', 1800 UNION ALL
    SELECT 'A2', 'C4', 600  UNION ALL
    SELECT 'A2', 'C5', 40   UNION ALL
    SELECT 'A2', 'C6', 80   UNION ALL
    SELECT 'A3', 'C1', 90   UNION ALL
    SELECT 'A3', 'C2', 200  UNION ALL
    SELECT 'A3', 'C3', 900  UNION ALL
    SELECT 'A3', 'C4', 1200 UNION ALL
    SELECT 'A3', 'C5', 75   UNION ALL
    SELECT 'A3', 'C6', 55   UNION ALL
    SELECT 'A4', 'C1', 70   UNION ALL
    SELECT 'A4', 'C2', 800  UNION ALL
    SELECT 'A4', 'C3', 2500 UNION ALL
    SELECT 'A4', 'C4', 500  UNION ALL
    SELECT 'A4', 'C5', 30   UNION ALL
    SELECT 'A4', 'C6', 85   UNION ALL
    SELECT 'A5', 'C1', 55   UNION ALL
    SELECT 'A5', 'C2', 950  UNION ALL
    SELECT 'A5', 'C3', 2000 UNION ALL
    SELECT 'A5', 'C4', 450  UNION ALL
    SELECT 'A5', 'C5', 25   UNION ALL
    SELECT 'A5', 'C6', 90
) v
JOIN alternatif a ON a.kode = v.ak
JOIN kriteria   k ON k.kode = v.kk;
