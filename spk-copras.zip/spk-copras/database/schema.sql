CREATE DATABASE IF NOT EXISTS spk_tps
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE spk_tps;

DROP TABLE IF EXISTS penilaian;
DROP TABLE IF EXISTS alternatif;
DROP TABLE IF EXISTS kriteria;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE = InnoDB;

CREATE TABLE kriteria (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(8) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    atribut ENUM('benefit', 'cost') NOT NULL DEFAULT 'benefit',
    bobot DECIMAL(5,2) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE = InnoDB;

CREATE TABLE alternatif (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(8) NOT NULL UNIQUE,
    nama VARCHAR(120) NOT NULL,
    lokasi VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE = InnoDB;

CREATE TABLE penilaian (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    alternatif_id INT UNSIGNED NOT NULL,
    kriteria_id INT UNSIGNED NOT NULL,
    nilai DECIMAL(8,2) NOT NULL DEFAULT 0,
    UNIQUE KEY uniq_pasangan (alternatif_id, kriteria_id),
    CONSTRAINT fk_penilaian_alternatif FOREIGN KEY (alternatif_id)
        REFERENCES alternatif (id) ON DELETE CASCADE,
    CONSTRAINT fk_penilaian_kriteria FOREIGN KEY (kriteria_id)
        REFERENCES kriteria (id) ON DELETE CASCADE
) ENGINE = InnoDB;
