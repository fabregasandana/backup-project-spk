-- Akun default untuk login SPK TPS 3R
-- Username: admin | Password: admin123
USE spk_tps;

INSERT INTO users (username, nama, password_hash)
VALUES ('admin', 'Administrator', '$2y$10$JRpOulv4YogjZ0024M1BuuDTIpBYClmPOtk30jgHQdKONzZ27/e2i');
