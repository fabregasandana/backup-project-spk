<?php

use function Spk\Support\base_url;
use function Spk\Support\e;
use function Spk\Support\flash;
use Spk\Support\Icon;

$appName = \Spk\Support\Config::get('app')['name'];

$menu = [
    'dashboard'  => ['label' => 'Dashboard',  'icon' => 'layout-dashboard', 'url' => '/'],
    'kriteria'   => ['label' => 'Kriteria',   'icon' => 'list-checks',      'url' => '/kriteria'],
    'alternatif' => ['label' => 'Alternatif', 'icon' => 'map-pin',          'url' => '/alternatif'],
    'penilaian'  => ['label' => 'Penilaian',  'icon' => 'table-2',          'url' => '/penilaian'],
    'hasil'      => ['label' => 'Hasil',      'icon' => 'chart-bar',      'url' => '/hasil'],
    'laporan'    => ['label' => 'Laporan',    'icon' => 'printer',        'url' => '/laporan'],
];

$flashSuccess = flash('success');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title ?? 'Dashboard') ?> · <?= e($appName) ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?= e(base_url('assets/css/style.css')) ?>">
</head>
<body>
<div class="shell">
    <aside class="sidebar">
        <div class="brand">
            <span class="brand-mark"><?= Icon::render('recycle', 26) ?></span>
            <span class="brand-text">
                <strong>SPK TPS 3R</strong>
                <small>Metode COPRAS</small>
            </span>
        </div>

        <nav class="nav">
            <?php foreach ($menu as $key => $item): ?>
                <a href="<?= e(base_url($item['url'])) ?>"
                   class="nav-link <?= ($active ?? '') === $key ? 'is-active' : '' ?>">
                    <?= Icon::render($item['icon'], 20) ?>
                    <span><?= e($item['label']) ?></span>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="sidebar-foot">
            <?= Icon::render('info', 16) ?>
            <span>Pemilihan lokasi pengolahan sampah Reduce-Reuse-Recycle</span>
        </div>
    </aside>

    <main class="main">
        <header class="topbar">
            <h1><?= e($title ?? 'Dashboard') ?></h1>
            <div class="head-actions">
                <span class="badge-leaf"><?= Icon::render('leaf', 16) ?> Instansi Pemerintah</span>
                <span class="badge-user"><?= Icon::render('user', 16) ?> <?= e($_SESSION['user_nama'] ?? 'Pengguna') ?></span>
                <a href="<?= e(base_url('/logout')) ?>" class="btn btn-sm btn-ghost" title="Keluar">
                    <?= Icon::render('log-out', 16) ?> Keluar
                </a>
            </div>
        </header>

        <div class="page">
            <?= $content ?>
        </div>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
    window.APP = {
        base: <?= json_encode(base_url()) ?>,
        flash: <?= json_encode($flashSuccess) ?>
    };
</script>
<script src="<?= e(base_url('assets/js/app.js')) ?>"></script>
</body>
</html>
