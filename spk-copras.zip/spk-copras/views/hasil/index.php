<?php

use Spk\Support\Icon;

use function Spk\Support\e;

$fmt = fn($v, $d = 4) => number_format((float) $v, $d, ',', '.');
$altById = [];
foreach ($alternatif as $a) {
    $altById[(int) $a['id']] = $a;
}
?>
<?php if ($hasil === null): ?>
    <div class="panel">
        <div class="panel-body">
            <p class="empty-note">
                <?= Icon::render('inbox', 18) ?>
                Data belum lengkap. Isi kriteria, alternatif, dan penilaian untuk menjalankan perhitungan.
            </p>
        </div>
    </div>
<?php else: ?>

    <div class="winner-banner">
        <div class="winner-icon"><?= Icon::render('trophy', 34) ?></div>
        <div class="winner-text">
            <span>Lokasi paling direkomendasikan</span>
            <strong><?= e($hasil['ranking'][0]['kode']) ?> — <?= e($hasil['ranking'][0]['nama']) ?></strong>
        </div>
        <div class="winner-score"><?= $fmt($hasil['ranking'][0]['n'], 2) ?>%</div>
    </div>

    <!-- Tahap 1: matriks keputusan -->
    <div class="panel">
        <div class="panel-head"><h3><?= Icon::render('grid-3x3', 20) ?> Tahap 1 · Matriks Keputusan</h3></div>
        <div class="panel-body">
            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th class="sticky-col">Alternatif</th>
                            <?php foreach ($kriteria as $k): ?>
                                <th><?= e($k['kode']) ?><div class="th-sub"><?= $fmt($hasil['bobot'][(int) $k['id']], 3) ?></div></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($alternatif as $a): ?>
                            <tr>
                                <td class="sticky-col strong"><?= e($a['kode']) ?></td>
                                <?php foreach ($kriteria as $k): ?>
                                    <td><?= $fmt($matriks[(int) $a['id']][(int) $k['id']] ?? 0, 2) ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <p class="hint"><?= Icon::render('info', 15) ?> Baris kedua header menampilkan bobot ternormalisasi tiap kriteria.</p>
        </div>
    </div>

    <!-- Tahap 2: normalisasi -->
    <div class="panel">
        <div class="panel-head"><h3><?= Icon::render('divide', 20) ?> Tahap 2 · Matriks Ternormalisasi</h3></div>
        <div class="panel-body">
            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th class="sticky-col">Alternatif</th>
                            <?php foreach ($kriteria as $k): ?><th><?= e($k['kode']) ?></th><?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($alternatif as $a): ?>
                            <tr>
                                <td class="sticky-col strong"><?= e($a['kode']) ?></td>
                                <?php foreach ($kriteria as $k): ?>
                                    <td><?= $fmt($hasil['normalisasi'][(int) $a['id']][(int) $k['id']]) ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Tahap 3: terbobot -->
    <div class="panel">
        <div class="panel-head"><h3><?= Icon::render('scale', 20) ?> Tahap 3 · Matriks Terbobot</h3></div>
        <div class="panel-body">
            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th class="sticky-col">Alternatif</th>
                            <?php foreach ($kriteria as $k): ?>
                                <th><?= e($k['kode']) ?><div class="th-sub"><?= $k['atribut'] === 'benefit' ? '+' : '−' ?></div></th>
                            <?php endforeach; ?>
                            <th>S+</th>
                            <th>S−</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($alternatif as $a): ?>
                            <tr>
                                <td class="sticky-col strong"><?= e($a['kode']) ?></td>
                                <?php foreach ($kriteria as $k): ?>
                                    <td><?= $fmt($hasil['terbobot'][(int) $a['id']][(int) $k['id']]) ?></td>
                                <?php endforeach; ?>
                                <td class="cell-plus"><?= $fmt($hasil['sPlus'][(int) $a['id']]) ?></td>
                                <td class="cell-minus"><?= $fmt($hasil['sMinus'][(int) $a['id']]) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Tahap 4: prioritas & utilitas -->
    <div class="panel">
        <div class="panel-head"><h3><?= Icon::render('medal', 20) ?> Tahap 4 · Peringkat Akhir</h3></div>
        <div class="panel-body">
            <div class="result-grid">
                <div class="table-wrap">
                    <table class="data-table ranking-table">
                        <thead>
                            <tr><th>Rank</th><th>Kode</th><th>Lokasi</th><th>Q (Prioritas)</th><th>N (Utilitas)</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($hasil['ranking'] as $row): ?>
                                <tr class="<?= $row['rank'] === 1 ? 'row-win' : '' ?>">
                                    <td>
                                        <span class="rank-badge rank-<?= $row['rank'] ?>"><?= $row['rank'] ?></span>
                                    </td>
                                    <td><span class="chip"><?= e($row['kode']) ?></span></td>
                                    <td class="strong"><?= e($row['nama']) ?></td>
                                    <td><?= $fmt($row['q']) ?></td>
                                    <td><strong><?= $fmt($row['n'], 2) ?>%</strong></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="chart-box">
                    <canvas id="chartUtilitas"></canvas>
                </div>
            </div>
        </div>
    </div>

    <script id="data-ranking" type="application/json"><?= json_encode(array_map(
        fn($r) => ['label' => $r['kode'], 'nilai' => round($r['n'], 2)],
        $hasil['ranking']
    )) ?></script>
<?php endif; ?>
