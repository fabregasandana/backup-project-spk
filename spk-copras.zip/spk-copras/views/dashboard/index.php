<?php

use Spk\Support\Icon;

use function Spk\Support\base_url;
use function Spk\Support\e;
?>
<section class="hero">
    <div class="hero-text">
        <h2>Sistem Pendukung Keputusan<br><span>Lokasi TPS Reduce-Reuse-Recycle</span></h2>
        <p>
            Menilai kelayakan kandidat lokasi pengolahan sampah di perkotaan dengan metode
            <strong>COPRAS</strong> berdasarkan aksesibilitas, jarak permukiman, luas lahan,
            biaya pengadaan, potensi dampak sosial, dan dukungan masyarakat.
        </p>
        <div class="hero-actions">
            <a class="btn btn-primary" href="<?= e(base_url('/penilaian')) ?>">
                <?= Icon::render('table-2', 18) ?> Isi Penilaian
            </a>
            <a class="btn btn-ghost" href="<?= e(base_url('/hasil')) ?>">
                <?= Icon::render('chart-bar', 18) ?> Lihat Hasil
            </a>
        </div>
    </div>
    <div class="hero-art"><?= Icon::render('recycle', 120, 'hero-icon') ?></div>
</section>

<div class="stat-grid">
    <div class="stat-card">
        <span class="stat-icon tone-green"><?= Icon::render('list-checks', 24) ?></span>
        <div class="stat-body">
            <strong><?= (int) $jmlKriteria ?></strong>
            <span>Kriteria Penilaian</span>
        </div>
    </div>
    <div class="stat-card">
        <span class="stat-icon tone-yellow"><?= Icon::render('map-pin', 24) ?></span>
        <div class="stat-body">
            <strong><?= (int) $jmlAlternatif ?></strong>
            <span>Alternatif Lokasi</span>
        </div>
    </div>
    <div class="stat-card">
        <span class="stat-icon tone-blue"><?= Icon::render('scale', 24) ?></span>
        <div class="stat-body">
            <strong><?= number_format((float) $totalBobot, 0) ?></strong>
            <span>Total Bobot</span>
        </div>
    </div>
</div>

<div class="panel">
    <div class="panel-head">
        <h3><?= Icon::render('trophy', 20) ?> Rekomendasi Saat Ini</h3>
    </div>
    <div class="panel-body">
        <?php if ($rekomendasi === null): ?>
            <p class="empty-note">
                <?= Icon::render('inbox', 18) ?>
                Lengkapi data kriteria, alternatif, dan penilaian untuk melihat rekomendasi.
            </p>
        <?php else: ?>
            <div class="rekomendasi">
                <div class="rekom-medal"><?= Icon::render('award', 40) ?></div>
                <div class="rekom-info">
                    <span class="rekom-rank">Peringkat 1 · <?= e($rekomendasi['kode']) ?></span>
                    <strong><?= e($rekomendasi['nama']) ?></strong>
                    <p>Lokasi dengan nilai utilitas tertinggi berdasarkan perhitungan COPRAS.</p>
                </div>
                <div class="rekom-score">
                    <strong><?= number_format($rekomendasi['n'], 2) ?>%</strong>
                    <span>Nilai Utilitas</span>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
