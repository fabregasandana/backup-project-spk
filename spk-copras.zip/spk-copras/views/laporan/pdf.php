<?php

use Spk\Support\Config;

use function Spk\Support\e;

$appName = Config::get('app')['name'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 10px; color: #0b130b; line-height: 1.4; }
        .rpt-head { border-bottom: 2px solid #0b130b; padding-bottom: 8px; margin-bottom: 14px; }
        .rpt-head strong { font-size: 13px; display: block; }
        .rpt-head span { font-size: 9px; }
        .rpt-h { font-size: 11px; margin: 14px 0 6px; color: #15803d; }
        table.rpt { width: 100%; border-collapse: collapse; font-size: 9px; }
        table.rpt th, table.rpt td { border: 1px solid #0b130b; padding: 4px 5px; text-align: left; }
        table.rpt thead th { background: #dcfce7; }
        .rpt-note { margin-top: 12px; padding: 8px; border: 1px solid #0b130b; font-size: 9px; }
        .rpt-foot { margin-top: 18px; border-top: 1px dashed #9db894; padding-top: 6px; font-size: 8px; color: #5c6b58; }
    </style>
</head>
<body>
    <header class="rpt-head">
        <strong>LAPORAN SISTEM PENDUKUNG KEPUTUSAN</strong>
        <span>Pemilihan Lokasi Tempat Pengolahan Sampah Reduce-Reuse-Recycle (TPS 3R)</span><br>
        <span>Metode COPRAS · <?= e($appName) ?> · Dicetak <?= date('d/m/Y H:i') ?></span>
    </header>

    <?= $body ?>

    <footer class="rpt-foot">Dokumen dihasilkan otomatis oleh <?= e($appName) ?>.</footer>
</body>
</html>
