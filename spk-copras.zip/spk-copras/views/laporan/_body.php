<?php

use function Spk\Support\e;

$fmt = fn($v, $d = 4) => number_format((float) $v, $d, ',', '.');
?>
<h2 class="rpt-h">1. Data Kriteria</h2>
<table class="rpt">
    <thead>
        <tr><th>Kode</th><th>Nama Kriteria</th><th>Atribut</th><th>Bobot</th></tr>
    </thead>
    <tbody>
        <?php foreach ($kriteria as $k): ?>
            <tr>
                <td><?= e($k['kode']) ?></td>
                <td><?= e($k['nama']) ?></td>
                <td><?= $k['atribut'] === 'benefit' ? 'Benefit' : 'Cost' ?></td>
                <td><?= number_format((float) $k['bobot'], 2) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<h2 class="rpt-h">2. Data Alternatif Lokasi</h2>
<table class="rpt">
    <thead>
        <tr><th>Kode</th><th>Nama Lokasi</th><th>Alamat / Kawasan</th></tr>
    </thead>
    <tbody>
        <?php foreach ($alternatif as $a): ?>
            <tr>
                <td><?= e($a['kode']) ?></td>
                <td><?= e($a['nama']) ?></td>
                <td><?= e($a['lokasi'] ?? '-') ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<h2 class="rpt-h">3. Matriks Penilaian</h2>
<table class="rpt">
    <thead>
        <tr>
            <th>Alternatif</th>
            <?php foreach ($kriteria as $k): ?><th><?= e($k['kode']) ?></th><?php endforeach; ?>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($alternatif as $a): ?>
            <tr>
                <td><?= e($a['kode']) ?> · <?= e($a['nama']) ?></td>
                <?php foreach ($kriteria as $k): ?>
                    <td><?= $fmt($matriks[(int) $a['id']][(int) $k['id']] ?? 0, 2) ?></td>
                <?php endforeach; ?>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php if ($hasil !== null): ?>
    <h2 class="rpt-h">4. Matriks Ternormalisasi &amp; Terbobot</h2>
    <table class="rpt">
        <thead>
            <tr>
                <th>Alternatif</th>
                <?php foreach ($kriteria as $k): ?><th><?= e($k['kode']) ?></th><?php endforeach; ?>
                <th>S+</th><th>S−</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($alternatif as $a): ?>
                <tr>
                    <td><?= e($a['kode']) ?></td>
                    <?php foreach ($kriteria as $k): ?>
                        <td><?= $fmt($hasil['terbobot'][(int) $a['id']][(int) $k['id']]) ?></td>
                    <?php endforeach; ?>
                    <td><?= $fmt($hasil['sPlus'][(int) $a['id']]) ?></td>
                    <td><?= $fmt($hasil['sMinus'][(int) $a['id']]) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <h2 class="rpt-h">5. Peringkat Akhir (COPRAS)</h2>
    <table class="rpt">
        <thead>
            <tr><th>Peringkat</th><th>Kode</th><th>Lokasi</th><th>Nilai Q</th><th>Nilai Utilitas</th></tr>
        </thead>
        <tbody>
            <?php foreach ($hasil['ranking'] as $row): ?>
                <tr>
                    <td><?= $row['rank'] ?></td>
                    <td><?= e($row['kode']) ?></td>
                    <td><?= e($row['nama']) ?></td>
                    <td><?= $fmt($row['q']) ?></td>
                    <td><?= $fmt($row['n'], 2) ?>%</td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <p class="rpt-note">
        Rekomendasi: lokasi paling layak adalah
        <strong><?= e($hasil['ranking'][0]['kode']) ?> — <?= e($hasil['ranking'][0]['nama']) ?></strong>
        dengan nilai utilitas <?= $fmt($hasil['ranking'][0]['n'], 2) ?>%.
    </p>
<?php endif; ?>
