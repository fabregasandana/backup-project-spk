<?php

use Spk\Support\Config;

use function Spk\Support\e;

$appName = Config::get('app')['name'];
?>
<html xmlns:x="urn:schemas-microsoft-com:office:excel">
<head>
    <meta charset="UTF-8">
    <!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>
    <x:Name>Laporan SPK</x:Name>
    <x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions>
    </x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
    <style>
        table.rpt { border-collapse: collapse; }
        table.rpt th, table.rpt td { border: 1px solid #000; padding: 4px 8px; }
        table.rpt thead th { background: #dcfce7; font-weight: bold; }
        .rpt-h { font-weight: bold; }
    </style>
</head>
<body>
    <p><strong>LAPORAN SISTEM PENDUKUNG KEPUTUSAN</strong><br>
    Pemilihan Lokasi TPS Reduce-Reuse-Recycle (TPS 3R) · Metode COPRAS<br>
    <?= e($appName) ?> · Dicetak <?= date('d/m/Y H:i') ?></p>

    <?= $body ?>
</body>
</html>
