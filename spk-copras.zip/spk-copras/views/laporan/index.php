<?php

use Spk\Support\Config;
use Spk\Support\Icon;

use function Spk\Support\base_url;
use function Spk\Support\e;

$appName = Config::get('app')['name'];
$autoPrint = ($print ?? false);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan · <?= e($appName) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(base_url('assets/css/laporan.css')) ?>">
</head>
<body>
<div class="rpt-toolbar no-print">
    <a class="rpt-btn" href="<?= e(base_url('/penilaian')) ?>">&larr; Kembali</a>
    <button class="rpt-btn rpt-btn-primary" onclick="window.print()"><?= Icon::render('printer', 16) ?> Cetak</button>
    <a class="rpt-btn" href="<?= e(base_url('/laporan/pdf')) ?>"><?= Icon::render('file-text', 16) ?> Simpan PDF</a>
    <a class="rpt-btn" href="<?= e(base_url('/laporan/excel')) ?>"><?= Icon::render('file-spreadsheet', 16) ?> Simpan Excel</a>
</div>

<div class="rpt-sheet">
    <header class="rpt-head">
        <div class="rpt-head-text">
            <strong>LAPORAN SISTEM PENDUKUNG KEPUTUSAN</strong>
            <span>Pemilihan Lokasi Tempat Pengolahan Sampah Reduce-Reuse-Recycle (TPS 3R)</span>
            <span>Metode COPRAS · <?= e($appName) ?></span>
        </div>
        <div class="rpt-head-meta">
            <span>Tanggal cetak:</span>
            <strong><?= date('d/m/Y H:i') ?></strong>
        </div>
    </header>

    <?= $body ?>

    <footer class="rpt-foot">
        <span>Dokumen dihasilkan otomatis oleh <?= e($appName) ?>.</span>
    </footer>
</div>

<?php if ($autoPrint): ?>
    <script>window.addEventListener('load', () => window.print());</script>
<?php endif; ?>
</body>
</html>
