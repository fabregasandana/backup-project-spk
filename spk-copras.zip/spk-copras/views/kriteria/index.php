<?php

use Spk\Support\Icon;

use function Spk\Support\base_url;
use function Spk\Support\e;
?>
<div class="panel">
    <div class="panel-head">
        <h3><?= Icon::render('list-checks', 20) ?> Daftar Kriteria</h3>
        <button class="btn btn-primary" data-open-modal="modal-kriteria" data-mode="create">
            <?= Icon::render('plus', 18) ?> Tambah Kriteria
        </button>
    </div>
    <div class="panel-body">
        <div class="table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width:90px">Kode</th>
                        <th>Nama Kriteria</th>
                        <th style="width:150px">Atribut</th>
                        <th style="width:120px">Bobot</th>
                        <th style="width:140px">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($kriteria === []): ?>
                        <tr><td colspan="5" class="empty-cell">Belum ada kriteria.</td></tr>
                    <?php else: ?>
                        <?php foreach ($kriteria as $k): ?>
                            <tr>
                                <td><span class="chip"><?= e($k['kode']) ?></span></td>
                                <td class="strong"><?= e($k['nama']) ?></td>
                                <td>
                                    <span class="tag tag-<?= $k['atribut'] === 'benefit' ? 'green' : 'red' ?>">
                                        <?= $k['atribut'] === 'benefit' ? 'Benefit' : 'Cost' ?>
                                    </span>
                                </td>
                                <td><?= number_format((float) $k['bobot'], 2) ?></td>
                                <td>
                                    <div class="row-actions">
                                        <button class="icon-btn"
                                                data-open-modal="modal-kriteria"
                                                data-mode="edit"
                                                data-id="<?= (int) $k['id'] ?>"
                                                data-kode="<?= e($k['kode']) ?>"
                                                data-nama="<?= e($k['nama']) ?>"
                                                data-atribut="<?= e($k['atribut']) ?>"
                                                data-bobot="<?= e($k['bobot']) ?>"
                                                title="Ubah">
                                            <?= Icon::render('pencil', 16) ?>
                                        </button>
                                        <button class="icon-btn icon-btn-danger"
                                                data-delete="<?= e(base_url('/kriteria/' . $k['id'] . '/delete')) ?>"
                                                data-label="<?= e($k['nama']) ?>"
                                                title="Hapus">
                                            <?= Icon::render('trash-2', 16) ?>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal" id="modal-kriteria" hidden>
    <div class="modal-card">
        <div class="modal-head">
            <h3 data-modal-title>Tambah Kriteria</h3>
            <button class="icon-btn" data-close-modal><?= Icon::render('x', 18) ?></button>
        </div>
        <form class="modal-body" data-create="<?= e(base_url('/kriteria')) ?>"
              data-update="<?= e(base_url('/kriteria')) ?>">
            <input type="hidden" name="id">
            <div class="field">
                <label for="k-kode">Kode</label>
                <input id="k-kode" name="kode" placeholder="C1" required>
            </div>
            <div class="field">
                <label for="k-nama">Nama Kriteria</label>
                <input id="k-nama" name="nama" placeholder="Aksesibilitas" required>
            </div>
            <div class="field-row">
                <div class="field">
                    <label for="k-atribut">Atribut</label>
                    <select id="k-atribut" name="atribut">
                        <option value="benefit">Benefit (makin besar makin baik)</option>
                        <option value="cost">Cost (makin kecil makin baik)</option>
                    </select>
                </div>
                <div class="field">
                    <label for="k-bobot">Bobot</label>
                    <input id="k-bobot" name="bobot" type="number" step="0.01" min="0" value="0" required>
                </div>
            </div>
            <div class="modal-foot">
                <button type="button" class="btn btn-ghost" data-close-modal>Batal</button>
                <button type="submit" class="btn btn-primary"><?= Icon::render('save', 18) ?> Simpan</button>
            </div>
        </form>
    </div>
</div>
