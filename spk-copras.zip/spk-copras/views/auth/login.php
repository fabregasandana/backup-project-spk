<?php
/**
 * Halaman login — berdiri sendiri (tanpa layout aplikasi).
 * Variabel dari AuthController::showLogin(): $appName, $flashError, $oldUsername
 */

use function Spk\Support\base_url;
use function Spk\Support\e;
use Spk\Support\Icon;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login · <?= e($appName) ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?= e(base_url('assets/css/style.css')) ?>">
    <style>
        .login-wrap {
            min-height: 100vh;
            display: grid;
            place-items: center;
            padding: 24px 16px;
        }
        .login-card {
            width: 100%;
            max-width: 420px;
            background: var(--paper);
            border: var(--border);
            box-shadow: 8px 8px 0 var(--ink);
            border-radius: 16px;
            overflow: hidden;
            animation: pop .18s ease;
        }
        .login-head {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            padding: 28px 24px 22px;
            background: var(--green-tint);
            border-bottom: var(--border);
            text-align: center;
        }
        .login-mark {
            display: grid;
            place-items: center;
            width: 64px; height: 64px;
            background: var(--yellow);
            border: var(--border);
            border-radius: 16px;
            box-shadow: var(--shadow-sm);
            color: var(--green);
        }
        .login-head strong { font-size: 1.3rem; font-weight: 700; letter-spacing: -.4px; }
        .login-head small { font-size: .78rem; font-weight: 500; opacity: .7; }
        .login-body { padding: 24px; display: flex; flex-direction: column; gap: 16px; }
        .login-input {
            padding: 12px 14px;
            font-family: inherit;
            font-size: .92rem;
            font-weight: 500;
            border: 2px solid var(--ink);
            border-radius: 10px;
            background: var(--green-tint);
            transition: background .12s ease, box-shadow .12s ease;
        }
        .login-input:focus { outline: none; background: #fff; box-shadow: 3px 3px 0 var(--green); }
        .login-btn {
            justify-content: center;
            width: 100%;
            font-size: .95rem;
            padding: 12px 18px;
        }
        .login-foot {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            padding: 14px;
            background: var(--ink);
            color: var(--green-bright);
            font-size: .72rem;
            font-weight: 500;
        }
        .alert-error {
            display: flex;
            align-items: center;
            gap: 9px;
            background: #fecaca;
            border: 2px solid var(--ink);
            border-radius: 10px;
            padding: 11px 13px;
            font-size: .84rem;
            font-weight: 600;
            color: #7f1d1d;
        }
    </style>
</head>
<body>
<div class="login-wrap">
    <div class="login-card">
        <div class="login-head">
            <span class="login-mark"><?= Icon::render('recycle', 34) ?></span>
            <div>
                <strong>SPK TPS 3R</strong><br>
                <small>Metode COPRAS — Silakan login untuk melanjutkan</small>
            </div>
        </div>

        <div class="login-body">
            <?php if ($flashError !== null): ?>
                <div class="alert-error"><?= Icon::render('triangle-alert', 18) ?> <?= e($flashError) ?></div>
            <?php endif; ?>

            <form method="post" action="<?= e(base_url('/login')) ?>">
                <div class="field" style="margin-bottom: 14px;">
                    <label for="username">Username</label>
                    <input class="login-input" type="text" id="username" name="username"
                           placeholder="Masukkan username" value="<?= $oldUsername ?>" required autofocus>
                </div>

                <div class="field" style="margin-bottom: 20px;">
                    <label for="password">Password</label>
                    <input class="login-input" type="password" id="password" name="password"
                           placeholder="Masukkan password" required>
                </div>

                <button type="submit" class="btn btn-primary login-btn">
                    <?= Icon::render('log-in', 18) ?> Masuk
                </button>
            </form>
        </div>

        <div class="login-foot">
            <?= Icon::render('leaf', 14) ?>
            <span>Pemilihan lokasi pengolahan sampah Reduce-Reuse-Recycle</span>
        </div>
    </div>
</div>
</body>
</html>
