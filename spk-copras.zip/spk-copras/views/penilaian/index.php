<?php

use Spk\Support\Icon;

use function Spk\Support\base_url;
use function Spk\Support\e;

$adaData = $kriteria !== [] && $alternatif !== [];
?>
<div class="panel">
    <form data-create="<?= e(base_url('/penilaian')) ?>">
        <div class="panel-head">
            <h3><?= Icon::render('table-2', 20) ?> Matriks Penilaian</h3>
            <div class="head-actions">
                <?php if ($adaData): ?>
                    <div class="report-actions" title="Laporan">
                        <a class="btn btn-ghost btn-sm" target="_blank"
                           href="<?= e(base_url('/laporan?print=1')) ?>">
                            <?= Icon::render('printer', 16) ?> Cetak
                        </a>
                        <a class="btn btn-ghost btn-sm" href="<?= e(base_url('/laporan/excel')) ?>">
                            <?= Icon::render('file-spreadsheet', 16) ?> Excel
                        </a>
                        <a class="btn btn-ghost btn-sm" href="<?= e(base_url('/laporan/pdf')) ?>">
                            <?= Icon::render('file-text', 16) ?> PDF
                        </a>
                    </div>
                <?php endif; ?>
                <button type="submit" class="btn btn-primary">
                    <?= Icon::render('save', 18) ?> Simpan Penilaian
                </button>
            </div>
        </div>
        <div class="panel-body">
            <?php if (!$adaData): ?>
                <p class="empty-note">
                    <?= Icon::render('inbox', 18) ?>
                    Lengkapi data kriteria dan alternatif terlebih dahulu.
                </p>
            <?php else: ?>
                <p class="hint">
                    <?= Icon::render('lightbulb', 16) ?>
                    Isi nilai tiap lokasi untuk setiap kriteria. Benefit = makin besar makin baik,
                    Cost = makin kecil makin baik.
                </p>
                <div class="table-wrap">
                    <table class="data-table matrix">
                        <thead>
                            <tr>
                                <th class="sticky-col">Alternatif</th>
                                <?php foreach ($kriteria as $k): ?>
                                    <th>
                                        <span class="chip"><?= e($k['kode']) ?></span>
                                        <div class="th-sub"><?= e($k['nama']) ?></div>
                                        <span class="tag tag-<?= $k['atribut'] === 'benefit' ? 'green' : 'red' ?> tag-sm">
                                            <?= $k['atribut'] ?>
                                        </span>
                                    </th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($alternatif as $a): ?>
                                <tr>
                                    <td class="sticky-col strong">
                                        <?= e($a['kode']) ?> · <?= e($a['nama']) ?>
                                    </td>
                                    <?php foreach ($kriteria as $k): ?>
                                        <?php $val = $matriks[(int) $a['id']][(int) $k['id']] ?? 0; ?>
                                        <td>
                                            <input class="cell-input" type="number" step="0.01" min="0"
                                                   name="nilai[<?= (int) $a['id'] ?>-<?= (int) $k['id'] ?>]"
                                                   value="<?= e(rtrim(rtrim(number_format($val, 2, '.', ''), '0'), '.')) ?>">
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </form>
</div>
