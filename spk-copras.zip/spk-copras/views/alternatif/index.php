<?php

use Spk\Support\Icon;

use function Spk\Support\base_url;
use function Spk\Support\e;
?>
<div class="panel">
    <div class="panel-head">
        <h3><?= Icon::render('map-pin', 20) ?> Daftar Alternatif Lokasi</h3>
        <button class="btn btn-primary" data-open-modal="modal-alternatif" data-mode="create">
            <?= Icon::render('plus', 18) ?> Tambah Alternatif
        </button>
    </div>
    <div class="panel-body">
        <div class="table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width:90px">Kode</th>
                        <th>Nama Lokasi</th>
                        <th>Alamat / Kawasan</th>
                        <th style="width:140px">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($alternatif === []): ?>
                        <tr><td colspan="4" class="empty-cell">Belum ada alternatif lokasi.</td></tr>
                    <?php else: ?>
                        <?php foreach ($alternatif as $a): ?>
                            <tr>
                                <td><span class="chip"><?= e($a['kode']) ?></span></td>
                                <td class="strong"><?= e($a['nama']) ?></td>
                                <td><?= e($a['lokasi'] ?? '-') ?></td>
                                <td>
                                    <div class="row-actions">
                                        <button class="icon-btn"
                                                data-open-modal="modal-alternatif"
                                                data-mode="edit"
                                                data-id="<?= (int) $a['id'] ?>"
                                                data-kode="<?= e($a['kode']) ?>"
                                                data-nama="<?= e($a['nama']) ?>"
                                                data-lokasi="<?= e($a['lokasi'] ?? '') ?>"
                                                title="Ubah">
                                            <?= Icon::render('pencil', 16) ?>
                                        </button>
                                        <button class="icon-btn icon-btn-danger"
                                                data-delete="<?= e(base_url('/alternatif/' . $a['id'] . '/delete')) ?>"
                                                data-label="<?= e($a['nama']) ?>"
                                                title="Hapus">
                                            <?= Icon::render('trash-2', 16) ?>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal" id="modal-alternatif" hidden>
    <div class="modal-card">
        <div class="modal-head">
            <h3 data-modal-title>Tambah Alternatif</h3>
            <button class="icon-btn" data-close-modal><?= Icon::render('x', 18) ?></button>
        </div>
        <form class="modal-body" data-create="<?= e(base_url('/alternatif')) ?>"
              data-update="<?= e(base_url('/alternatif')) ?>">
            <input type="hidden" name="id">
            <div class="field-row">
                <div class="field">
                    <label for="a-kode">Kode</label>
                    <input id="a-kode" name="kode" placeholder="A1" required>
                </div>
                <div class="field">
                    <label for="a-nama">Nama Lokasi</label>
                    <input id="a-nama" name="nama" placeholder="Lahan Kelurahan Sukamaju" required>
                </div>
            </div>
            <div class="field">
                <label for="a-lokasi">Alamat / Kawasan</label>
                <input id="a-lokasi" name="lokasi" placeholder="Jl. Sukamaju No. 12, Kec. Coblong">
            </div>
            <div class="modal-foot">
                <button type="button" class="btn btn-ghost" data-close-modal>Batal</button>
                <button type="submit" class="btn btn-primary"><?= Icon::render('save', 18) ?> Simpan</button>
            </div>
        </form>
    </div>
</div>
