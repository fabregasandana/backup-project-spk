<?php

return [
    'app' => [
        'name' => 'SPK Lokasi TPS 3R',
        'short' => 'TPS 3R',
    ],

    'database' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'spk_tps',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4',
    ],
];
