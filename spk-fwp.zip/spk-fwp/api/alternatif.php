<?php

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';

$input = require_post();
$action = $input['action'] ?? '';
$id = (int) ($input['id'] ?? 0);

if ($action === 'save') {
    $kode = strtoupper(trim($input['kode'] ?? ''));
    $nama = trim($input['nama'] ?? '');
    $jabatan = trim($input['jabatan'] ?? '');

    if ($kode === '' || $nama === '') {
        json_fail('Kode dan nama calon wajib diisi.');
    }
    if (repo()->codeExists('alternatif', $kode, $id ?: null)) {
        json_fail("Kode {$kode} sudah dipakai.");
    }

    $data = compact('kode', 'nama', 'jabatan');
    $id ? repo()->update('alternatif', $id, $data) : repo()->insert('alternatif', $data);

    json_ok(['message' => 'Data calon tersimpan.']);
}

if ($action === 'delete') {
    repo()->delete('alternatif', $id);
    json_ok(['message' => 'Data calon dihapus.']);
}

json_fail('Aksi tidak dikenal.');
