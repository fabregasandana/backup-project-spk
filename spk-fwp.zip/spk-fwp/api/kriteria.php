<?php

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';

$input = require_post();
$action = $input['action'] ?? '';
$id = (int) ($input['id'] ?? 0);

if ($action === 'save') {
    $kode = strtoupper(trim($input['kode'] ?? ''));
    $nama = trim($input['nama'] ?? '');
    $atribut = $input['atribut'] ?? 'benefit';
    $bobot = (int) ($input['bobot'] ?? 0);

    if ($kode === '' || $nama === '') {
        json_fail('Kode dan nama kriteria wajib diisi.');
    }
    if (!in_array($atribut, ['benefit', 'cost'], true)) {
        json_fail('Atribut tidak valid.');
    }
    if ($bobot < 1 || $bobot > 100) {
        json_fail('Bobot harus antara 1 - 100.');
    }
    if (repo()->codeExists('kriteria', $kode, $id ?: null)) {
        json_fail("Kode {$kode} sudah dipakai.");
    }

    $data = compact('kode', 'nama', 'atribut', 'bobot');
    $id ? repo()->update('kriteria', $id, $data) : repo()->insert('kriteria', $data);

    json_ok(['message' => 'Kriteria tersimpan.']);
}

if ($action === 'delete') {
    repo()->delete('kriteria', $id);
    json_ok(['message' => 'Kriteria dihapus.']);
}

json_fail('Aksi tidak dikenal.');
