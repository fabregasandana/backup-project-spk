<?php

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';

$input = require_post();
$action = $input['action'] ?? '';

if ($action === 'save') {
    $alternatifId = (int) ($input['alternatif_id'] ?? 0);
    $kriteriaId = (int) ($input['kriteria_id'] ?? 0);
    $skalaId = (int) ($input['skala_id'] ?? 0);

    if (!$alternatifId || !$kriteriaId || !$skalaId) {
        json_fail('Data penilaian tidak lengkap.');
    }

    repo()->saveAssessment($alternatifId, $kriteriaId, $skalaId);
    json_ok(['message' => 'Penilaian tersimpan.']);
}

json_fail('Aksi tidak dikenal.');
