<?php
require_once __DIR__ . '/bootstrap.php';

$pageTitle = 'Data Kriteria';
$activeMenu = 'kriteria';
$criteria = repo()->criteria();
$totalBobot = array_sum(array_column($criteria, 'bobot'));

require __DIR__ . '/partials/header.php';
?>

<div class="card">
    <div class="card-head">
        <div>
            <div class="card-title"><?= icon('list-checks') ?> Kriteria Penilaian</div>
            <p class="hint">Total bobot saat ini: <strong><?= $totalBobot ?></strong> — akan dinormalisasi otomatis oleh metode FWP sehingga berjumlah 1.</p>
        </div>
        <button class="btn" onclick="openForm()"><?= icon('plus', 'icon', 17) ?> Tambah Kriteria</button>
    </div>

    <?php if ($criteria === []): ?>
        <div class="empty"><?= icon('inbox', 'icon', 40) ?><p>Belum ada kriteria. Klik "Tambah Kriteria".</p></div>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr><th>Kode</th><th>Nama Kriteria</th><th>Atribut</th><th>Bobot</th><th>Bobot Normalisasi</th><th>Aksi</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($criteria as $id => $k): ?>
                        <tr>
                            <td><strong><?= e($k['kode']) ?></strong></td>
                            <td><?= e($k['nama']) ?></td>
                            <td><span class="badge <?= e($k['atribut']) ?>"><?= $k['atribut'] === 'benefit' ? 'Benefit' : 'Cost' ?></span></td>
                            <td><?= (int) $k['bobot'] ?></td>
                            <td><?= $totalBobot > 0 ? num($k['bobot'] / $totalBobot) : '—' ?></td>
                            <td>
                                <div class="actions">
                                    <button class="btn-mini" title="Edit" onclick='openForm(<?= json_encode($k, JSON_HEX_APOS) ?>)'><?= icon('pencil', 'icon', 16) ?></button>
                                    <button class="btn-mini danger" title="Hapus" onclick="hapus(<?= $id ?>, '<?= e($k['nama']) ?>')"><?= icon('trash-2', 'icon', 16) ?></button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    <?php endif ?>
</div>

<script>
const fields = [
    { name: 'kode', label: 'Kode (contoh: C1)', required: true, attrs: 'maxlength="10" placeholder="C1"' },
    { name: 'nama', label: 'Nama Kriteria', required: true, attrs: 'maxlength="100" placeholder="Kepemimpinan"' },
    { name: 'atribut', label: 'Atribut', type: 'select', options: [{ value: 'benefit', label: 'Benefit (semakin baik semakin tinggi)' }, { value: 'cost', label: 'Cost (semakin baik semakin rendah)' }] },
    { name: 'bobot', label: 'Bobot (1 - 100)', type: 'number', required: true, attrs: 'min="1" max="100"' },
];

function openForm(data = {}) {
    App.form({
        title: data.id ? 'Edit Kriteria' : 'Tambah Kriteria',
        fields,
        values: data,
        onSubmit: async (payload) => {
            const res = await App.request('api/kriteria.php', { action: 'save', id: data.id || 0, ...payload });
            res.ok ? location.reload() : App.toast('error', res.message);
        },
    });
}

function hapus(id, nama) {
    App.confirm(`Kriteria "${nama}" beserta seluruh penilaian terkait akan dihapus.`, async () => {
        const res = await App.request('api/kriteria.php', { action: 'delete', id });
        res.ok ? location.reload() : App.toast('error', res.message);
    });
}
</script>

<?php require __DIR__ . '/partials/footer.php'; ?>
