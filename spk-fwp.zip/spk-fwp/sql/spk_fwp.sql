CREATE DATABASE IF NOT EXISTS spk_fwp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE spk_fwp;

CREATE TABLE kriteria (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(10) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    atribut ENUM('benefit', 'cost') NOT NULL DEFAULT 'benefit',
    bobot TINYINT UNSIGNED NOT NULL
) ENGINE=InnoDB;

CREATE TABLE skala_fuzzy (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(10) NOT NULL UNIQUE,
    label VARCHAR(50) NOT NULL,
    a DECIMAL(3,1) NOT NULL,
    b DECIMAL(3,1) NOT NULL,
    c DECIMAL(3,1) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE alternatif (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(10) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    jabatan VARCHAR(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB;

CREATE TABLE penilaian (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    alternatif_id INT UNSIGNED NOT NULL,
    kriteria_id INT UNSIGNED NOT NULL,
    skala_id INT UNSIGNED NOT NULL,
    UNIQUE KEY unik_penilaian (alternatif_id, kriteria_id),
    CONSTRAINT fk_penilaian_alternatif FOREIGN KEY (alternatif_id) REFERENCES alternatif (id) ON DELETE CASCADE,
    CONSTRAINT fk_penilaian_kriteria FOREIGN KEY (kriteria_id) REFERENCES kriteria (id) ON DELETE CASCADE,
    CONSTRAINT fk_penilaian_skala FOREIGN KEY (skala_id) REFERENCES skala_fuzzy (id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO kriteria (kode, nama, atribut, bobot) VALUES
('C1', 'Kepemimpinan', 'benefit', 30),
('C2', 'Komunikasi', 'benefit', 20),
('C3', 'Komitmen', 'benefit', 20),
('C4', 'Pengalaman', 'benefit', 15),
('C5', 'Kepercayaan Anggota', 'benefit', 15);

INSERT INTO skala_fuzzy (kode, label, a, b, c) VALUES
('SP', 'Sangat Kurang', 1, 1, 2),
('KP', 'Kurang', 1, 2, 3),
('C',  'Cukup', 2, 3, 4),
('B',  'Baik', 3, 4, 5),
('SB', 'Sangat Baik', 4, 5, 5);

INSERT INTO alternatif (kode, nama, jabatan) VALUES
('A1', 'Rangga Prasetyo', 'Ketua Seksi Kepemudaan'),
('A2', 'Siti Nurhaliza', 'Sekretaris Karang Taruna'),
('A3', 'Budi Santoso', 'Bendahara Karang Taruna'),
('A4', 'Dewi Lestari', 'Koordinator Seksi Acara'),
('A5', 'Andi Wijaya', 'Ketua Seksi Perlengkapan');

CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL DEFAULT '',
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO users (username, nama, password_hash) VALUES
('admin', 'Administrator', '$2y$10$ukuNvpY6oYvtzP1Yl3jy9u80E9G8CU/icZGUdzSYmpOOKima14//u');

INSERT INTO penilaian (alternatif_id, kriteria_id, skala_id) VALUES
(1, 1, 5), (1, 2, 4), (1, 3, 5), (1, 4, 3), (1, 5, 4),
(2, 1, 4), (2, 2, 5), (2, 3, 4), (2, 4, 3), (2, 5, 5),
(3, 1, 3), (3, 2, 3), (3, 3, 4), (3, 4, 5), (3, 5, 3),
(4, 1, 5), (4, 2, 4), (4, 3, 3), (4, 4, 4), (4, 5, 4),
(5, 1, 3), (5, 2, 4), (5, 3, 5), (5, 4, 2), (5, 5, 4);
