<?php
require_once __DIR__ . '/bootstrap.php';

$pageTitle = 'Laporan Hasil';
$activeMenu = 'laporan';
$calc = buildCalculation();

require __DIR__ . '/partials/header.php';
?>

<?php if ($calc === null): ?>
    <div class="card">
        <div class="empty">
            <?= icon('inbox', 'icon', 44) ?>
            <p>Belum ada hasil. Lengkapi seluruh data dan penilaian terlebih dahulu.</p>
        </div>
    </div>
<?php else:
    $winner = null;
    foreach ($calc['results'] as $altId => $res) {
        if ($res['rank'] === 1) {
            $winner = $calc['alternatives'][$altId] + ['v' => $res['v']];
            break;
        }
    }
?>
    <div class="card print-area">
        <div class="card-head no-print">
            <div class="card-title"><?= icon('file-text') ?> Laporan Pemilihan Ketua Panitia</div>
            <div class="head-actions">
                <button class="btn" onclick="simpanPdf()"><?= icon('download', 'icon', 17) ?> Simpan PDF</button>
                <button class="btn" onclick="simpanExcel()"><?= icon('file-spreadsheet', 'icon', 17) ?> Simpan Excel</button>
                <button class="btn" onclick="window.print()"><?= icon('printer', 'icon', 17) ?> Cetak</button>
            </div>
        </div>

        <div class="report-head">
            <h2>Hasil Perhitungan Metode FWP</h2>
            <p class="muted">SPK Pemilihan Calon Ketua Panitia Kegiatan Besar Berbasis Penilaian Fuzzy</p>
            <p class="muted">Dicetak: <?= date('d/m/Y H:i') ?></p>
        </div>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr><th>Rank</th><th>Kode</th><th>Nama Calon</th><th>Jabatan</th><th>Nilai Akhir (V)</th><th>Keterangan</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($calc['results'] as $altId => $res): $a = $calc['alternatives'][$altId]; ?>
                        <tr>
                            <td><span class="badge rank">#<?= $res['rank'] ?></span></td>
                            <td><?= e($a['kode']) ?></td>
                            <td><strong><?= e($a['nama']) ?></strong></td>
                            <td class="muted"><?= e($a['jabatan']) ?></td>
                            <td><strong><?= num($res['v'], 6) ?></strong></td>
                            <td><?= $res['rank'] === 1 ? 'Direkomendasikan' : '' ?></td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>

        <?php if ($winner): ?>
            <div class="formula" style="margin-top:20px">
                Kesimpulan: calon ketua panitia yang direkomendasikan adalah
                <strong><?= e($winner['nama']) ?></strong> (<?= e($winner['jabatan']) ?>)
                dengan nilai preferensi tertinggi V = <strong><?= num($winner['v'], 6) ?></strong>.
            </div>
        <?php endif ?>
    </div>

    <?php
        $exportRows = [];
        foreach ($calc['results'] as $altId => $res) {
            $a = $calc['alternatives'][$altId];
            $exportRows[] = [
                $res['rank'],
                $a['kode'],
                $a['nama'],
                $a['jabatan'],
                round($res['v'], 6),
                $res['rank'] === 1 ? 'Direkomendasikan' : '',
            ];
        }
        $export = [
            'tanggal' => date('d/m/Y H:i'),
            'rows' => $exportRows,
            'kesimpulan' => $winner
                ? sprintf('Rekomendasi: %s (%s) dengan nilai preferensi tertinggi V = %s.', $winner['nama'], $winner['jabatan'], num($winner['v'], 6))
                : '',
        ];
    ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <script>
    const laporan = <?= json_encode($export, JSON_UNESCAPED_UNICODE) ?>;

    function excelWorkbook() {
        const aoa = [
            ['Laporan Hasil Pemilihan Ketua Panitia Kegiatan Besar'],
            ['Metode: Full Weighted Product (FWP) - Penilaian Fuzzy'],
            ['Dicetak: ' + laporan.tanggal],
            [],
            ['Rank', 'Kode', 'Nama Calon', 'Jabatan', 'Nilai Akhir (V)', 'Keterangan'],
            ...laporan.rows,
        ];
        if (laporan.kesimpulan) {
            aoa.push([], [laporan.kesimpulan]);
        }

        const sheet = XLSX.utils.aoa_to_sheet(aoa);
        sheet['!cols'] = [{ wch: 6 }, { wch: 8 }, { wch: 22 }, { wch: 28 }, { wch: 15 }, { wch: 18 }];

        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, sheet, 'Hasil FWP');
        return workbook;
    }

    function simpanExcel() {
        XLSX.writeFile(excelWorkbook(), 'laporan-fwp.xlsx');
        App.toast('success', 'File Excel tersimpan.');
    }

    async function pdfDocument() {
        const canvas = await html2canvas(document.querySelector('.print-area'), {
            scale: 2,
            backgroundColor: '#ffffff',
            ignoreElements: (el) => el.classList?.contains('no-print'),
        });

        const pdf = new window.jspdf.jsPDF('p', 'mm', 'a4');
        const pageW = pdf.internal.pageSize.getWidth();
        const pageH = pdf.internal.pageSize.getHeight();
        const imgH = canvas.height * pageW / canvas.width;
        const image = canvas.toDataURL('image/png');

        let offset = 0;
        pdf.addImage(image, 'PNG', 0, offset, pageW, imgH);
        while (imgH + offset > pageH) {
            offset -= pageH;
            pdf.addPage();
            pdf.addImage(image, 'PNG', 0, offset, pageW, imgH);
        }
        return pdf;
    }

    async function simpanPdf() {
        Swal.fire({ title: 'Menyusun PDF…', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
        try {
            (await pdfDocument()).save('laporan-fwp.pdf');
            Swal.close();
            App.toast('success', 'File PDF tersimpan.');
        } catch (err) {
            Swal.fire({ icon: 'error', title: 'Gagal menyimpan PDF', text: 'Coba lagi atau gunakan tombol Cetak.' });
        }
    }
    </script>
<?php endif ?>

<?php require __DIR__ . '/partials/footer.php'; ?>
