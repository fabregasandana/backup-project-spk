import docx

d = docx.Document(r'C:\Users\lenovo\Downloads\Laporan_Project_SPK_Muhammad_Habibi.docx')
out = []
for i, p in enumerate(d.paragraphs):
    t = p.text.strip()
    if t:
        out.append(f"{i} | {p.style.name} | {t[:300]}")
out.append(f"TABLES: {len(d.tables)}")
for ti, tbl in enumerate(d.tables):
    out.append(f"--- table {ti} rows {len(tbl.rows)} cols {len(tbl.columns)}")
    for r in tbl.rows[:12]:
        out.append('    ' + ' | '.join(c.text.strip()[:40] for c in r.cells))

with open(r'C:\xampp\htdocs\spk-fwp\_report\example_paragraphs.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(out))
print('paras:', len(d.paragraphs), 'tables:', len(d.tables))
