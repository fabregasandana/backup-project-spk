import sys
from docx import Document

path, out_path = sys.argv[1], sys.argv[2]
doc = Document(path)

with open(out_path, "w", encoding="utf-8") as out:
    for i, p in enumerate(doc.paragraphs):
        if p.text.strip():
            out.write(f"{i:3} [{p.style.name}] {p.text}\n")
    out.write("\n===== TABLES =====\n")
    for ti, t in enumerate(doc.tables):
        out.write(f"--- table {ti} ({len(t.rows)}x{len(t.columns)}) ---\n")
        for r in t.rows:
            out.write(" | ".join(c.text.strip()[:60] for c in r.cells) + "\n")
print("ok")
