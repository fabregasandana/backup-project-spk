# -*- coding: utf-8 -*-
import os
import win32com.client

ROOT = r'C:\xampp\htdocs\spk-fwp'
DOCX = os.path.join(ROOT, 'Laporan_Project_SPK_Fabregas_Andana.docx')
PDF = os.path.join(ROOT, '_report', 'laporan_check.pdf')

word = win32com.client.Dispatch('Word.Application')
word.Visible = False
word.DisplayAlerts = 0
try:
    doc = word.Documents.Open(DOCX)
    doc.TablesOfContents(1).Update()
    doc.Fields.Update()
    for i in range(1, doc.Sections.Count + 1):
        try:
            doc.Sections(i).Footers(1).Fields.Update()
        except Exception:
            pass
    doc.TablesOfContents(1).Update()
    doc.Save()
    doc.ExportAsFixedFormat(PDF, 17)
    pages = doc.ComputeStatistics(2)  # wdStatisticPages
    print('total pages:', pages)
    toc = doc.TablesOfContents(1)
    text = toc.Range.Text
    doc.Close(False)
finally:
    word.Quit()

with open(os.path.join(ROOT, '_report', 'toc_result.txt'), 'w', encoding='utf-8') as f:
    f.write(text)
print('toc updated')
