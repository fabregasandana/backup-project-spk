# -*- coding: utf-8 -*-
"""Membangun Laporan_Project_SPK_Fabregas_Andana.docx"""
import os
from docx import Document
from docx.enum.section import WD_SECTION_START
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import parse_xml
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROOT = r'C:\xampp\htdocs\spk-fwp'
SHOTS = os.path.join(ROOT, '_report', 'shots')
OUT = os.path.join(ROOT, 'Laporan_Project_SPK_Fabregas_Andana.docx')

M_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NSDECL = f'xmlns:m="{M_NS}" xmlns:w="{W_NS}"'

TNR = 'Times New Roman'


# ---------------------------------------------------------------- OMML utils
def esc(t):
    return t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def mr(t):
    return f'<m:r><m:t xml:space="preserve">{esc(t)}</m:t></m:r>'


def msub(base, s):
    return f'<m:sSub><m:e>{base}</m:e><m:sub>{s}</m:sub></m:sSub>'


def msup(base, s):
    return f'<m:sSup><m:e>{base}</m:e><m:sup>{s}</m:sup></m:sSup>'


def mfrac(n, d):
    return f'<m:f><m:num>{n}</m:num><m:den>{d}</m:den></m:f>'


def mdel(x):
    return f'<m:d><m:e>{x}</m:e></m:d>'


def mnary(ch, sub, sup, e):
    return ('<m:nary><m:naryPr>'
            f'<m:chr m:val="{ch}"/><m:limLoc m:val="undOvr"/>'
            '<m:subHide m:val="0"/><m:supHide m:val="0"/>'
            f'</m:naryPr><m:sub>{sub}</m:sub><m:sup>{sup}</m:sup>'
            f'<m:e>{e}</m:e></m:nary>')


def add_formula(doc, inner):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 1.5
    xml = f'<m:oMath {NSDECL}>{inner}</m:oMath>'
    p._p.append(parse_xml(xml))
    return p


# ---------------------------------------------------------------- helpers
def set_base_style(doc):
    normal = doc.styles['Normal']
    normal.font.name = TNR
    normal.font.size = Pt(12)
    normal.element.rPr.rFonts.set(qn('w:eastAsia'), TNR)
    pf = normal.paragraph_format
    pf.line_spacing = 2.0
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)

    for name, size in (('Heading 1', 12), ('Heading 2', 12), ('Heading 3', 12)):
        st = doc.styles[name]
        st.font.name = TNR
        st.font.size = Pt(size)
        st.font.bold = True
        st.font.color.rgb = RGBColor(0, 0, 0)
        st.element.rPr.rFonts.set(qn('w:eastAsia'), TNR)
        st.paragraph_format.line_spacing = 2.0
        st.paragraph_format.space_before = Pt(0)
        st.paragraph_format.space_after = Pt(0)
        st.paragraph_format.keep_with_next = True


def setup_section(section):
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(4)
    section.left_margin = Cm(4)
    section.bottom_margin = Cm(3)
    section.right_margin = Cm(3)


def page_number(section, fmt=None, start=None):
    section.footer.is_linked_to_previous = False
    p = section.footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 1.0
    for xml in ('<w:fldChar w:fldCharType="begin"/>',
                '<w:instrText xml:space="preserve"> PAGE </w:instrText>',
                '<w:fldChar w:fldCharType="end"/>'):
        p._p.append(parse_xml(f'<w:r {NSDECL}>{xml}</w:r>'))
    sect_pr = section._sectPr
    attrs = ''
    if fmt:
        attrs += f' w:fmt="{fmt}"'
    if start is not None:
        attrs += f' w:start="{start}"'
    if attrs:
        sect_pr.append(parse_xml(f'<w:pgNumType {NSDECL}{attrs}/>'))


def body(doc, text, align=WD_ALIGN_PARAGRAPH.JUSTIFY):
    p = doc.add_paragraph(text)
    p.alignment = align
    return p


def heading(doc, text, level):
    h = doc.add_heading(text, level=level)
    h.alignment = WD_ALIGN_PARAGRAPH.LEFT
    return h


def caption(doc, text):
    p = doc.add_paragraph(text)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(12)
    for run in p.runs:
        run.font.size = Pt(10)
    return p


def image(doc, path, width_cm=14):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.space_before = Pt(12)
    p.add_run().add_picture(path, width=Cm(width_cm))
    return p


def code_block(doc, code):
    for line in code.rstrip('\n').split('\n'):
        p = doc.add_paragraph()
        p.paragraph_format.line_spacing = 1.0
        p.paragraph_format.left_indent = Cm(0.75)
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        run = p.add_run(line if line else ' ')
        run.font.name = TNR
        run.font.size = Pt(10)
        run._r.rPr.rFonts.set(qn('w:cs'), TNR)


def table(doc, rows, widths=None, header=True, size=10, align_first_left=False):
    t = doc.add_table(rows=len(rows), cols=len(rows[0]))
    t.style = 'Table Grid'
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            cell = t.cell(i, j)
            cell.text = ''
            p = cell.paragraphs[0]
            p.paragraph_format.line_spacing = 1.0
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if (align_first_left and j == 0) else WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(str(val))
            run.font.name = TNR
            run.font.size = Pt(size)
            run.font.bold = bool(header and i == 0)
    if widths:
        for j, w in enumerate(widths):
            for i in range(len(rows)):
                t.cell(i, j).width = Cm(w)
    doc.add_paragraph().paragraph_format.line_spacing = 1.0
    return t


def toc_field(doc):
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.5
    begin = parse_xml(f'<w:r {NSDECL}><w:fldChar w:fldCharType="begin"/></w:r>')
    instr = parse_xml(f'<w:r {NSDECL}><w:instrText xml:space="preserve"> TOC \\o "1-2" \\h \\z \\u </w:instrText></w:r>')
    sep = parse_xml(f'<w:r {NSDECL}><w:fldChar w:fldCharType="separate"/></w:r>')
    result = parse_xml(f'<w:r {NSDECL}><w:t>Daftar isi akan terisi otomatis.</w:t></w:r>')
    end = parse_xml(f'<w:r {NSDECL}><w:fldChar w:fldCharType="end"/></w:r>')
    for el in (begin, instr, sep, result, end):
        p._p.append(el)


# ---------------------------------------------------------------- data
ALTIF = [
    ('A1', 'Rangga Prasetyo', 'Ketua Seksi Kepemudaan'),
    ('A2', 'Siti Nurhaliza', 'Sekretaris Karang Taruna'),
    ('A3', 'Budi Santoso', 'Bendahara Karang Taruna'),
    ('A4', 'Dewi Lestari', 'Koordinator Seksi Acara'),
    ('A5', 'Andi Wijaya', 'Ketua Seksi Perlengkapan'),
]
KRIT = [
    ('C1', 'Kepemimpinan', 'Benefit', 30, 0.30),
    ('C2', 'Komunikasi', 'Benefit', 20, 0.20),
    ('C3', 'Komitmen', 'Benefit', 20, 0.20),
    ('C4', 'Pengalaman', 'Benefit', 15, 0.15),
    ('C5', 'Kepercayaan Anggota', 'Benefit', 15, 0.15),
]
SKALA = [
    ('SP', 'Sangat Kurang', '(1,0 ; 1,0 ; 2,0)', '1,3333'),
    ('KP', 'Kurang', '(1,0 ; 2,0 ; 3,0)', '2,0000'),
    ('C', 'Cukup', '(2,0 ; 3,0 ; 4,0)', '3,0000'),
    ('B', 'Baik', '(3,0 ; 4,0 ; 5,0)', '4,0000'),
    ('SB', 'Sangat Baik', '(4,0 ; 5,0 ; 5,0)', '4,6667'),
]
LING = {
    'A1': ['SB', 'B', 'SB', 'C', 'B'],
    'A2': ['B', 'SB', 'B', 'C', 'SB'],
    'A3': ['C', 'C', 'B', 'SB', 'C'],
    'A4': ['SB', 'B', 'C', 'B', 'B'],
    'A5': ['C', 'B', 'SB', 'KP', 'B'],
}
CRISP = {
    'A1': ['4,6667', '4,0000', '4,6667', '3,0000', '4,0000'],
    'A2': ['4,0000', '4,6667', '4,0000', '3,0000', '4,6667'],
    'A3': ['3,0000', '3,0000', '4,0000', '4,6667', '3,0000'],
    'A4': ['4,6667', '4,0000', '3,0000', '4,0000', '4,0000'],
    'A5': ['3,0000', '4,0000', '4,6667', '2,0000', '4,0000'],
}
HASIL = [
    (1, 'A1', 'Rangga Prasetyo', '4,138020', '0,218453', 'Direkomendasikan'),
    (2, 'A2', 'Siti Nurhaliza', '4,043436', '0,213459', ''),
    (3, 'A4', 'Dewi Lestari', '3,955089', '0,208795', ''),
    (4, 'A5', 'Andi Wijaya', '3,410462', '0,180044', ''),
    (5, 'A3', 'Budi Santoso', '3,395407', '0,179249', ''),
]

LISTING_DB = open(os.path.join(ROOT, 'config/database.php'), encoding='utf-8').read()
LISTING_FUZZY = open(os.path.join(ROOT, 'app/FuzzyScale.php'), encoding='utf-8').read()
LISTING_FWP = open(os.path.join(ROOT, 'app/Fwp.php'), encoding='utf-8').read()

LISTING_REPO = """    public function saveAssessment(int $alternatifId, int $kriteriaId, int $skalaId): void
    {
        $stmt = $this->db->prepare(
            'INSERT INTO penilaian (alternatif_id, kriteria_id, skala_id) VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE skala_id = VALUES(skala_id)'
        );
        $stmt->execute([$alternatifId, $kriteriaId, $skalaId]);
    }"""

LISTING_BOOTSTRAP = """    $matrix = [];
    $linguistic = [];
    foreach ($alternatives as $altId => $alt) {
        foreach ($criteria as $kriteriaId => $kriteria) {
            $skalaId = $assessments[$altId . '-' . $kriteriaId] ?? null;
            if ($skalaId === null) {
                return null;
            }
            $skala = $scales[$skalaId];
            $matrix[$altId][$kriteriaId] = FuzzyScale::defuzzify(
                (float) $skala['a'],
                (float) $skala['b'],
                (float) $skala['c']
            );
            $linguistic[$altId][$kriteriaId] = $skala;
        }
    }

    return [
        'criteria' => $criteria,
        'alternatives' => $alternatives,
        'matrix' => $matrix,
        'linguistic' => $linguistic,
        'weights' => Fwp::normalizeWeights(array_map(
            static fn ($c) => (float) $c['bobot'], $criteria)),
        'results' => Fwp::solve($fwCriteria, $matrix),
    ];"""

FOLDER = """spk-fwp/
├── api/               Endpoint JSON (kriteria, alternatif, penilaian)
├── app/               Kelas inti: Fwp, FuzzyScale, Repository, Auth, helpers
├── assets/            CSS neumorphism dan JavaScript (app.js)
├── config/            Koneksi basis data PDO (database.php)
├── partials/          Layout header, sidebar, dan footer
├── sql/               Skema dan data awal basis data (spk_fwp.sql)
├── vendor/            Library Composer (php-lucide)
├── bootstrap.php      Inisialisasi sesi dan fungsi perhitungan bersama
├── index.php          Dashboard
├── login.php          Autentikasi pengguna
├── logout.php         Pengakhiran sesi
├── kriteria.php       Halaman data kriteria dan bobot
├── alternatif.php     Halaman data alternatif (calon)
├── penilaian.php      Halaman matriks penilaian fuzzy
├── perhitungan.php    Halaman langkah perhitungan FWP
└── laporan.php        Halaman laporan hasil dan ekspor PDF/Excel"""


# ---------------------------------------------------------------- build
doc = Document()
set_base_style(doc)

sec1 = doc.sections[0]
setup_section(sec1)

# ===== COVER =====
cover_lines_1 = [
    ('SPK PEMILIHAN CALON KETUA PANITIA KEGIATAN BESAR BERBASIS', 14, True),
    ('PENILAIAN FUZZY DENGAN METODE FULL WEIGHTED PRODUCT (FWP)', 14, True),
    ('(Studi Kasus: Karang Taruna Tingkat Kelurahan)', 12, False),
]
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.line_spacing = 1.5
p.paragraph_format.space_after = Pt(18)
for text, size, bold in cover_lines_1:
    r = p.add_run(text + '\n')
    r.font.size = Pt(size)
    r.font.bold = bold

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.line_spacing = 1.0
p.add_run().add_picture(os.path.join(ROOT, '_report/logo.png'), width=Cm(5))

p = doc.add_paragraph('Disusun Oleh:', style=None)
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.line_spacing = 1.5
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.line_spacing = 1.5
r = p.add_run('Fabregas Andana\n2024020163')
r.font.bold = True

for text in ('PROGRAM STUDI SISTEM INFORMASI',
             'SEKOLAH TINGGI MANAJEMEN INFORMATIKA TRIGUNA DHARMA',
             '2026'):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 1.5
    p.paragraph_format.space_before = Pt(18)
    r = p.add_run(text)
    r.font.bold = True
    r.font.size = Pt(14)

# ===== DAFTAR ISI (section 2, angka romawi) =====
sec2 = doc.add_section(WD_SECTION_START.NEW_PAGE)
setup_section(sec2)
page_number(sec2, fmt='lowerRoman', start=1)

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('DAFTAR ISI')
r.font.bold = True
r.font.size = Pt(12)
toc_field(doc)

# ===== ISI (section 3, angka arab) =====
sec3 = doc.add_section(WD_SECTION_START.NEW_PAGE)
setup_section(sec3)
page_number(sec3, fmt='decimal', start=1)

# --- 1. IDENTITAS PROJECT
heading(doc, '1. IDENTITAS PROJECT', 1)
table(doc, [
    ('Komponen', 'Isi'),
    ('Nama Mahasiswa', 'Fabregas Andana'),
    ('NIM', '2024020163'),
    ('Program Studi', 'Sistem Informasi — STMIK Triguna Dharma'),
    ('Judul Project', 'SPK Pemilihan Calon Ketua Panitia Kegiatan Besar Berbasis Penilaian Fuzzy'),
    ('Objek/Kasus', 'Karang Taruna tingkat kelurahan — pemilihan ketua panitia kegiatan besar tahunan (Peringatan HUT Kemerdekaan RI)'),
    ('Metode SPK', 'Full Weighted Product (FWP) dengan penilaian linguistik fuzzy (Triangular Fuzzy Number)'),
    ('Bahasa Pemrograman/Framework', 'PHP 8.2 (native, tanpa framework), HTML, CSS, JavaScript'),
    ('Database', 'MySQL/MariaDB (XAMPP), basis data: spk_fwp'),
    ('Jumlah Alternatif', '5 calon ketua panitia'),
    ('Jumlah Kriteria', '5 kriteria (semua benefit), total bobot 100 (ternormalisasi 1,00)'),
    ('Output Utama Program', 'Perangkingan alternatif berdasarkan nilai preferensi V beserta laporan cetak dan ekspor PDF/Excel'),
], widths=(4.5, 9.5), align_first_left=True)

# --- 2. RINGKASAN PROGRAM
heading(doc, '2. RINGKASAN PROGRAM', 1)
heading(doc, '2.1 Tujuan Program', 2)
body(doc, 'Program ini bertujuan membantu pengurus Karang Taruna tingkat kelurahan memilih calon ketua '
          'panitia kegiatan besar tahunan — peringatan HUT Kemerdekaan RI — secara objektif menggunakan '
          'metode Full Weighted Product (FWP) terhadap lima calon dengan lima kriteria penilaian. Penilaian '
          'dilakukan dengan istilah bahasa (linguistik) yang dipetakan ke bilangan fuzzy, sehingga keputusan '
          'tidak lagi bergantung pada kira-kira atau preferensi subjektif semata.')
heading(doc, '2.2 Permasalahan yang Diselesaikan', 2)
body(doc, 'Setiap menjelang bulan Agustus, Karang Taruna kelurahan membentuk kepanitiaan besar untuk '
          'peringatan HUT Kemerdekaan RI — mulai dari lomba tingkat RT, kerja bakti, hingga malam puncak '
          'perayaan. Pemilihan ketua panitia selama ini dilakukan melalui musyawarah pengurus yang rawan '
          'dipengaruhi kedekatan personal. Aspek yang dinilai bersifat kualitatif — kepemimpinan, komunikasi, '
          'komitmen, pengalaman, dan kepercayaan warga — sehingga penilai kesulitan mengubah kesan verbal '
          'menjadi angka yang seragam. Selain itu, bobot tiap aspek berbeda dan satu metode perhitungan yang '
          'konsisten belum tersedia, sehingga hasil pemilihan sulit dipertanggungjawabkan.')
heading(doc, '2.3 Pengguna Program', 2)
body(doc, 'Pengguna utama adalah pengurus Karang Taruna kelurahan (ketua, sekretaris, bendahara, dan para '
          'ketua seksi) yang membentuk tim pemilihan panitia. Program dioperasikan melalui browser dengan '
          'login admin berbasis sesi, sehingga hanya pihak berwenang yang dapat mengelola data dan melihat '
          'hasil perhitungan.')
heading(doc, '2.4 Manfaat Program', 2)
body(doc, 'Program menyediakan alat bantu keputusan yang transparan dan dapat ditelusuri: seluruh langkah '
          'perhitungan FWP ditampilkan utuh mulai dari normalisasi bobot hingga nilai preferensi. Proses '
          'penilaian menjadi lebih cepat dan terdokumentasi karena data calon, kriteria, dan penilaian '
          'tersimpan terpusat dalam satu basis data, dan hasilnya dapat langsung dicetak atau diekspor ke '
          'PDF/Excel.')
heading(doc, '2.5 Output Keputusan yang Dihasilkan', 2)
body(doc, 'Program menghasilkan perangkingan lima calon berdasarkan nilai preferensi V beserta rekomendasi '
          'terbaik. Untuk data studi kasus, program merekomendasikan Rangga Prasetyo (Ketua Seksi '
          'Kepemudaan) dengan nilai preferensi V = 0,218453.')

# --- 3. KESESUAIAN DENGAN KONSEP SPK
heading(doc, '3. KESESUAIAN PROGRAM DENGAN KONSEP SPK', 1)
heading(doc, '3.1 Konsep Dasar SPK pada Program', 2)
body(doc, 'Program ini memenuhi konsep Sistem Pendukung Keputusan karena memadukan tiga unsur utama SPK: '
          '(1) data, berupa lima calon, lima kriteria, skala linguistik fuzzy, dan matriks penilaian yang '
          'tersimpan dalam basis data MySQL; (2) model, berupa metode FWP yang diimplementasikan pada kelas '
          'Fwp.php beserta defuzzifikasi Triangular Fuzzy Number pada kelas FuzzyScale.php; serta (3) antarmuka, '
          'berupa menu interaktif untuk mengelola data, menjalankan penilaian, dan membaca hasil. Program tidak '
          'sekadar menyimpan data, melainkan menghasilkan rekomendasi keputusan berupa ranking calon terbaik '
          'beserta seluruh jejak perhitungannya.')
heading(doc, '3.2 Karakteristik SPK pada Program', 2)
table(doc, [
    ('Karakteristik SPK', 'Bukti pada Program'),
    ('Interaktif', 'Pengguna memasukkan dan mengubah data kriteria, alternatif, dan penilaian fuzzy melalui formulir web yang langsung merespons.'),
    ('Fleksibel', 'Kriteria, bobot, dan alternatif dapat ditambah, diubah, dan dihapus tanpa mengubah kode program.'),
    ('Adaptif', 'Perhitungan tidak terikat pada satu organisasi saja; mengganti kriteria, bobot, atau data calon langsung mengubah hasil ranking.'),
    ('Berbasis data dan model', 'Data tersimpan di MySQL (tabel kriteria, alternatif, penilaian, skala_fuzzy, users) dan diolah model FWP pada app/Fwp.php.'),
    ('Mendukung, bukan menggantikan keputusan', 'Hasil perangkingan bersifat rekomendasi; keputusan akhir penetapan ketua panitia tetap berada pada forum musyawarah pengurus Karang Taruna.'),
    ('Transparan/dapat ditelusuri', 'Halaman Perhitungan menampilkan empat langkah FWP secara berurutan sehingga setiap angka dapat diverifikasi.'),
], widths=(4.5, 9.5), align_first_left=True)
heading(doc, '3.3 Komponen Utama SPK pada Program', 2)
table(doc, [
    ('Komponen Utama SPK', 'Implementasi dalam Program'),
    ('Subsistem Data / Data Management', 'Basis data MySQL spk_fwp dengan tabel kriteria (kode, nama, atribut, bobot), alternatif (kode, nama, jabatan), penilaian (peta alternatif-kriteria ke skala), skala_fuzzy (TFN a,b,c), dan users.'),
    ('Subsistem Model / Model Management', 'Kelas Fwp.php (normalisasi bobot, vektor S, vektor V, perankingan) dan FuzzyScale.php (defuzzifikasi (a+b+c)/3).'),
    ('Subsistem Dialog / User Interface', 'Antarmuka web bergaya neumorphism: dashboard, kriteria, alternatif, penilaian fuzzy, perhitungan, dan laporan dengan notifikasi SweetAlert2.'),
    ('Basis Pengetahuan / Aturan Penilaian', 'Lima istilah linguistik (Sangat Kurang s.d. Sangat Baik) yang dipetakan ke Triangular Fuzzy Number dan nilai crisp-nya.'),
], widths=(4.5, 9.5), align_first_left=True)
heading(doc, '3.4 Ketercapaian Target Capaian Pembelajaran SPK', 2)
table(doc, [
    ('Target Capaian', 'Bukti pada Program/Laporan'),
    ('Memahami konsep SPK', 'Program menerapkan struktur data–model–antarmuka SPK (Bab 3).'),
    ('Memahami data dan pembobotan', 'Lima alternatif dan lima kriteria benefit dengan bobot 30/20/20/15/15 yang ternormalisasi menjadi jumlah 1,00 (Bab 5).'),
    ('Menerapkan metode SPK', 'Empat langkah FWP diimplementasikan dan ditampilkan utuh pada halaman perhitungan (Bab 6.6 dan 8.3).'),
    ('Menghasilkan keputusan/ranking', 'Perangkingan lima alternatif dengan nilai preferensi V dan rekomendasi utama (Bab 7).'),
    ('Memvalidasi hasil keputusan', 'Hasil program dibandingkan dengan perhitungan manual independen dan sama persis (Bab 9.2).'),
], widths=(4.5, 9.5), align_first_left=True)

# --- 4. SPESIFIKASI PROGRAM
heading(doc, '4. SPESIFIKASI PROGRAM', 1)
heading(doc, '4.1 Spesifikasi Teknis', 2)
table(doc, [
    ('Komponen', 'Keterangan'),
    ('Bahasa Pemrograman', 'PHP 8.2 (native, arsitektur modular tanpa framework)'),
    ('Library/Framework', 'SweetAlert2 (notifikasi dan modal), php-lucide (ikon SVG via Composer), html2canvas + jsPDF (ekspor PDF), SheetJS (ekspor Excel)'),
    ('Database', 'MySQL/MariaDB (paket XAMPP), basis data spk_fwp'),
    ('Tools Editor', 'Visual Studio Code'),
    ('Browser/Runtime', 'Google Chrome / Microsoft Edge'),
    ('Sistem Operasi', 'Microsoft Windows (XAMPP sebagai server lokal)'),
    ('Antarmuka', 'Neumorphism, palet Soft Cool Gray + Soft Blue, responsif hingga layar ponsel'),
], widths=(4.5, 9.5), align_first_left=True)
heading(doc, '4.2 Struktur Folder Program', 2)
code_block(doc, FOLDER)

# --- 5. DATA
heading(doc, '5. DATA YANG DIGUNAKAN DALAM PROGRAM', 1)
heading(doc, '5.1 Data Alternatif', 2)
body(doc, 'Alternatif merupakan lima calon ketua panitia kegiatan besar Karang Taruna yang aktif pada '
          'struktur kepengurusan organisasi. Data diambil dari struktur kepengurusan Karang Taruna tingkat '
          'kelurahan.')
table(doc, [('Kode', 'Nama Calon', 'Jabatan')] + [(k, n, j) for k, n, j in ALTIF],
      widths=(1.8, 6, 6.2))
heading(doc, '5.2 Data Kriteria dan Bobot', 2)
body(doc, 'Kelima kriteria bersifat benefit (semakin tinggi semakin baik) dengan total bobot 100 yang '
          'dinormalisasi menjadi jumlah 1,00. Bobot kepemimpinan terbesar karena ketua panitia paling '
          'dituntut mengarahkan seluruh divisi.')
table(doc, [
    ('Kode', 'Nama Kriteria', 'Atribut', 'Bobot', 'W Normalisasi'),
] + [(k, n, a, str(b), f'{w:.2f}'.replace('.', ',')) for k, n, a, b, w in KRIT],
    widths=(1.6, 5.2, 2.2, 2.2, 2.8))
heading(doc, '5.3 Skala Linguistik Fuzzy', 2)
body(doc, 'Penilaian tidak diberikan dalam angka mentah, melainkan istilah bahasa yang dipetakan ke '
          'Triangular Fuzzy Number (a, b, c). Setiap TFN didefuzzifikasi menjadi satu nilai crisp dengan '
          'rumus rata-rata ketiga titiknya.')
table(doc, [('Kode', 'Istilah', 'TFN (a, b, c)', 'Nilai Crisp')] + SKALA,
      widths=(1.8, 5.4, 4.4, 2.4))
heading(doc, '5.4 Matriks Keputusan (Penilaian Linguistik)', 2)
body(doc, 'Matriks berikut adalah hasil penilaian tim pemilihan terhadap kelima calon untuk setiap kriteria '
          'dalam bentuk istilah linguistik.')
table(doc, [
    ('Alternatif', 'C1', 'C2', 'C3', 'C4', 'C5'),
] + [(f'{kode} · {nama}',) + tuple(LING[kode]) for kode, nama, _ in ALTIF],
    widths=(6, 1.6, 1.6, 1.6, 1.6, 1.6))
heading(doc, '5.5 Matriks Crisp Hasil Defuzzifikasi', 2)
body(doc, 'Setelah setiap istilah diubah menjadi nilai crisp dengan rumus (a + b + c) / 3, diperoleh matriks '
          'keputusan yang siap dihitung dengan metode FWP.')
table(doc, [
    ('Alternatif', 'C1', 'C2', 'C3', 'C4', 'C5'),
] + [(f'{kode} · {nama}',) + tuple(CRISP[kode]) for kode, nama, _ in ALTIF],
    widths=(6, 1.6, 1.6, 1.6, 1.6, 1.6))

# --- 6. CARA KERJA DAN PENGGUNAAN
heading(doc, '6. CARA KERJA DAN PENGGUNAAN PROGRAM', 1)
SIX = [
    ('6.1 Halaman Login / Akses Awal Program', '6-1-login.png', 'Gambar 6.1 untuk Halaman Login',
     'Program diakses melalui browser pada alamat localhost/spk-fwp. Seluruh halaman internals dilindungi '
     'sesi: pengguna yang belum login otomatis dialihkan ke halaman login. Pengguna memasukkan username dan '
     'password admin; kata sandi disimpan sebagai hash (password_hash) dan diverifikasi dengan '
     'password_verify sehingga aman dari pembacaan balik. Setelah login berhasil, pengguna diarahkan ke '
     'dashboard.'),
    ('6.2 Dashboard / Halaman Utama', '6-2-dashboard.png', 'Gambar 6.2 untuk Dashboard',
     'Dashboard merangkum jumlah kriteria, jumlah alternatif, dan kelengkapan penilaian dalam kartu statistik '
     'bergaya neumorphism, sehingga pengguna langsung mengetahui apakah data sudah siap dihitung. Tersedia '
     'pintasan menuju halaman perhitungan dan laporan.'),
    ('6.3 Menu Data Kriteria', '6-3-kriteria.png', 'Gambar 6.3 untuk Data Kriteria dan Bobot',
     'Menu ini menampilkan daftar kriteria beserta atribut (benefit/cost), bobot mentah, dan bobot '
     'ternormalisasi. Kriteria dapat ditambah, diedit, dan dihapus melalui modal SweetAlert2 dengan validasi '
     'nomor urut kode otomatis (C1, C2, dst.) dan bobot numerik. Perubahan bobot langsung memengaruhi hasil '
     'perhitungan berikutnya.'),
    ('6.4 Menu Data Alternatif', '6-4-alternatif.png', 'Gambar 6.4 untuk Data Alternatif',
     'Menu ini mengelola lima calon ketua panitia beserta jabatannya di organisasi. Kode alternatif dibuat '
     'otomatis (A1, A2, dst.) dan datanya menjadi baris pada matriks keputusan.'),
    ('6.5 Menu Penilaian Fuzzy', '6-5-penilaian.png', 'Gambar 6.5 untuk Penilaian Fuzzy',
     'Halaman ini memuat tabel skala linguistik (SP, KP, C, B, SB beserta TFN dan nilai crisp-nya) sebagai '
     'acuan penilai, diikuti matriks penilaian alternatif terhadap kriteria. Setiap sel menampilkan lima '
     'chip pilihan istilah; satu klik langsung menyimpan penilaian melalui endpoint JSON dengan token CSRF, '
     'sehingga tidak ada tombol simpan terpisah.'),
    ('6.6 Menu Proses Perhitungan', '6-6-perhitungan.png', 'Gambar 6.6 untuk Langkah Perhitungan FWP',
     'Halaman Perhitungan FWP menampilkan empat langkah secara berurutan: Langkah 1 normalisasi bobot '
     '(Wj = wj / Σwj), Langkah 2 defuzzifikasi penilaian menjadi matriks crisp, Langkah 3 vektor S dengan '
     'perkalian bernilai pangkat (S_i = Π r_ij^Wj) yang menuliskan angka setiap alternatif secara lengkap, '
     'dan Langkah 4 vektor V (V_i = S_i / ΣS_i) sekaligus perankingan. Seluruh tabel dapat diperiksa langkah '
     'demi langkah sehingga perhitungan transparan.'),
    ('6.7 Menu Hasil Ranking / Laporan', '6-7-laporan.png', 'Gambar 6.7 untuk Laporan Hasil dan Ekspor PDF/Excel',
     'Laporan menampilkan tabel peringkat lima calon dengan nilai preferensi V dan keterangan '
     '"Direkomendasikan" pada peringkat pertama, diikuti kalimat kesimpulan. Tersedia tiga tombol keluaran: '
     'Cetak (dialog cetak browser), Simpan PDF (dibangun di sisi peramban dengan html2canvas dan jsPDF), '
     'serta Simpan Excel (SheetJS) sehingga laporan dapat diarsipkan dan didistribusikan.'),
]
for title, img, cap, expl in SIX:
    heading(doc, title, 2)
    image(doc, os.path.join(SHOTS, img))
    caption(doc, cap)
    body(doc, expl)

# --- 7. HASIL PROGRAM
heading(doc, '7. HASIL PROGRAM DAN PENJELASAN OUTPUT', 1)
heading(doc, '7.1 Rumus Lengkap Metode FWP', 2)
body(doc, 'Full Weighted Product menghitung nilai preferensi setiap alternatif dengan mengalikan seluruh '
          'atribut yang dipangkatkan bobot ternormalisasinya. Tahapan rumusnya sebagai berikut.')
body(doc, 'Langkah 1 — Normalisasi bobot, dengan wj bobot asli kriteria ke-j dan n jumlah kriteria:')
add_formula(doc, msub(mr('W'), mr('j')) + mr('=') +
            mfrac(msub(mr('w'), mr('j')),
                  mnary('∑', mr('k=1'), mr('n'), msub(mr('w'), mr('k')))))
body(doc, 'Langkah 2 — Defuzzifikasi Triangular Fuzzy Number (a, b, c) menjadi nilai crisp:')
add_formula(doc, mr('d = ') + mfrac(mr('a + b + c'), mr('3')))
body(doc, 'Langkah 3 — Vektor S. Untuk kriteria benefit digunakan r_ij = x_ij, dan untuk kriteria cost '
          'digunakan r_ji = x_ji / x_ij dengan pangkat negatif:')
add_formula(doc, msub(mr('S'), mr('i')) + mr('=') +
            mnary('∏', mr('j=1'), mr('n'),
                  msup(mdel(msub(mr('r'), mr('ij'))), msub(mr('W'), mr('j')))))
add_formula(doc, msub(mr('S'), mr('i')) + mr('=') +
            mnary('∏', mr('j=1'), mr('n'),
                  msup(mdel(msub(mr('r'), mr('ji'))), mr('−') + msub(mr('W'), mr('j')))))
body(doc, 'Langkah 4 — Vektor preferensi V, dengan m jumlah alternatif:')
add_formula(doc, msub(mr('V'), mr('i')) + mr('=') +
            mfrac(msub(mr('S'), mr('i')),
                  mnary('∑', mr('i=1'), mr('m'), msub(mr('S'), mr('i')))))
body(doc, 'Alternatif dengan nilai V terbesar menempati peringkat pertama dan direkomendasikan menjadi '
          'ketua panitia. Karena seluruh kriteria pada kasus ini bersifat benefit, rumus Langkah 3 yang '
          'dipakai adalah bentuk pertama.')
heading(doc, '7.2 Hasil Perhitungan Program', 2)
body(doc, 'Berdasarkan matriks crisp pada Bab 5.5 dan bobot ternormalisasi pada Bab 5.2, program '
          'menghasilkan perangkingan sebagai berikut.')
table(doc, [
    ('Rank', 'Kode', 'Nama Calon', 'Vektor S', 'Nilai V', 'Keterangan'),
] + [(r[0], r[1], r[2], r[3], r[4], r[5]) for r in HASIL],
    widths=(1.5, 1.5, 4.6, 2.6, 2.2, 2.6))
body(doc, 'Program merekomendasikan Rangga Prasetyo sebagai calon ketua panitia terbaik dengan nilai '
          'preferensi V = 0,218453 (S = 4,138020). Calon ini unggul karena profil penilaiannya paling '
          'merata pada bobot terbesar: kepemimpinan dan komitmen dinilai Sangat Baik (crisp 4,6667) dengan '
          'komunikasi dan kepercayaan anggota Baik (4,0000). Siti Nurhaliza mengikuti di peringkat kedua '
          '(V = 0,213459) berkat komunikasi dan kepercayaan anggota Sangat Baik, namun komitmen hanya '
          'ternilai Cukup pada bobot yang sama. Dewi Lestari (0,208795), Andi Wijaya (0,180044), dan Budi '
          'Santoso (0,179249) menyusul; Budi berada di peringkat terakhir meskipun pengalamannya Sangat '
          'Baik karena tiga kriteria berbobot besar lainnya hanya Cukup. Jumlah seluruh nilai V tepat 1,00 '
          'sebagai bukti konsistensi pembagian.')

# --- 8. LISTING PROGRAM
heading(doc, '8. LISTING PROGRAM DAN PENJELASAN FUNGSI KODE', 1)
heading(doc, '8.1 Kode Koneksi Database (config/database.php)', 2)
code_block(doc, LISTING_DB)
body(doc, 'Kelas Database membuat satu koneksi PDO ke basis data spk_fwp dan menyimpannya pada properti '
          'statik (pola singleton) sehingga seluruh halaman memakai koneksi yang sama. Mode '
          'ERRMODE_EXCEPTION membuat kesalahan query langsung terdeteksi, dan ATTR_EMULATE_PREPARES=false '
          'memastikan prepared statement dijalankan asli oleh MySQL.')
heading(doc, '8.2 Kode Defuzzifikasi Skala Fuzzy (app/FuzzyScale.php)', 2)
code_block(doc, LISTING_FUZZY)
body(doc, 'Method defuzzify() mengubah satu istilah linguistik yang diwakili tiga titik TFN (a, b, c) '
          'menjadi satu angka crisp dengan rata-rata ketiganya, contoh Sangat Baik (4,0; 5,0; 5,0) menjadi '
          '4,6667. Nilai crisp inilah yang masuk ke matriks keputusan.')
heading(doc, '8.3 Kode Perhitungan Metode SPK (app/Fwp.php)', 2)
code_block(doc, LISTING_FWP)
body(doc, 'Method solve() menjalankan seluruh algoritme FWP: normalisasiWeights() membagi tiap bobot '
          'dengan total bobot sehingga jumlahnya 1; kemudian untuk setiap alternatif dihitung vektor S '
          'sebagai perkalian nilai kriteria yang dipangkatkan bobot ternormalisasi (pangkat negatif untuk '
          'kriteria cost). Terakhir setiap S dibagi jumlah seluruh S menjadi nilai preferensi V, dan '
          'assignRanks() mengurutkan alternatif dari V terbesar.')
heading(doc, '8.4 Kode Penyimpanan Penilaian (app/Repository.php)', 2)
code_block(doc, LISTING_REPO)
body(doc, 'Penilaian disimpan dengan perintah INSERT ... ON DUPLICATE KEY UPDATE sehingga satu klik pada '
          'matriks penilaian cukup mengirim satu baris data: jika pasangan alternatif-kriteria sudah punya '
          'nilai maka skala diganti, jika belum maka baris baru dibuat. Prepared statement melindungi dari '
          'SQL injection.')
heading(doc, '8.5 Kode Penyusunan Data Perhitungan (bootstrap.php)', 2)
code_block(doc, LISTING_BOOTSTRAP)
body(doc, 'Fungsi buildCalculation() menyusun paket data lengkap untuk halaman perhitungan dan laporan: '
          'matriks crisp hasil defuzzifikasi, istilah linguistik tiap sel, bobot ternormalisasi, dan hasil '
          'FWP. Fungsi mengembalikan null bila masih ada sel penilaian yang kosong sehingga halaman '
          'melaporkan status "belum ada hasil" alih-alih angka yang salah.')
heading(doc, '8.6 Kode Tampilan Ranking (laporan.php)', 2)
code_block(doc, """$calc = buildCalculation();
...
<?php foreach ($calc['results'] as $altId => $res): $a = $calc['alternatives'][$altId]; ?>
    <tr>
        <td><span class="badge rank">#<?= $res['rank'] ?></span></td>
        <td><?= e($a['kode']) ?></td>
        <td><strong><?= e($a['nama']) ?></strong></td>
        <td class="muted"><?= e($a['jabatan']) ?></td>
        <td><strong><?= num($res['v'], 6) ?></strong></td>
        <td><?= $res['rank'] === 1 ? 'Direkomendasikan' : '' ?></td>
    </tr>
<?php endforeach ?>""")
body(doc, 'Karena hasil dari Fwp::solve() sudah terurut menurun berdasarkan nilai V, tabel laporan cukup '
          'menampilkannya berurutan dan memberi keterangan "Direkomendasikan" pada peringkat pertama. '
          'Nilai V ditampilkan enam desimal dengan pemisah koma.')

# --- 9. PENGUJIAN
heading(doc, '9. PENGUJIAN DAN VALIDASI PROGRAM', 1)
heading(doc, '9.1 Pengujian Fungsional', 2)
table(doc, [
    ('No', 'Pengujian', 'Langkah', 'Hasil', 'Status'),
    ('1', 'Login', 'Masukkan username dan password admin', 'Sesi dibuat, dialihkan ke dashboard', 'Valid'),
    ('2', 'Logout', 'Klik tombol keluar', 'Sesi dihancurkan, kembali ke login', 'Valid'),
    ('3', 'CRUD Kriteria', 'Tambah, ubit, hapus kriteria melalui modal', 'Tabel terbarui, kode otomatis, bobot tervalidasi', 'Valid'),
    ('4', 'CRUD Alternatif', 'Tambah, ubah, hapus calon', 'Kode A1..A5 dibuat otomatis', 'Valid'),
    ('5', 'Penilaian Fuzzy', 'Klik chip istilah pada matriks', 'Penilaian tersimpan otomatis dan bertahan setelah reload', 'Valid'),
    ('6', 'Perhitungan FWP', 'Buka halaman perhitungan', 'Empat langkah tampil dan angkanya sesuai hitungan manual', 'Valid'),
    ('7', 'Laporan', 'Buka halaman laporan', 'Ranking, kesimpulan, dan tombol cetak tampil', 'Valid'),
    ('8', 'Ekspor PDF/Excel', 'Klik Simpan PDF dan Simpan Excel', 'Berkas laporan-fwp.pdf dan laporan-fwp.xlsx terunduh', 'Valid'),
], widths=(1, 3, 4.2, 4.2, 1.6))
heading(doc, '9.2 Validasi Hasil Perhitungan', 2)
body(doc, 'Validasi dilakukan dengan menghitung ulang seluruh proses FWP secara independen menggunakan '
          'skrip Python berpresisi tinggi (modul Decimal). Contoh perhitungan manual untuk alternatif A1 '
          '(Rangga Prasetyo) dengan nilai crisp [4,6667; 4,0000; 4,6667; 3,0000; 4,0000] dan bobot '
          'ternormalisasi [0,30; 0,20; 0,20; 0,15; 0,15]:')
code_block(doc, """S1 = 4,6667^0,3000 × 4,0000^0,2000 × 4,6667^0,2000 × 3,0000^0,1500 × 4,0000^0,1500
   = 1,587548 × 1,319508 × 1,360790 × 1,179148 × 1,231144
   = 4,138020

ΣS = 4,138020 + 4,043436 + 3,395407 + 3,955089 + 3,410462 = 18,942414

V1 = S1 / ΣS = 4,138020 / 18,942414 = 0,218453""")
body(doc, 'Perhitungan manual seluruh alternatif menghasilkan nilai yang identik dengan output program:')
table(doc, [
    ('Alternatif', 'V hasil program', 'V perhitungan manual', 'Selisih'),
    ('A1 — Rangga Prasetyo', '0,218453', '0,218453', '0'),
    ('A2 — Siti Nurhaliza', '0,213459', '0,213459', '0'),
    ('A3 — Budi Santoso', '0,179249', '0,179249', '0'),
    ('A4 — Dewi Lestari', '0,208795', '0,208795', '0'),
    ('A5 — Andi Wijaya', '0,180044', '0,180044', '0'),
], widths=(5.4, 3, 3.4, 2.2))
body(doc, 'Hasil perhitungan program dan perhitungan manual sama persis (selisih 0), sehingga validitas '
          'perhitungan program terbukti.')

# --- 10. KENDALA
heading(doc, '10. KENDALA DAN PENGEMBANGAN PROGRAM', 1)
body(doc, 'Kendala: (1) penilaian kualitatif tim pemilihan awalnya ditulis dalam skala angka bebas sehingga '
          'tidak konsisten — kendala ini diselesaikan dengan memaksa istilah linguistik fuzzy (SP s.d. SB) '
          'yang seragam melalui chip pilihan; (2) pemetaan istilah ke Triangular Fuzzy Number menuntut '
          'kesepakatan bersama agar tafsir "Baik" dan "Sangat Baik" tidak berbeda antar penilai; (3) '
          'perhitungan pangkat desimal pada metode FWP rawan galat pembulatan, sehingga nilai ditampilkan '
          'enam desimal dan divalidasi ulang dengan komputasi presisi tinggi.')
body(doc, 'Saran pengembangan: (1) agregasi penilaian banyak penilai (rata-rata kelompok per sel matriks) '
          'agar subjektivitas tunggal berkurang; (2) ekspor jejak perhitungan lengkap ke PDF; (3) '
          'perbandingan antarmetode (SAW, TOPSIS) untuk analisis sensitivitas bobot; (4) manajemen '
          'multi-peran (admin, penilai, pengambil keputusan); dan (5) penguncian periode penilaian agar '
          'hasil yang telah disahkan tidak dapat diubah.')

# --- 11. KESIMPULAN
heading(doc, '11. KESIMPULAN', 1)
body(doc, 'Program SPK Pemilihan Calon Ketua Panitia Kegiatan Besar Berbasis Penilaian Fuzzy berhasil '
          'dibangun menggunakan PHP native dan MySQL dengan metode Full Weighted Product. Program membantu '
          'pengurus Karang Taruna kelurahan mengambil keputusan secara objektif, transparan, dan dapat '
          'ditelusuri atas lima calon terhadap lima kriteria dengan total bobot ternormalisasi 1,00. Penilaian '
          'linguistik fuzzy dipetakan ke Triangular Fuzzy Number lalu didefuzzifikasi menjadi nilai crisp '
          'sebelum dihitung FWP, sehingga kesan verbal penilai dapat diperbandingkan secara adil. Hasil '
          'perhitungan menempatkan Rangga Prasetyo sebagai rekomendasi utama dengan nilai preferensi '
          'V = 0,218453, diikuti Siti Nurhaliza (0,213459) dan Dewi Lestari (0,208795). Validasi terhadap '
          'perhitungan manual menunjukkan nilai yang identik, sehingga program layak digunakan sebagai '
          'alat bantu pengambilan keputusan pembentukan kepanitiaan kegiatan besar di lingkungan organisasi '
          'kemasyarakatan.')

# --- 12. DAFTAR PUSTAKA
heading(doc, '12. DAFTAR PUSTAKA', 1)
REFS = [
    'Sabekti, Y., Mursyidah, H., & Abdullah, S. (2026). Sistem pendukung keputusan berbasis metode '
    'weighted product untuk memprioritaskan bantuan rumah tidak layak huni (RTLH). JUMISTIK: Jurnal '
    'Manajemen Informatika, Sistem Informasi dan Teknologi Komputer, 5(1). '
    'https://doi.org/10.70247/jumistik.v5i1.250',
    'Sihombing, C. P. B., Nunes, M. D., & Sipayung, S. P. (2024). Pemilihan karyawan terbaik untuk promosi '
    'jabatan dengan metode weighted product (WP). KAKIFIKOM: Jurnal Kolektif Ilmu Komputer, 6(1), 15–18.',
    'Wike, W. N., Jauhari, M. N., & Nasichuddin, A. (2023). Penggabungan metode fuzzy simple additive '
    'weighting dengan rank order centroid sebagai pendukung keputusan penilaian kemiskinan di Jawa Timur. '
    'JRMM: Jurnal Riset Mahasiswa Matematika, 3(1). https://doi.org/10.18860/jrmm.v3i1.22340',
    'Yoon, K., & Hwang, C. L. (1981). Multiple attribute decision making: Methods and applications. '
    'Springer-Verlag.',
    'Zimmermann, H.-J. (2001). Fuzzy set theory—and its applications (4th ed.). Kluwer Academic Publishers.',
]
for ref in REFS:
    p = doc.add_paragraph(ref)
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.left_indent = Cm(1.25)
    p.paragraph_format.first_line_indent = Cm(-1.25)

doc.save(OUT)
print('saved:', OUT)
