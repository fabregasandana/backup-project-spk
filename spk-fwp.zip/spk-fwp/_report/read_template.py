import docx

d = docx.Document(r'C:\Users\lenovo\Downloads\Format_Laporan_Project_SPK.docx')
out = []
for i, p in enumerate(d.paragraphs):
    t = p.text.strip()
    if t:
        out.append(f"{i} | {p.style.name} | {t[:250]}")
out.append(f"TABLES: {len(d.tables)}")
for ti, tbl in enumerate(d.tables):
    out.append(f"--- table {ti} rows {len(tbl.rows)}")
    for r in tbl.rows[:8]:
        out.append('    ' + ' | '.join(c.text.strip()[:45] for c in r.cells))

with open(r'C:\xampp\htdocs\spk-fwp\_report\template_paragraphs.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(out))
print('DONE')
