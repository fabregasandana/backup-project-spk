<?php

declare(strict_types=1);

define('PUBLIC_PAGE', true);
require_once __DIR__ . '/../bootstrap.php';

$calc = buildCalculation();
if ($calc === null) {
    exit("Data belum lengkap\n");
}

echo "== Kriteria ==\n";
foreach ($calc['criteria'] as $c) {
    echo $c['kode'], ' | ', $c['nama'], ' | ', $c['atribut'], ' | bobot ', $c['bobot'], "\n";
}
echo "\n== Skala Fuzzy & Crisp ==\n";
foreach (repo()->scales() as $s) {
    echo $s['kode'], ' ', $s['label'], ' (', $s['a'], ',', $s['b'], ',', $s['c'], ') => ', FuzzyScale::defuzzify((float) $s['a'], (float) $s['b'], (float) $s['c']), "\n";
}
echo "\n== Matriks Crisp (hasil defuzzifikasi) ==\n";
foreach ($calc['alternatives'] as $altId => $alt) {
    echo $alt['kode'], ' ', $alt['nama'], ' [', $alt['jabatan'], '] : ',
        implode(', ', array_map(static fn ($v) => number_format($v, 4, ',', '.'), $calc['matrix'][$altId])), "\n";
}
echo "\n== Bobot ternormalisasi ==\n";
echo implode(', ', array_map(static fn ($w) => number_format($w, 4, ',', '.'), $calc['weights'])), "\n";

echo "\n== Hasil S dan V ==\n";
foreach ($calc['results'] as $altId => $res) {
    $alt = $calc['alternatives'][$altId];
    echo 'Rank ', $res['rank'], ' | ', $alt['nama'], ' | S=', number_format($res['s'], 6, ',', '.'), ' | V=', number_format($res['v'], 6, ',', '.'), "\n";
}
