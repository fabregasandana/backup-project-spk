const App = (() => {
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';

    async function request(url, data) {
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf },
            body: JSON.stringify(data),
        });
        return res.json();
    }

    function toast(icon, title) {
        Swal.fire({ toast: true, position: 'top-end', icon, title, showConfirmButton: false, timer: 2200, timerProgressBar: true });
    }

    function confirm(message, onYes) {
        Swal.fire({
            title: 'Yakin?', text: message, icon: 'warning',
            showCancelButton: true, confirmButtonText: 'Ya, lanjutkan', cancelButtonText: 'Batal',
            confirmButtonColor: '#4f74bd', cancelButtonColor: '#a0a8b8',
        }).then((r) => r.isConfirmed && onYes());
    }

    // Render a create/edit form inside a SweetAlert modal.
    function form({ title, fields, values = {}, onSubmit }) {
        const html = fields.map((f) => {
            const val = values[f.name] ?? f.default ?? '';
            if (f.type === 'select') {
                const opts = f.options.map((o) => `<option value="${o.value}" ${String(o.value) === String(val) ? 'selected' : ''}>${o.label}</option>`).join('');
                return `<label class="swal-label">${f.label}</label><select id="sw-${f.name}" class="swal2-select">${opts}</select>`;
            }
            return `<label class="swal-label">${f.label}</label><input id="sw-${f.name}" class="swal2-input" type="${f.type || 'text'}" value="${val}" ${f.attrs || ''}>`;
        }).join('');

        Swal.fire({
            title, html, showCancelButton: true, confirmButtonText: 'Simpan', cancelButtonText: 'Batal',
            confirmButtonColor: '#4f74bd', cancelButtonColor: '#a0a8b8', focusConfirm: false, width: 480,
            preConfirm: () => {
                const payload = {};
                for (const f of fields) {
                    const el = document.getElementById(`sw-${f.name}`);
                    if (f.required && !el.value.trim()) { Swal.showValidationMessage(`${f.label} wajib diisi`); return false; }
                    payload[f.name] = el.value.trim();
                }
                return payload;
            },
        }).then((r) => r.isConfirmed && onSubmit(r.value));
    }

    function bindSidebar() {
        document.getElementById('toggleSidebar')?.addEventListener('click', () => {
            const sidebar = document.querySelector('.sidebar');
            const mobile = window.matchMedia('(max-width: 820px)').matches;
            sidebar.classList.toggle(mobile ? 'open' : 'collapsed');
        });
    }

    return { request, toast, confirm, form, bindSidebar };
})();

document.addEventListener('DOMContentLoaded', App.bindSidebar);
