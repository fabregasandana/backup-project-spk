<?php

declare(strict_types=1);

define('PUBLIC_PAGE', true);
require_once __DIR__ . '/bootstrap.php';

if (Auth::check()) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf'] ?? '';
    if (!hash_equals(csrf_token(), is_string($token) ? $token : '')) {
        $error = 'Sesi tidak valid, silakan coba lagi.';
    } else {
        $username = trim((string) ($_POST['username'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');

        if ($username === '' || $password === '') {
            $error = 'Username dan password wajib diisi.';
        } elseif (Auth::attempt($username, $password)) {
            header('Location: index.php');
            exit;
        } else {
            $error = 'Username atau password salah.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= csrf_token() ?>">
    <title>Login &middot; SPK Ketua Panitia</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-body">
    <div class="login-card">
        <div class="brand-logo login-logo"><?= icon('crown', 'icon', 30) ?></div>
        <h1 class="login-title">SPK FWP</h1>
        <p class="login-subtitle">Pemilihan Ketua Panitia &middot; Full Weighted Product</p>

        <?php if ($error !== ''): ?>
            <div class="login-error"><?= icon('circle-alert', 'icon', 18) ?> <?= e($error) ?></div>
        <?php endif ?>

        <form method="post" action="login.php" autocomplete="off">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
            <div class="field">
                <label for="username">Username</label>
                <div class="input-icon-wrap">
                    <?= icon('user', 'icon', 18) ?>
                    <input class="input has-icon" type="text" id="username" name="username"
                           placeholder="Masukkan username" required autofocus
                           value="<?= e($_POST['username'] ?? '') ?>">
                </div>
            </div>
            <div class="field">
                <label for="password">Password</label>
                <div class="input-icon-wrap">
                    <?= icon('lock', 'icon', 18) ?>
                    <input class="input has-icon" type="password" id="password" name="password"
                           placeholder="Masukkan password" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary login-btn">
                <?= icon('log-in', 'icon', 18) ?> Masuk
            </button>
        </form>

        <div class="login-footer">Metode Full Weighted Product &middot; Penilaian Fuzzy</div>
    </div>
</body>
</html>
