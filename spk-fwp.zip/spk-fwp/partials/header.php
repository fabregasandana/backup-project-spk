<?php
$menus = [
    'index' => ['label' => 'Dashboard', 'icon' => 'layout-dashboard', 'url' => 'index.php'],
    'kriteria' => ['label' => 'Kriteria', 'icon' => 'list-checks', 'url' => 'kriteria.php'],
    'alternatif' => ['label' => 'Alternatif', 'icon' => 'users', 'url' => 'alternatif.php'],
    'penilaian' => ['label' => 'Penilaian Fuzzy', 'icon' => 'star', 'url' => 'penilaian.php'],
    'perhitungan' => ['label' => 'Perhitungan FWP', 'icon' => 'calculator', 'url' => 'perhitungan.php'],
    'laporan' => ['label' => 'Laporan', 'icon' => 'file-text', 'url' => 'laporan.php'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= csrf_token() ?>">
    <title><?= e($pageTitle ?? 'SPK FWP') ?> &middot; SPK Ketua Panitia</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="layout">
    <aside class="sidebar">
        <div class="brand">
            <div class="brand-logo"><?= icon('crown', 'icon', 24) ?></div>
            <div>
                <strong>SPK FWP</strong>
                <small>Pemilihan Ketua Panitia</small>
            </div>
        </div>
        <nav class="menu">
            <?php foreach ($menus as $key => $menu): ?>
                <a href="<?= $menu['url'] ?>" class="menu-item <?= ($activeMenu ?? '') === $key ? 'active' : '' ?>">
                    <?= icon($menu['icon']) ?>
                    <span><?= $menu['label'] ?></span>
                </a>
            <?php endforeach ?>
        </nav>
        <div class="sidebar-footer">Metode Full Weighted Product &middot; Penilaian Fuzzy</div>
    </aside>

    <main class="content">
        <header class="topbar">
            <button class="icon-btn" id="toggleSidebar" aria-label="Menu"><?= icon('menu') ?></button>
            <h1><?= e($pageTitle ?? 'Dashboard') ?></h1>
            <?php if ($user = Auth::user()): ?>
                <div class="user-chip"><?= icon('user', 'icon', 16) ?> <?= e($user['nama']) ?></div>
            <?php endif ?>
            <a class="btn-logout" href="logout.php" title="Keluar" onclick="return confirm('Yakin ingin keluar?')"><?= icon('log-out') ?></a>
            <div class="topbar-badge"><?= icon('sparkles', 'icon', 16) ?> Fuzzy Linguistik</div>
        </header>
        <div class="page">
