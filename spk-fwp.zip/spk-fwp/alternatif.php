<?php
require_once __DIR__ . '/bootstrap.php';

$pageTitle = 'Data Calon';
$activeMenu = 'alternatif';
$alternatives = repo()->alternatives();
$assessments = repo()->assessments();
$criteriaCount = count(repo()->criteria());

require __DIR__ . '/partials/header.php';
?>

<div class="card">
    <div class="card-head">
        <div>
            <div class="card-title"><?= icon('users') ?> Calon Ketua Panitia</div>
            <p class="hint">Daftar kandidat yang akan dinilai pada kelima aspek fuzzy.</p>
        </div>
        <button class="btn" onclick="openForm()"><?= icon('user-plus', 'icon', 17) ?> Tambah Calon</button>
    </div>

    <?php if ($alternatives === []): ?>
        <div class="empty"><?= icon('inbox', 'icon', 40) ?><p>Belum ada calon. Klik "Tambah Calon".</p></div>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr><th>Kode</th><th>Nama</th><th>Jabatan di Organisasi</th><th>Penilaian Lengkap</th><th>Aksi</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($alternatives as $id => $a):
                        $done = count(array_filter(array_keys($assessments), fn ($k) => str_starts_with($k, $id . '-')));
                    ?>
                        <tr>
                            <td><strong><?= e($a['kode']) ?></strong></td>
                            <td><?= e($a['nama']) ?></td>
                            <td class="muted"><?= e($a['jabatan']) ?></td>
                            <td><span class="badge <?= $done === $criteriaCount && $criteriaCount > 0 ? 'benefit' : 'cost' ?>"><?= $done ?>/<?= $criteriaCount ?> kriteria</span></td>
                            <td>
                                <div class="actions">
                                    <button class="btn-mini" title="Edit" onclick='openForm(<?= json_encode($a, JSON_HEX_APOS) ?>)'><?= icon('pencil', 'icon', 16) ?></button>
                                    <button class="btn-mini danger" title="Hapus" onclick="hapus(<?= $id ?>, '<?= e($a['nama']) ?>')"><?= icon('trash-2', 'icon', 16) ?></button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    <?php endif ?>
</div>

<script>
const fields = [
    { name: 'kode', label: 'Kode (contoh: A1)', required: true, attrs: 'maxlength="10" placeholder="A1"' },
    { name: 'nama', label: 'Nama Calon', required: true, attrs: 'maxlength="100" placeholder="Nama lengkap"' },
    { name: 'jabatan', label: 'Jabatan di Organisasi', attrs: 'maxlength="100" placeholder="Contoh: Ketua Divisi Acara"' },
];

function openForm(data = {}) {
    App.form({
        title: data.id ? 'Edit Calon' : 'Tambah Calon',
        fields,
        values: data,
        onSubmit: async (payload) => {
            const res = await App.request('api/alternatif.php', { action: 'save', id: data.id || 0, ...payload });
            res.ok ? location.reload() : App.toast('error', res.message);
        },
    });
}

function hapus(id, nama) {
    App.confirm(`Data "${nama}" beserta seluruh penilaiannya akan dihapus.`, async () => {
        const res = await App.request('api/alternatif.php', { action: 'delete', id });
        res.ok ? location.reload() : App.toast('error', res.message);
    });
}
</script>

<?php require __DIR__ . '/partials/footer.php'; ?>
