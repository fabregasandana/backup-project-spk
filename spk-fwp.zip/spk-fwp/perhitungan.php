<?php
require_once __DIR__ . '/bootstrap.php';

$pageTitle = 'Perhitungan FWP';
$activeMenu = 'perhitungan';
$calc = buildCalculation();

require __DIR__ . '/partials/header.php';
?>

<?php if ($calc === null): ?>
    <div class="card">
        <div class="empty">
            <?= icon('inbox', 'icon', 44) ?>
            <p>Perhitungan belum bisa dilakukan.<br>Lengkapi kriteria, calon, dan <strong>seluruh</strong> penilaian fuzzy terlebih dahulu.</p>
            <a class="btn" href="penilaian.php" style="margin-top:16px">Buka Halaman Penilaian</a>
        </div>
    </div>
<?php else:
    $criteria = $calc['criteria'];
    $alternatives = $calc['alternatives'];
    $matrix = $calc['matrix'];
    $linguistic = $calc['linguistic'];
    $weights = $calc['weights'];
    $results = $calc['results'];
?>

    <div class="card">
        <div class="card-head">
            <div class="card-title"><?= icon('sigma') ?> Langkah 1 — Normalisasi Bobot</div>
        </div>
        <p class="hint" style="margin-bottom:14px">
            W<sub>j</sub> = w<sub>j</sub> / &sum;w &nbsp; sehingga total bobot normalisasi = 1.
        </p>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr><th>Kode</th><th>Kriteria</th><th>Atribut</th><th>Bobot</th><th>W Normalisasi</th></tr>
                </thead>
                <tbody>
                    <?php $totalBobot = array_sum(array_column($criteria, 'bobot')); ?>
                    <?php foreach ($criteria as $id => $k): ?>
                        <tr>
                            <td><strong><?= e($k['kode']) ?></strong></td>
                            <td><?= e($k['nama']) ?></td>
                            <td><span class="badge <?= e($k['atribut']) ?>"><?= $k['atribut'] === 'benefit' ? 'Benefit' : 'Cost' ?></span></td>
                            <td><?= (int) $k['bobot'] ?> / <?= $totalBobot ?></td>
                            <td><strong><?= num($weights[$id]) ?></strong></td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-head">
            <div class="card-title"><?= icon('sparkles') ?> Langkah 2 — Defuzzifikasi Penilaian</div>
        </div>
        <p class="hint" style="margin-bottom:14px">
            Istilah linguistik tiap sel diubah menjadi nilai crisp r<sub>ij</sub> = (a + b + c) / 3.
        </p>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Alternatif</th>
                        <?php foreach ($criteria as $k): ?><th><?= e($k['kode']) ?></th><?php endforeach ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($alternatives as $altId => $a): ?>
                        <tr>
                            <td><strong><?= e($a['kode']) ?></strong> &middot; <?= e($a['nama']) ?></td>
                            <?php foreach ($criteria as $kriteriaId => $k): ?>
                                <td>
                                    <?= e($linguistic[$altId][$kriteriaId]['kode']) ?>
                                    <span class="muted">(<?= num($matrix[$altId][$kriteriaId]) ?>)</span>
                                </td>
                            <?php endforeach ?>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-head">
            <div class="card-title"><?= icon('calculator') ?> Langkah 3 — Vektor S</div>
        </div>
        <div class="formula">S<sub>i</sub> = &prod;<sub>j</sub> r<sub>ij</sub><sup>&plusmn;W<sub>j</sub></sup> &nbsp; (pangkat negatif untuk kriteria cost)</div>
        <?php foreach ($alternatives as $altId => $a):
            $parts = [];
            foreach ($criteria as $kriteriaId => $k) {
                $sign = $k['atribut'] === 'cost' ? '-' : '';
                $parts[] = num($matrix[$altId][$kriteriaId]) . '<sup>' . $sign . num($weights[$kriteriaId]) . '</sup>';
            }
        ?>
            <p style="margin:10px 0;font-size:.9rem">
                <strong><?= e($a['kode']) ?></strong> &nbsp;S = <?= implode(' &times; ', $parts) ?> = <strong><?= num($results[$altId]['s'], 6) ?></strong>
            </p>
        <?php endforeach ?>
    </div>

    <div class="card">
        <div class="card-head">
            <div class="card-title"><?= icon('trophy') ?> Langkah 4 — Vektor V &amp; Perankingan</div>
        </div>
        <div class="formula">V<sub>i</sub> = S<sub>i</sub> / &sum;S<sub>i</sub></div>
        <div class="table-wrap" style="margin-top:14px">
            <table>
                <thead>
                    <tr><th>Rank</th><th>Calon</th><th>Vektor S</th><th>Vektor V</th><th style="width:26%">Preferensi</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $altId => $res): $a = $alternatives[$altId]; ?>
                        <tr>
                            <td><span class="badge rank">#<?= $res['rank'] ?></span></td>
                            <td><strong><?= e($a['nama']) ?></strong><br><span class="muted"><?= e($a['jabatan']) ?></span></td>
                            <td><?= num($res['s'], 6) ?></td>
                            <td><strong><?= num($res['v'], 6) ?></strong></td>
                            <td><div class="rank-bar"><span style="width:<?= round($res['v'] * 100) ?>%"></span></div></td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>

<?php endif ?>

<?php require __DIR__ . '/partials/footer.php'; ?>
