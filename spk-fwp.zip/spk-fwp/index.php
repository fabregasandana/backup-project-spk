<?php
require_once __DIR__ . '/bootstrap.php';

$pageTitle = 'Dashboard';
$activeMenu = 'index';

$criteria = repo()->criteria();
$alternatives = repo()->alternatives();
$assessments = repo()->assessments();
$calc = buildCalculation();

$top = null;
if ($calc !== null) {
    foreach ($calc['results'] as $altId => $res) {
        if ($res['rank'] === 1) {
            $top = $calc['alternatives'][$altId] + ['v' => $res['v']];
            break;
        }
    }
}

require __DIR__ . '/partials/header.php';
?>

<div class="grid stats">
    <div class="stat">
        <div class="stat-icon"><?= icon('list-checks', 'icon', 26) ?></div>
        <div>
            <div class="stat-value"><?= count($criteria) ?></div>
            <div class="stat-label">Kriteria Penilaian</div>
        </div>
    </div>
    <div class="stat">
        <div class="stat-icon"><?= icon('users', 'icon', 26) ?></div>
        <div>
            <div class="stat-value"><?= count($alternatives) ?></div>
            <div class="stat-label">Calon Ketua Panitia</div>
        </div>
    </div>
    <div class="stat">
        <div class="stat-icon"><?= icon('star', 'icon', 26) ?></div>
        <div>
            <div class="stat-value"><?= count($assessments) ?></div>
            <div class="stat-label">Penilaian Fuzzy</div>
        </div>
    </div>
    <div class="stat">
        <div class="stat-icon"><?= icon('trophy', 'icon', 26) ?></div>
        <div>
            <div class="stat-value" style="font-size:1.05rem"><?= $top ? e($top['nama']) : '—' ?></div>
            <div class="stat-label">Rekomendasi Saat Ini<?= $top ? ' (V = ' . num($top['v']) . ')' : '' ?></div>
        </div>
    </div>
</div>

<div class="grid cols-2">
    <div class="card">
        <div class="card-head">
            <div class="card-title"><?= icon('info') ?> Tentang Aplikasi</div>
        </div>
        <p class="muted" style="line-height:1.8">
            Sistem Pendukung Keputusan ini membantu organisasi memilih
            <strong>calon ketua panitia kegiatan besar</strong> menggunakan metode
            <strong>Full Weighted Product (FWP)</strong> dengan penilaian berbasis
            <strong>fuzzy linguistik</strong>. Penilai cukup memilih skala bahasa
            (Sangat Kurang s.d. Sangat Baik) untuk lima aspek: kepemimpinan, komunikasi,
            komitmen, pengalaman, dan kepercayaan anggota.
        </p>
        <div class="formula" style="margin-top:18px">
            S<sub>i</sub> = &prod;<sub>j</sub> r<sub>ij</sub><sup>&plusmn;w<sub>j</sub></sup>
            &nbsp;&nbsp;&rarr;&nbsp;&nbsp;
            V<sub>i</sub> = S<sub>i</sub> / &sum; S<sub>i</sub>
        </div>
        <p class="hint">
            Bobot kriteria dinormalisasi hingga berjumlah 1. Pangkat bernilai positif untuk
            kriteria benefit dan negatif untuk kriteria cost. Alternatif dengan nilai V terbesar
            menjadi peringkat pertama.
        </p>
    </div>

    <div class="card">
        <div class="card-head">
            <div class="card-title"><?= icon('chart-bar') ?> Peringkat Sementara</div>
            <a class="btn" href="perhitungan.php" style="padding:10px 18px">Detail <?= icon('arrow-right', 'icon', 16) ?></a>
        </div>
        <?php if ($calc === null): ?>
            <div class="empty">
                <?= icon('inbox', 'icon', 40) ?>
                <p>Lengkapi kriteria, alternatif, dan seluruh penilaian untuk melihat peringkat.</p>
            </div>
        <?php else: ?>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr><th>Peringkat</th><th>Calon</th><th>Jabatan</th><th style="width:32%">Nilai V</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($calc['results'] as $altId => $res): $alt = $calc['alternatives'][$altId]; ?>
                            <tr>
                                <td><span class="badge rank">#<?= $res['rank'] ?></span></td>
                                <td><?= e($alt['nama']) ?></td>
                                <td class="muted"><?= e($alt['jabatan']) ?></td>
                                <td>
                                    <div style="display:flex;align-items:center;gap:10px">
                                        <div class="rank-bar" style="flex:1"><span style="width:<?= round($res['v'] * 100) ?>%"></span></div>
                                        <strong><?= num($res['v']) ?></strong>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>
            </div>
        <?php endif ?>
    </div>
</div>

<?php require __DIR__ . '/partials/footer.php'; ?>
