<?php
require_once __DIR__ . '/bootstrap.php';

$pageTitle = 'Penilaian Fuzzy';
$activeMenu = 'penilaian';

$criteria = repo()->criteria();
$alternatives = repo()->alternatives();
$scales = repo()->scales();
$assessments = repo()->assessments();

require __DIR__ . '/partials/header.php';
?>

<div class="card">
    <div class="card-head">
        <div>
            <div class="card-title"><?= icon('star') ?> Skala Linguistik (Fuzzy)</div>
            <p class="hint">Setiap istilah bahasa dipetakan ke Triangular Fuzzy Number (a, b, c), lalu didefuzzifikasi menjadi nilai crisp = (a + b + c) / 3.</p>
        </div>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr><th>Kode</th><th>Istilah</th><th>TFN (a, b, c)</th><th>Nilai Crisp</th></tr>
            </thead>
            <tbody>
                <?php foreach ($scales as $s): ?>
                    <tr>
                        <td><strong><?= e($s['kode']) ?></strong></td>
                        <td><?= e($s['label']) ?></td>
                        <td class="muted">(<?= num((float) $s['a'], 1) ?>, <?= num((float) $s['b'], 1) ?>, <?= num((float) $s['c'], 1) ?>)</td>
                        <td><strong><?= num(FuzzyScale::defuzzify((float) $s['a'], (float) $s['b'], (float) $s['c'])) ?></strong></td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-head">
        <div>
            <div class="card-title"><?= icon('clipboard-check') ?> Matriks Penilaian</div>
            <p class="hint">Klik salah satu istilah pada tiap sel — penilaian tersimpan otomatis.</p>
        </div>
    </div>

    <?php if ($alternatives === [] || $criteria === []): ?>
        <div class="empty"><?= icon('inbox', 'icon', 40) ?><p>Lengkapi data kriteria dan calon terlebih dahulu.</p></div>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Calon</th>
                        <?php foreach ($criteria as $k): ?>
                            <th><?= e($k['kode']) ?> &middot; <?= e($k['nama']) ?></th>
                        <?php endforeach ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($alternatives as $altId => $a): ?>
                        <tr class="rating-row">
                            <td><strong><?= e($a['kode']) ?></strong> &middot; <?= e($a['nama']) ?></td>
                            <?php foreach ($criteria as $kriteriaId => $k):
                                $selected = $assessments[$altId . '-' . $kriteriaId] ?? 0;
                            ?>
                                <td>
                                    <div class="rating-cell">
                                        <?php foreach ($scales as $skalaId => $s): ?>
                                            <button type="button"
                                                    class="chip <?= $selected === $skalaId ? 'active' : '' ?>"
                                                    title="<?= e($s['label']) ?>"
                                                    onclick="nilai(<?= $altId ?>, <?= $kriteriaId ?>, <?= $skalaId ?>, this)">
                                                <?= e($s['kode']) ?>
                                            </button>
                                        <?php endforeach ?>
                                    </div>
                                </td>
                            <?php endforeach ?>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    <?php endif ?>
</div>

<script>
async function nilai(altId, kriteriaId, skalaId, btn) {
    btn.closest('.rating-cell').querySelectorAll('.chip').forEach((c) => c.classList.remove('active'));
    btn.classList.add('active');

    const res = await App.request('api/penilaian.php', {
        action: 'save', alternatif_id: altId, kriteria_id: kriteriaId, skala_id: skalaId,
    });
    App.toast(res.ok ? 'success' : 'error', res.message);
}
</script>

<?php require __DIR__ . '/partials/footer.php'; ?>
