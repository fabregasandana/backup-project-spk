<?php

declare(strict_types=1);

session_start();

require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/app/FuzzyScale.php';
require_once __DIR__ . '/app/Fwp.php';
require_once __DIR__ . '/app/Repository.php';
require_once __DIR__ . '/app/Auth.php';
require_once __DIR__ . '/app/helpers.php';

if (!defined('PUBLIC_PAGE') && !Auth::check()) {
    header('Location: login.php');
    exit;
}

function repo(): Repository
{
    static $repo = null;

    return $repo ??= new Repository(Database::connection());
}

/**
 * Susun data lengkap untuk perhitungan FWP:
 * kriteria, alternatif, matriks crisp hasil defuzzifikasi, dan hasil ranking.
 */
function buildCalculation(): ?array
{
    $criteria = repo()->criteria();
    $alternatives = repo()->alternatives();
    $scales = repo()->scales();
    $assessments = repo()->assessments();

    if ($criteria === [] || $alternatives === []) {
        return null;
    }

    $matrix = [];
    $linguistic = [];
    foreach ($alternatives as $altId => $alt) {
        foreach ($criteria as $kriteriaId => $kriteria) {
            $skalaId = $assessments[$altId . '-' . $kriteriaId] ?? null;
            if ($skalaId === null) {
                return null;
            }
            $skala = $scales[$skalaId];
            $matrix[$altId][$kriteriaId] = FuzzyScale::defuzzify(
                (float) $skala['a'],
                (float) $skala['b'],
                (float) $skala['c']
            );
            $linguistic[$altId][$kriteriaId] = $skala;
        }
    }

    $fwCriteria = array_map(
        static fn ($k) => ['atribut' => $k['atribut'], 'bobot' => (float) $k['bobot']],
        $criteria
    );

    return [
        'criteria' => $criteria,
        'alternatives' => $alternatives,
        'matrix' => $matrix,
        'linguistic' => $linguistic,
        'weights' => Fwp::normalizeWeights(array_map(static fn ($c) => (float) $c['bobot'], $fwCriteria)),
        'results' => Fwp::solve($fwCriteria, $matrix),
    ];
}
