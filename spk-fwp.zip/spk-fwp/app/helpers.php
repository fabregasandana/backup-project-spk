<?php

declare(strict_types=1);

use Lucide\IconManager;

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function icon(string $name, string $class = 'icon', int $size = 20): string
{
    static $manager = null;
    $manager ??= new IconManager();

    return $manager->getIcon($name, ['class' => $class, 'width' => $size, 'height' => $size])->render();
}

function num(float $value, int $decimals = 4): string
{
    return number_format($value, $decimals, ',', '.');
}

function csrf_token(): string
{
    return $_SESSION['csrf'] ??= bin2hex(random_bytes(16));
}

function csrf_guard(): void
{
    $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!hash_equals(csrf_token(), $sent)) {
        json_fail('Sesi tidak valid, muat ulang halaman.');
    }
}

function json_ok(array $data = []): never
{
    echo json_encode(['ok' => true] + $data);
    exit;
}

function json_fail(string $message): never
{
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => $message]);
    exit;
}

function require_post(): array
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        exit;
    }
    csrf_guard();

    return json_decode(file_get_contents('php://input'), true) ?? $_POST;
}
