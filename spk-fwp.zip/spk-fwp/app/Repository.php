<?php

declare(strict_types=1);

final class Repository
{
    public function __construct(private PDO $db)
    {
    }

    /** @return array<int, array<string, mixed>> keyed by id */
    public function criteria(): array
    {
        return $this->keyed('SELECT * FROM kriteria ORDER BY kode');
    }

    /** @return array<int, array<string, mixed>> keyed by id */
    public function scales(): array
    {
        return $this->keyed('SELECT * FROM skala_fuzzy ORDER BY a, b, c');
    }

    /** @return array<int, array<string, mixed>> keyed by id */
    public function alternatives(): array
    {
        return $this->keyed('SELECT * FROM alternatif ORDER BY kode');
    }

    /** @return array<string, int> "alternatif_id-kriteria_id" => skala_id */
    public function assessments(): array
    {
        $rows = $this->db->query('SELECT alternatif_id, kriteria_id, skala_id FROM penilaian')->fetchAll();

        $map = [];
        foreach ($rows as $row) {
            $map[$row['alternatif_id'] . '-' . $row['kriteria_id']] = (int) $row['skala_id'];
        }

        return $map;
    }

    public function find(string $table, int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM {$table} WHERE id = ?");
        $stmt->execute([$id]);

        return $stmt->fetch() ?: null;
    }

    public function insert(string $table, array $data): int
    {
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        $stmt = $this->db->prepare("INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})");
        $stmt->execute(array_values($data));

        return (int) $this->db->lastInsertId();
    }

    public function update(string $table, int $id, array $data): void
    {
        $sets = implode(', ', array_map(static fn ($col) => "{$col} = ?", array_keys($data)));
        $stmt = $this->db->prepare("UPDATE {$table} SET {$sets} WHERE id = ?");
        $stmt->execute([...array_values($data), $id]);
    }

    public function delete(string $table, int $id): void
    {
        $stmt = $this->db->prepare("DELETE FROM {$table} WHERE id = ?");
        $stmt->execute([$id]);
    }

    public function saveAssessment(int $alternatifId, int $kriteriaId, int $skalaId): void
    {
        $stmt = $this->db->prepare(
            'INSERT INTO penilaian (alternatif_id, kriteria_id, skala_id) VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE skala_id = VALUES(skala_id)'
        );
        $stmt->execute([$alternatifId, $kriteriaId, $skalaId]);
    }

    public function codeExists(string $table, string $kode, ?int $exceptId = null): bool
    {
        $sql = "SELECT 1 FROM {$table} WHERE kode = ?" . ($exceptId ? ' AND id <> ?' : '');
        $stmt = $this->db->prepare($sql);
        $stmt->execute($exceptId ? [$kode, $exceptId] : [$kode]);

        return (bool) $stmt->fetchColumn();
    }

    public function nextCode(string $table, string $prefix): string
    {
        $max = $this->db->query("SELECT MAX(CAST(SUBSTRING(kode, 2) AS UNSIGNED)) FROM {$table}")->fetchColumn();

        return $prefix . ((int) $max + 1);
    }

    /** @return array<int, array<string, mixed>> */
    private function keyed(string $sql): array
    {
        $rows = $this->db->query($sql)->fetchAll();

        $keyed = [];
        foreach ($rows as $row) {
            $keyed[(int) $row['id']] = $row;
        }

        return $keyed;
    }
}
