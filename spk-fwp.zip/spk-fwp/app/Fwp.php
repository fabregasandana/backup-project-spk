<?php

declare(strict_types=1);

/**
 * Full Weighted Product (FWP).
 *
 * Langkah:
 *  1. Normalisasi bobot agar jumlahnya = 1.
 *  2. Vektor S  : S_i = Π (x_ij ^ pangkat_j), pangkat + untuk benefit, - untuk cost.
 *  3. Vektor V  : V_i = S_i / Σ S_i  (nilai preferensi akhir).
 *  4. Perankingan menurun berdasarkan V.
 */
final class Fwp
{
    /**
     * @param array<int, array{atribut:string, bobot:float}> $criteria  keyed by kriteria_id
     * @param array<int, array<int, float>>                 $matrix    [alternatif_id][kriteria_id] => crisp value
     * @return array<int, array{s:float, v:float, rank:int}>
     */
    public static function solve(array $criteria, array $matrix): array
    {
        $weights = self::normalizeWeights(array_map(static fn ($c) => (float) $c['bobot'], $criteria));

        $s = [];
        foreach ($matrix as $altId => $row) {
            $product = 1.0;
            foreach ($criteria as $kriteriaId => $meta) {
                $value = max($row[$kriteriaId] ?? 0.0, 1e-9);
                $exponent = $weights[$kriteriaId] * ($meta['atribut'] === 'cost' ? -1 : 1);
                $product *= $value ** $exponent;
            }
            $s[$altId] = $product;
        }

        $totalS = array_sum($s);
        $result = [];
        foreach ($s as $altId => $value) {
            $result[$altId] = ['s' => $value, 'v' => $totalS > 0 ? $value / $totalS : 0.0, 'rank' => 0];
        }

        return self::assignRanks($result);
    }

    /** @param array<int, float> $weights @return array<int, float> keyed by kriteria_id */
    public static function normalizeWeights(array $weights): array
    {
        $total = array_sum($weights);
        if ($total <= 0) {
            return array_map(static fn ($w) => 0.0, $weights);
        }

        return array_map(static fn ($w) => $w / $total, $weights);
    }

    /** @param array<int, array{s:float, v:float, rank:int}> $result */
    private static function assignRanks(array $result): array
    {
        uasort($result, static fn ($a, $b) => $b['v'] <=> $a['v']);

        $rank = 0;
        foreach ($result as $altId => $row) {
            $result[$altId]['rank'] = ++$rank;
        }

        return $result;
    }
}
