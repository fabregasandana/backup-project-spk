<?php

declare(strict_types=1);

/**
 * Skala linguistik fuzzy -> nilai crisp.
 * Tiap label dipetakan ke Triangular Fuzzy Number (a, b, c),
 * lalu didefuzzifikasi dengan rata-rata: (a + b + c) / 3.
 */
final class FuzzyScale
{
    public static function defuzzify(float $a, float $b, float $c): float
    {
        return ($a + $b + $c) / 3;
    }
}
