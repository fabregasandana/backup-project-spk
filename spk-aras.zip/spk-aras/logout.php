<?php

declare(strict_types=1);

require_once __DIR__ . '/config/app.php';

Auth::logout();
session_start();

redirect('login.php');
