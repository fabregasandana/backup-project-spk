<?php

declare(strict_types=1);

require_once __DIR__ . '/config/app.php';

Auth::requireLogin();

$laporan = Laporan::data();
if (!$laporan['lengkap']) {
    redirect('laporan.php');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Laporan &middot; <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body class="print-page">
    <div class="print-bar no-print">
        <button type="button" class="btn btn-primary" onclick="window.print()"><?= icon('printer', 17) ?> Cetak Sekarang</button>
        <button type="button" class="btn btn-ghost" onclick="window.close()"><?= icon('x', 17) ?> Tutup</button>
        <span class="print-hint">Dialog printer terbuka otomatis; gunakan "Save as PDF" di dialog bila ingin berkas PDF.</span>
    </div>

    <div class="paper-frame print-frame">
        <?php require ROOT_PATH . '/views/laporan_dokumen.php'; ?>
    </div>

    <script>window.addEventListener('load', () => setTimeout(() => window.print(), 400));</script>
</body>
</html>
