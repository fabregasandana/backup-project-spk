<?php

declare(strict_types=1);

require_once __DIR__ . '/config/app.php';

Auth::requireLogin();

$kriteria = Kriteria::all();
$alternatif = Alternatif::all();
$matriks = Penilaian::matrix();
$totalBobot = Kriteria::totalBobot();
$lengkap = Aras::dataLengkap($kriteria, $alternatif, $matriks);

$hasil = $lengkap ? Aras::hitung($kriteria, $alternatif, $matriks) : null;
$peringkat3 = [];
if ($hasil !== null) {
    $altById = array_column($alternatif, null, 'id');
    foreach (array_slice($hasil['k'], 0, 3, true) as $id => $nilaiK) {
        $peringkat3[] = ['alt' => $altById[$id], 'k' => $nilaiK];
    }
}

$pageTitle = 'Dashboard';
$active = 'dashboard';
require ROOT_PATH . '/views/header.php';
?>

<section class="hero glass">
    <span class="hero-badge"><?= icon('sparkles', 14) ?> Sistem Pendukung Keputusan &middot; Metode ARAS</span>
    <h2>Pemilihan <span class="accent">Peralatan Produksi Hemat Energi</span> untuk UMKM Makanan</h2>
    <p>
        Bandingkan peralatan produksi berdasarkan efisiensi listrik, kapasitas produksi, harga,
        garansi, kemudahan perawatan, dan dampak pada kualitas produk. Metode ARAS
        (Additive Ratio Assessment) mengukur seberapa dekat setiap alternatif dengan nilai optimal.
    </p>
    <div class="hero-actions">
        <a class="btn btn-primary" href="<?= BASE_URL ?>/hasil.php"><?= icon('trophy', 17) ?> Hitung &amp; Lihat Peringkat</a>
        <a class="btn btn-ghost" href="<?= BASE_URL ?>/penilaian.php"><?= icon('clipboard-list', 17) ?> Input Penilaian</a>
    </div>
</section>

<section class="stat-grid">
    <div class="stat-card glass">
        <span class="stat-icon emerald"><?= icon('sliders-horizontal', 24) ?></span>
        <div>
            <p class="stat-value" data-count="<?= count($kriteria) ?>">0</p>
            <p class="stat-label">Kriteria Penilaian</p>
        </div>
    </div>
    <div class="stat-card glass">
        <span class="stat-icon gold"><?= icon('boxes', 24) ?></span>
        <div>
            <p class="stat-value" data-count="<?= count($alternatif) ?>">0</p>
            <p class="stat-label">Alternatif Peralatan</p>
        </div>
    </div>
    <div class="stat-card glass">
        <span class="stat-icon navy"><?= icon('percent', 24) ?></span>
        <div>
            <p class="stat-value">
                <span data-count="<?= format_desimal($totalBobot, abs($totalBobot - round($totalBobot)) > 0.001 ? 2 : 0) ?>">0</span><small>%</small>
            </p>
            <p class="stat-label">
                Total Bobot
                <?php if (abs($totalBobot - 100) > 0.001): ?>
                    <span class="badge badge-warn">harus 100%</span>
                <?php else: ?>
                    <span class="badge badge-ok">sesuai</span>
                <?php endif; ?>
            </p>
        </div>
    </div>
    <div class="stat-card glass">
        <span class="stat-icon emerald"><?= icon('award', 24) ?></span>
        <div>
            <?php if ($peringkat3 !== []): ?>
                <p class="stat-value text-sm"><?= e($peringkat3[0]['alt']['nama']) ?></p>
                <p class="stat-label">Rekomendasi Terbaik (K = <?= format_desimal($peringkat3[0]['k']) ?>)</p>
            <?php else: ?>
                <p class="stat-value text-sm">&mdash;</p>
                <p class="stat-label">Lengkapi data penilaian dulu</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<div class="grid-2">
    <section class="card glass">
        <div class="card-head">
            <h3 class="card-title">
                <span class="title-icon"><?= icon('calculator', 17) ?></span>
                Tahapan Metode ARAS
            </h3>
        </div>
        <div class="steps">
            <?php
            $tahapan = [
                ['Matriks Keputusan', 'Susun nilai setiap alternatif pada tiap kriteria, lalu tentukan baris nilai optimal (terbaik per kriteria).'],
                ['Normalisasi', 'Samakan skala nilai: kriteria benefit dibagi jumlah kolom, kriteria cost dibalik terlebih dahulu.'],
                ['Pembobotan', 'Kalikan nilai ternormalisasi dengan bobot tiap kriteria (v = w &times; r).'],
                ['Fungsi Optimalitas', 'Jumlahkan seluruh nilai terbobot tiap alternatif menjadi S, termasuk baris optimal S&#8320;.'],
                ['Peringkat Kegunaan', 'Hitung derajat kegunaan K = S / S&#8320;. Semakin mendekati 1, semakin layak dipilih.'],
            ];
            foreach ($tahapan as $i => [$judul, $deskripsi]): ?>
                <div class="step">
                    <span class="step-num"><?= $i + 1 ?></span>
                    <div class="step-body">
                        <h4><?= $judul ?></h4>
                        <p><?= $deskripsi ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <div>
        <section class="card glass">
            <div class="card-head">
                <h3 class="card-title">
                    <span class="title-icon gold"><?= icon('percent', 17) ?></span>
                    Bobot Kriteria
                </h3>
                <a class="card-note" href="<?= BASE_URL ?>/kriteria.php">Kelola &rarr;</a>
            </div>

            <?php if ($kriteria === []): ?>
                <div class="empty-state">
                    <span class="empty-icon"><?= icon('sliders-horizontal', 26) ?></span>
                    <h4>Belum ada kriteria</h4>
                    <p>Tambahkan kriteria penilaian terlebih dahulu pada menu Data Kriteria.</p>
                </div>
            <?php else: ?>
                <div class="weight-list">
                    <?php foreach ($kriteria as $kri): ?>
                        <div class="weight-item">
                            <div class="weight-item-head">
                                <strong><?= e($kri['kode']) ?> &middot; <?= e($kri['nama']) ?></strong>
                                <span class="weight-num"><?= format_desimal((float) $kri['bobot'], 2) ?>%</span>
                            </div>
                            <div class="weight-bar">
                                <span style="width: <?= min(100, (float) $kri['bobot']) ?>%"></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="weight-total">
                    <span>Total bobot harus 100%</span>
                    <strong><?= format_desimal($totalBobot, 2) ?>%</strong>
                </div>
            <?php endif; ?>
        </section>

        <section class="card glass">
            <div class="card-head">
                <h3 class="card-title">
                    <span class="title-icon"><?= icon('trending-up', 17) ?></span>
                    Pratinjau Peringkat
                </h3>
                <a class="card-note" href="<?= BASE_URL ?>/hasil.php">Detail &rarr;</a>
            </div>

            <?php if ($peringkat3 === []): ?>
                <div class="empty-state">
                    <span class="empty-icon"><?= icon('trophy', 26) ?></span>
                    <h4>Belum dapat dihitung</h4>
                    <p>Peringkat muncul setelah seluruh alternatif memiliki nilai penilaian pada setiap kriteria.</p>
                </div>
            <?php else: ?>
                <div class="preview-list">
                    <?php foreach ($peringkat3 as $i => $item): ?>
                        <div class="preview-item <?= $i === 0 ? 'first' : '' ?>">
                            <span class="medal medal-<?= $i + 1 ?>"><?= $i + 1 ?></span>
                            <span class="preview-name">
                                <strong><?= e($item['alt']['nama']) ?></strong>
                                <small><?= e($item['alt']['kode']) ?><?= $item['alt']['kategori'] ? ' &middot; ' . e($item['alt']['kategori']) : '' ?></small>
                            </span>
                            <span class="preview-k"><?= format_desimal($item['k']) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </div>
</div>

<?php require ROOT_PATH . '/views/footer.php'; ?>
