<?php

declare(strict_types=1);

require_once __DIR__ . '/config/app.php';

Auth::requireLogin();

$alternatif = Alternatif::all();
$jumlahKriteria = count(Kriteria::all());
$matriks = Penilaian::matrix();

$pageTitle = 'Data Alternatif';
$active = 'alternatif';
require ROOT_PATH . '/views/header.php';
?>

<div class="page-head">
    <div>
        <h2>Alternatif Peralatan</h2>
        <p>
            Daftar peralatan produksi kandidat yang akan dibandingkan.
            Setiap alternatif dinilai terhadap seluruh kriteria pada menu Penilaian.
        </p>
    </div>
    <button type="button" class="btn btn-primary" data-modal-open="modalAlternatif" data-modal-heading="Tambah Alternatif">
        <?= icon('plus', 17) ?> Tambah Alternatif
    </button>
</div>

<section class="card glass">
    <div class="card-head">
        <h3 class="card-title">
            <span class="title-icon gold"><?= icon('boxes', 17) ?></span>
            Daftar Alternatif (<?= count($alternatif) ?>)
        </h3>
        <a class="btn btn-ghost btn-sm" href="<?= BASE_URL ?>/penilaian.php"><?= icon('clipboard-list', 15) ?> Isi Penilaian</a>
    </div>

    <?php if ($alternatif === []): ?>
        <div class="empty-state">
            <span class="empty-icon"><?= icon('boxes', 26) ?></span>
            <h4>Belum ada alternatif</h4>
            <p>Klik tombol "Tambah Alternatif" untuk mendaftarkan peralatan produksi yang akan dibandingkan.</p>
        </div>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Nama Peralatan</th>
                        <th>Kategori</th>
                        <th>Keterangan</th>
                        <th class="t-center">Penilaian</th>
                        <th class="t-right">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($alternatif as $alt): ?>
                        <?php
                        $terisi = 0;
                        foreach ($matriks[$alt['id']] ?? [] as $nilai) {
                            if ($nilai > 0) {
                                $terisi++;
                            }
                        }
                        ?>
                        <tr>
                            <td><span class="kode-chip alt"><?= e($alt['kode']) ?></span></td>
                            <td class="td-main"><?= e($alt['nama']) ?></td>
                            <td><?= $alt['kategori'] ? '<span class="badge badge-muted">' . e($alt['kategori']) . '</span>' : '-' ?></td>
                            <td class="td-sub" style="margin:0; max-width: 280px"><?= e($alt['keterangan'] ?? '-') ?></td>
                            <td class="t-center">
                                <span class="badge <?= $terisi >= $jumlahKriteria ? 'badge-ok' : 'badge-warn' ?>">
                                    <?= $terisi ?>/<?= $jumlahKriteria ?> kriteria
                                </span>
                            </td>
                            <td>
                                <div class="cell-actions">
                                    <button type="button" class="btn btn-icon btn-ghost btn-edit"
                                            data-modal-open="modalAlternatif"
                                            data-modal-heading="Ubah Alternatif"
                                            data-edit='<?= e(json_encode([
                                                'id' => $alt['id'],
                                                'kode' => $alt['kode'],
                                                'nama' => $alt['nama'],
                                                'kategori' => $alt['kategori'] ?? '',
                                                'keterangan' => $alt['keterangan'] ?? '',
                                            ], JSON_HEX_APOS)) ?>'
                                            aria-label="Ubah alternatif <?= e($alt['kode']) ?>">
                                        <?= icon('square-pen', 16) ?>
                                    </button>
                                    <form method="post" action="<?= BASE_URL ?>/actions/alternatif.php"
                                          data-confirm="Alternatif <?= e($alt['kode']) ?> (<?= e($alt['nama']) ?>) dan seluruh nilai penilaiannya akan dihapus permanen.">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="aksi" value="hapus">
                                        <input type="hidden" name="id" value="<?= (int) $alt['id'] ?>">
                                        <button type="submit" class="btn btn-icon btn-ghost btn-danger" aria-label="Hapus alternatif <?= e($alt['kode']) ?>">
                                            <?= icon('trash-2', 16) ?>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<div class="modal-overlay" id="modalAlternatif">
    <div class="modal glass">
        <div class="modal-head">
            <h3 data-modal-title>Tambah Alternatif</h3>
            <button type="button" class="modal-close" data-modal-close aria-label="Tutup"><?= icon('x', 17) ?></button>
        </div>
        <form method="post" action="<?= BASE_URL ?>/actions/alternatif.php">
            <?= csrf_field() ?>
            <input type="hidden" name="aksi" value="simpan">
            <input type="hidden" name="id" value="">

            <div class="field-row">
                <div class="field">
                    <label for="altKode">Kode Alternatif <span class="req">*</span></label>
                    <input type="text" id="altKode" name="kode" maxlength="6" placeholder="A1" value="<?= e(Alternatif::kodeOtomatis()) ?>" required>
                </div>
                <div class="field">
                    <label for="altKategori">Kategori</label>
                    <input type="text" id="altKategori" name="kategori" maxlength="60" placeholder="Pencampuran, Pemanggangan, ...">
                </div>
            </div>

            <div class="field">
                <label for="altNama">Nama Peralatan <span class="req">*</span></label>
                <input type="text" id="altNama" name="nama" maxlength="120" placeholder="Planetary Mixer 20L" required>
            </div>

            <div class="field">
                <label for="altKeterangan">Keterangan</label>
                <textarea id="altKeterangan" name="keterangan" maxlength="255" placeholder="Deskripsi singkat peralatan"></textarea>
            </div>

            <div class="modal-actions">
                <button type="button" class="btn btn-ghost" data-modal-close>Batal</button>
                <button type="submit" class="btn btn-primary"><?= icon('check', 16) ?> Simpan</button>
            </div>
        </form>
    </div>
</div>

<?php require ROOT_PATH . '/views/footer.php'; ?>
