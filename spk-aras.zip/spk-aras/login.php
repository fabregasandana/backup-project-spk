<?php

declare(strict_types=1);

require_once __DIR__ . '/config/app.php';

if (Auth::check()) {
    redirect('index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        flash('error', 'Username dan password wajib diisi.');
        redirect('login.php');
    }

    if (Auth::attempt($username, $password)) {
        flash('success', 'Selamat datang, ' . $_SESSION['user_nama'] . '!');
        redirect('index.php');
    }

    flash('error', 'Username atau password salah.');
    redirect('login.php');
}

$flash = pull_flash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login &middot; <?= APP_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body class="login-page">
<div class="bg-decor" aria-hidden="true">
    <span class="orb orb-emerald"></span>
    <span class="orb orb-gold"></span>
    <span class="orb orb-navy"></span>
</div>

<div class="login-wrap">
    <div class="login-card glass">
        <div class="login-brand">
            <span class="brand-icon"><?= icon('zap', 22) ?></span>
            <div>
                <strong><?= APP_NAME ?></strong>
                <small>Peralatan Hemat Energi</small>
            </div>
        </div>

        <h2 class="login-title">Masuk ke Sistem</h2>
        <p class="login-sub">SPK Pemilihan Peralatan Produksi Hemat Energi &mdash; Metode ARAS</p>

        <?php if ($flash !== null): ?>
            <div class="notice <?= $flash['type'] === 'success' ? 'notice-ok' : 'notice-warn' ?> login-notice">
                <div>
                    <strong><?= $flash['type'] === 'success' ? 'Berhasil' : 'Gagal' ?></strong>
                    <p><?= e($flash['message']) ?></p>
                </div>
            </div>
        <?php endif; ?>

        <form method="post" action="<?= BASE_URL ?>/login.php">
            <?= csrf_field() ?>
            <div class="field">
                <label for="username">Username <span class="req">*</span></label>
                <input type="text" id="username" name="username" placeholder="Masukkan username" required autofocus autocomplete="username">
            </div>
            <div class="field">
                <label for="password">Password <span class="req">*</span></label>
                <input type="password" id="password" name="password" placeholder="Masukkan password" required autocomplete="current-password">
            </div>
            <button type="submit" class="btn btn-primary btn-login">
                <?= icon('log-in', 17) ?> Masuk
            </button>
        </form>

        <p class="login-foot">&copy; <?= date('Y') ?> <?= APP_NAME ?> &middot; Sistem Pendukung Keputusan Metode ARAS</p>
    </div>
</div>
</body>
</html>
