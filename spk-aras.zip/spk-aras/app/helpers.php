<?php

declare(strict_types=1);

use Lucide\IconManager;

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function icon(string $name, int $size = 20, string $class = ''): string
{
    static $manager = null;
    $manager ??= new IconManager();

    $icon = $manager->getIcon($name)->setSize($size);
    if ($class !== '') {
        $icon->setCssClass($class);
    }

    return $icon->render();
}

function redirect(string $page): never
{
    header('Location: ' . BASE_URL . '/' . ltrim($page, '/'));
    exit;
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function pull_flash(): ?array
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);

    return $flash;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}

function csrf_verify(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(403);
        exit('Sesi tidak valid. Silakan muat ulang halaman.');
    }
}

function format_desimal(float $number, int $decimals = 4): string
{
    return number_format($number, $decimals, ',', '.');
}

function format_rupiah(float $amount): string
{
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

function format_nilai(float $value, string $satuan = ''): string
{
    $text = $value == (int) $value
        ? number_format($value, 0, ',', '.')
        : rtrim(rtrim(number_format($value, 2, ',', '.'), '0'), ',');

    return $satuan !== '' ? $text . ' ' . $satuan : $text;
}

function tanggal_id(?int $timestamp = null): string
{
    $bulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    $waktu = $timestamp ?? time();

    return date('j', $waktu) . ' ' . $bulan[(int) date('n', $waktu) - 1] . ' ' . date('Y', $waktu);
}
