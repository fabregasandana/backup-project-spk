<?php

declare(strict_types=1);

final class Penilaian
{
    /** Matriks penilaian: [id_alternatif][id_kriteria] => nilai */
    public static function matrix(): array
    {
        $matriks = [];
        $rows = db()->query('SELECT id_alternatif, id_kriteria, nilai FROM penilaian')->fetchAll();
        foreach ($rows as $row) {
            $matriks[$row['id_alternatif']][$row['id_kriteria']] = (float) $row['nilai'];
        }

        return $matriks;
    }

    public static function simpan(int $idAlternatif, int $idKriteria, float $nilai): void
    {
        $stmt = db()->prepare(
            'INSERT INTO penilaian (id_alternatif, id_kriteria, nilai) VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE nilai = VALUES(nilai)'
        );
        $stmt->execute([$idAlternatif, $idKriteria, $nilai]);
    }
}
