<?php

declare(strict_types=1);

final class Kriteria
{
    public static function all(): array
    {
        return db()->query('SELECT * FROM kriteria ORDER BY kode')->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $stmt = db()->prepare('SELECT * FROM kriteria WHERE id = ?');
        $stmt->execute([$id]);

        return $stmt->fetch() ?: null;
    }

    public static function create(array $data): void
    {
        $stmt = db()->prepare(
            'INSERT INTO kriteria (kode, nama, tipe, bobot, satuan, keterangan)
             VALUES (:kode, :nama, :tipe, :bobot, :satuan, :keterangan)'
        );
        $stmt->execute(self::bind($data));
    }

    public static function update(int $id, array $data): void
    {
        $stmt = db()->prepare(
            'UPDATE kriteria SET kode = :kode, nama = :nama, tipe = :tipe,
                    bobot = :bobot, satuan = :satuan, keterangan = :keterangan
             WHERE id = :id'
        );
        $stmt->execute(self::bind($data) + ['id' => $id]);
    }

    public static function delete(int $id): void
    {
        db()->prepare('DELETE FROM kriteria WHERE id = ?')->execute([$id]);
    }

    public static function kodeAda(string $kode, ?int $exceptId = null): bool
    {
        $stmt = db()->prepare('SELECT COUNT(*) FROM kriteria WHERE kode = ? AND id != ?');
        $stmt->execute([$kode, $exceptId ?? 0]);

        return (int) $stmt->fetchColumn() > 0;
    }

    public static function totalBobot(): float
    {
        return (float) db()->query('SELECT COALESCE(SUM(bobot), 0) FROM kriteria')->fetchColumn();
    }

    private static function bind(array $data): array
    {
        return [
            'kode' => strtoupper(trim($data['kode'])),
            'nama' => trim($data['nama']),
            'tipe' => ($data['tipe'] ?? 'benefit') === 'cost' ? 'cost' : 'benefit',
            'bobot' => (float) ($data['bobot'] ?? 0),
            'satuan' => trim($data['satuan'] ?? '') ?: null,
            'keterangan' => trim($data['keterangan'] ?? '') ?: null,
        ];
    }
}
