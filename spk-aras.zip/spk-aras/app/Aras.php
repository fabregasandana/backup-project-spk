<?php

declare(strict_types=1);

/**
 * Perhitungan metode ARAS (Additive Ratio Assessment).
 *
 * Baris ke-0 adalah baris nilai optimal per kriteria: nilai terbesar untuk
 * kriteria benefit dan nilai terkecil untuk kriteria cost.
 */
final class Aras
{
    public const BARIS_OPTIMAL = 0;

    public static function hitung(array $kriteria, array $alternatif, array $matriks): array
    {
        $bobot = self::bobotDinormalisasi($kriteria);
        $nilai = self::matriksKeputusan($kriteria, $alternatif, $matriks);
        $normalisasi = self::normalisasi($kriteria, $nilai);

        $terbobot = [];
        foreach ($normalisasi as $baris => $kolom) {
            foreach ($kolom as $idKriteria => $r) {
                $terbobot[$baris][$idKriteria] = $r * $bobot[$idKriteria];
            }
        }

        $s = array_map('array_sum', $terbobot);
        $s0 = $s[self::BARIS_OPTIMAL] ?? 0.0;

        $k = [];
        foreach ($alternatif as $alt) {
            $id = (int) $alt['id'];
            $k[$id] = $s0 > 0 ? $s[$id] / $s0 : 0.0;
        }
        arsort($k);

        $peringkat = [];
        $rank = 1;
        foreach (array_keys($k) as $id) {
            $peringkat[$id] = $rank++;
        }

        return [
            'bobot' => $bobot,
            'nilai' => $nilai,
            'normalisasi' => $normalisasi,
            'terbobot' => $terbobot,
            's' => $s,
            's0' => $s0,
            'k' => $k,
            'peringkat' => $peringkat,
        ];
    }

    /** Semua sel matriks wajib terisi nilai positif agar hasil valid. */
    public static function dataLengkap(array $kriteria, array $alternatif, array $matriks): bool
    {
        if ($kriteria === [] || $alternatif === []) {
            return false;
        }

        foreach ($alternatif as $alt) {
            foreach ($kriteria as $kri) {
                if ((float) ($matriks[$alt['id']][$kri['id']] ?? 0) <= 0) {
                    return false;
                }
            }
        }

        return true;
    }

    private static function bobotDinormalisasi(array $kriteria): array
    {
        $total = array_sum(array_map(fn($k) => (float) $k['bobot'], $kriteria));
        $bobot = [];
        foreach ($kriteria as $k) {
            $bobot[(int) $k['id']] = $total > 0 ? (float) $k['bobot'] / $total : 0.0;
        }

        return $bobot;
    }

    /** Gabungkan nilai alternatif dengan baris optimal (baris ke-0). */
    private static function matriksKeputusan(array $kriteria, array $alternatif, array $matriks): array
    {
        $nilai = [];
        foreach ($alternatif as $alt) {
            foreach ($kriteria as $kri) {
                $nilai[(int) $alt['id']][(int) $kri['id']] =
                    (float) ($matriks[$alt['id']][$kri['id']] ?? 0);
            }
        }

        foreach ($kriteria as $kri) {
            $kolom = array_column($nilai, (int) $kri['id']);
            $positif = array_filter($kolom, fn($v) => $v > 0);
            $nilai[self::BARIS_OPTIMAL][(int) $kri['id']] = $positif
                ? ($kri['tipe'] === 'benefit' ? max($positif) : min($positif))
                : 0.0;
        }

        return $nilai;
    }

    /**
     * benefit: r = x / Σx
     * cost:    r = (1/x) / Σ(1/x)
     */
    private static function normalisasi(array $kriteria, array $nilai): array
    {
        $normalisasi = [];
        foreach ($kriteria as $kri) {
            $id = (int) $kri['id'];
            // array_map mempertahankan key baris (id alternatif & baris optimal),
            // berbeda dengan array_column yang menomori ulang hasilnya.
            $kolom = array_map(fn($baris) => (float) ($baris[$id] ?? 0), $nilai);

            if ($kri['tipe'] === 'benefit') {
                $jumlah = array_sum($kolom);
                foreach ($kolom as $baris => $x) {
                    $normalisasi[$baris][$id] = $jumlah > 0 ? $x / $jumlah : 0.0;
                }
                continue;
            }

            $invers = [];
            foreach ($kolom as $baris => $x) {
                $invers[$baris] = $x > 0 ? 1 / $x : 0.0;
            }
            $jumlah = array_sum($invers);
            foreach ($invers as $baris => $inv) {
                $normalisasi[$baris][$id] = $jumlah > 0 ? $inv / $jumlah : 0.0;
            }
        }

        return $normalisasi;
    }
}
