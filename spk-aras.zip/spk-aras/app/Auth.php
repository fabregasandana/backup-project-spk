<?php

declare(strict_types=1);

class Auth
{
    public static function attempt(string $username, string $password): bool
    {
        $stmt = db()->prepare('SELECT * FROM users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user === null || !password_verify($password, $user['password'])) {
            return false;
        }

        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $user['id'];
        $_SESSION['user_nama'] = $user['nama'];

        return true;
    }

    public static function check(): bool
    {
        return isset($_SESSION['user_id']);
    }

    public static function user(): ?array
    {
        if (!self::check()) {
            return null;
        }

        $stmt = db()->prepare('SELECT id, username, nama FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();

        if ($user === null) {
            self::logout();
        }

        return $user;
    }

    public static function requireLogin(): void
    {
        if (!self::check()) {
            flash('error', 'Silakan login terlebih dahulu.');
            redirect('login.php');
        }
    }

    public static function logout(): void
    {
        $_SESSION = [];
        session_destroy();
    }
}
