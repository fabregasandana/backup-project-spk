<?php

declare(strict_types=1);

final class Alternatif
{
    public static function all(): array
    {
        return db()->query('SELECT * FROM alternatif ORDER BY kode')->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $stmt = db()->prepare('SELECT * FROM alternatif WHERE id = ?');
        $stmt->execute([$id]);

        return $stmt->fetch() ?: null;
    }

    public static function create(array $data): void
    {
        $stmt = db()->prepare(
            'INSERT INTO alternatif (kode, nama, kategori, keterangan)
             VALUES (:kode, :nama, :kategori, :keterangan)'
        );
        $stmt->execute(self::bind($data));
    }

    public static function update(int $id, array $data): void
    {
        $stmt = db()->prepare(
            'UPDATE alternatif SET kode = :kode, nama = :nama,
                    kategori = :kategori, keterangan = :keterangan
             WHERE id = :id'
        );
        $stmt->execute(self::bind($data) + ['id' => $id]);
    }

    public static function delete(int $id): void
    {
        db()->prepare('DELETE FROM alternatif WHERE id = ?')->execute([$id]);
    }

    public static function kodeAda(string $kode, ?int $exceptId = null): bool
    {
        $stmt = db()->prepare('SELECT COUNT(*) FROM alternatif WHERE kode = ? AND id != ?');
        $stmt->execute([$kode, $exceptId ?? 0]);

        return (int) $stmt->fetchColumn() > 0;
    }

    public static function kodeOtomatis(): string
    {
        $jumlah = (int) db()->query('SELECT COUNT(*) FROM alternatif')->fetchColumn();

        return 'A' . ($jumlah + 1);
    }

    private static function bind(array $data): array
    {
        return [
            'kode' => strtoupper(trim($data['kode'])),
            'nama' => trim($data['nama']),
            'kategori' => trim($data['kategori'] ?? '') ?: null,
            'keterangan' => trim($data['keterangan'] ?? '') ?: null,
        ];
    }
}
