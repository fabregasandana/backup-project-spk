<?php

declare(strict_types=1);

final class Laporan
{
    public static function data(): array
    {
        $kriteria = Kriteria::all();
        $alternatif = Alternatif::all();
        $matriks = Penilaian::matrix();

        $laporan = [
            'kriteria' => $kriteria,
            'alternatif' => $alternatif,
            'matriks' => $matriks,
            'lengkap' => Aras::dataLengkap($kriteria, $alternatif, $matriks),
            'hasil' => null,
            'peringkat' => [],
            'juara' => null,
            'tanggal' => tanggal_id(),
        ];

        if (!$laporan['lengkap']) {
            return $laporan;
        }

        $hasil = Aras::hitung($kriteria, $alternatif, $matriks);
        $altById = array_column($alternatif, null, 'id');
        foreach ($hasil['k'] as $id => $nilaiK) {
            $laporan['peringkat'][] = [
                'alt' => $altById[$id],
                'k' => $nilaiK,
                's' => $hasil['s'][$id],
                'rank' => $hasil['peringkat'][$id],
            ];
        }

        $laporan['hasil'] = $hasil;
        $laporan['juara'] = $laporan['peringkat'][0] ?? null;

        return $laporan;
    }

    public static function renderHtml(array $laporan): string
    {
        ob_start();
        require ROOT_PATH . '/views/laporan_dokumen.php';

        return ob_get_clean();
    }
}
