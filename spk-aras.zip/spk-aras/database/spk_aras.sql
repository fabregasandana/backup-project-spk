-- SPK Pemilihan Peralatan Produksi Hemat Energi untuk UMKM Makanan
-- Metode: ARAS (Additive Ratio Assessment)

CREATE DATABASE IF NOT EXISTS spk_aras
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE spk_aras;

DROP TABLE IF EXISTS penilaian;
DROP TABLE IF EXISTS alternatif;
DROP TABLE IF EXISTS kriteria;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL,
  password VARCHAR(255) NOT NULL,
  dibuat_pada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO users (username, nama, password) VALUES
('admin', 'Administrator', '$2y$10$Jwdn7Bg/BZWC27o/5yuwy.15rEZfE5R5lcnP0tIjV8R6so/vMfy72');

CREATE TABLE kriteria (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kode VARCHAR(5) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL,
  tipe ENUM('benefit','cost') NOT NULL DEFAULT 'benefit',
  bobot DECIMAL(5,2) NOT NULL DEFAULT 0,
  satuan VARCHAR(30) NULL,
  keterangan VARCHAR(255) NULL
) ENGINE=InnoDB;

CREATE TABLE alternatif (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kode VARCHAR(6) NOT NULL UNIQUE,
  nama VARCHAR(120) NOT NULL,
  kategori VARCHAR(60) NULL,
  keterangan VARCHAR(255) NULL
) ENGINE=InnoDB;

CREATE TABLE penilaian (
  id_alternatif INT UNSIGNED NOT NULL,
  id_kriteria INT UNSIGNED NOT NULL,
  nilai DECIMAL(14,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (id_alternatif, id_kriteria),
  CONSTRAINT fk_penilaian_alternatif FOREIGN KEY (id_alternatif) REFERENCES alternatif(id) ON DELETE CASCADE,
  CONSTRAINT fk_penilaian_kriteria FOREIGN KEY (id_kriteria) REFERENCES kriteria(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO kriteria (kode, nama, tipe, bobot, satuan, keterangan) VALUES
('C1', 'Efisiensi Listrik', 'cost', 25.00, 'watt', 'Konsumsi daya listrik; semakin kecil semakin hemat energi'),
('C2', 'Kapasitas Produksi', 'benefit', 20.00, 'kg/jam', 'Volume hasil produksi per jam; semakin besar semakin baik'),
('C3', 'Harga', 'cost', 25.00, 'Rp', 'Harga beli peralatan; semakin murah semakin baik'),
('C4', 'Garansi', 'benefit', 10.00, 'bulan', 'Masa garansi resmi; semakin lama semakin baik'),
('C5', 'Kemudahan Perawatan', 'benefit', 10.00, 'skor 1-5', 'Ketersediaan suku cadang dan kemudahan servis'),
('C6', 'Dampak Kualitas Produk', 'benefit', 10.00, 'skor 1-5', 'Pengaruh peralatan terhadap mutu hasil produksi');

INSERT INTO alternatif (kode, nama, kategori, keterangan) VALUES
('A1', 'Planetary Mixer 20L Admixer', 'Pencampuran', 'Mixer serbaguna untuk adonan kue dan roti'),
('A2', 'Oven Listrik 2 Deck Deck', 'Pemanggangan', 'Oven pemanggang roti dengan pengatur suhu digital'),
('A3', 'Mesin Spinner 5 kg', 'Penirisan', 'Peniris minyak keripik dan gorengan'),
('A4', 'Vacuum Sealer DZ-260', 'Pengemasan', 'Mesin vakum untuk pengawetan produk makanan'),
('A5', 'Spiral Mixer 25 kg', 'Pencampuran', 'Mixer spiral khusus adonan roti kapasitas besar');

INSERT INTO penilaian (id_alternatif, id_kriteria, nilai) VALUES
(1, 1, 750),    (1, 2, 20),  (1, 3, 6500000),  (1, 4, 12), (1, 5, 4), (1, 6, 4),
(2, 1, 3000),   (2, 2, 40),  (2, 3, 8750000),  (2, 4, 24), (2, 5, 3), (2, 6, 5),
(3, 1, 350),    (3, 2, 15),  (3, 3, 2850000),  (3, 4, 12), (3, 5, 5), (3, 6, 4),
(4, 1, 370),    (4, 2, 60),  (4, 3, 3400000),  (4, 4, 6),  (4, 5, 4), (4, 6, 3),
(5, 1, 1500),   (5, 2, 25),  (5, 3, 12000000), (5, 4, 24), (5, 5, 3), (5, 6, 5);
