document.addEventListener('DOMContentLoaded', () => {
    initFlash();
    initSidebar();
    initModals();
    initConfirmForms();
    initCounters();

    document.getElementById('btnResetPenilaian')?.addEventListener('click', () => {
        document.getElementById('formPenilaian')?.reset();
    });
});

const swalGlass = { customClass: { popup: 'swal-glass' } };

function initFlash() {
    const flash = window.APP?.flash;
    if (!flash) return;

    Swal.fire({
        icon: flash.type === 'success' ? 'success' : 'error',
        title: flash.type === 'success' ? 'Berhasil' : 'Gagal',
        text: flash.message,
        timer: 2800,
        timerProgressBar: true,
        showConfirmButton: false,
        ...swalGlass,
    });
}

function initSidebar() {
    const sidebar = document.getElementById('sidebar');
    const backdrop = document.getElementById('sidebarBackdrop');
    const hamburger = document.getElementById('hamburger');
    if (!sidebar || !hamburger) return;

    const toggle = (open) => {
        sidebar.classList.toggle('open', open);
        backdrop?.classList.toggle('show', open);
    };

    hamburger.addEventListener('click', () => toggle(!sidebar.classList.contains('open')));
    backdrop?.addEventListener('click', () => toggle(false));
}

function initModals() {
    document.querySelectorAll('[data-modal-open]').forEach((trigger) => {
        trigger.addEventListener('click', () => {
            const overlay = document.getElementById(trigger.dataset.modalOpen);
            if (!overlay) return;

            const form = overlay.querySelector('form');
            const title = overlay.querySelector('[data-modal-title]');
            const data = trigger.dataset.edit ? JSON.parse(trigger.dataset.edit) : null;

            if (form) {
                form.reset();
                form.querySelectorAll('input, select, textarea').forEach((input) => {
                    if (data && input.name in data) input.value = data[input.name];
                    else if (input.name === 'id') input.value = '';
                });
            }
            if (title) {
                title.textContent = trigger.dataset.modalHeading
                    || (data ? 'Ubah Data' : 'Tambah Data');
            }

            overlay.classList.add('open');
            document.body.style.overflow = 'hidden';
            overlay.querySelector('input:not([type=hidden]), select, textarea')?.focus();
        });
    });

    document.querySelectorAll('.modal-overlay').forEach((overlay) => {
        const close = () => {
            overlay.classList.remove('open');
            document.body.style.overflow = '';
        };
        overlay.addEventListener('click', (e) => e.target === overlay && close());
        overlay.querySelectorAll('[data-modal-close]').forEach((btn) => btn.addEventListener('click', close));
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay.open').forEach((o) => o.classList.remove('open'));
            document.body.style.overflow = '';
        }
    });
}

function initConfirmForms() {
    document.querySelectorAll('form[data-confirm]').forEach((form) => {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            Swal.fire({
                title: 'Hapus data ini?',
                text: form.dataset.confirm,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, hapus',
                cancelButtonText: 'Batal',
                reverseButtons: true,
                ...swalGlass,
            }).then((result) => {
                if (result.isConfirmed) form.submit();
            });
        });
    });
}

function initCounters() {
    document.querySelectorAll('[data-count]').forEach((el) => {
        const target = parseFloat(el.dataset.count);
        const decimals = parseInt(el.dataset.decimals || '0', 10);
        const duration = 900;
        const start = performance.now();

        const tick = (now) => {
            const progress = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = (target * eased).toFixed(decimals);
            if (progress < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
    });
}
