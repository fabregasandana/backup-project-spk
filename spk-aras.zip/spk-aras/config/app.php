<?php

declare(strict_types=1);

define('ROOT_PATH', dirname(__DIR__));
define('BASE_URL', '/' . basename(ROOT_PATH));
define('APP_NAME', 'SPK ARAS');

date_default_timezone_set('Asia/Jakarta');

require_once ROOT_PATH . '/vendor/autoload.php';
require_once __DIR__ . '/database.php';
require_once ROOT_PATH . '/app/helpers.php';
require_once ROOT_PATH . '/app/Kriteria.php';
require_once ROOT_PATH . '/app/Alternatif.php';
require_once ROOT_PATH . '/app/Penilaian.php';
require_once ROOT_PATH . '/app/Aras.php';
require_once ROOT_PATH . '/app/Laporan.php';
require_once ROOT_PATH . '/app/Auth.php';

session_start();
