<?php
/** Template dokumen laporan (tampilan kertas). Dipakai layar, cetak, PDF, dan Excel. */
$kriteria = $laporan['kriteria'];
$alternatif = $laporan['alternatif'];
$matriks = $laporan['matriks'];
$peringkat = $laporan['peringkat'];
$juara = $laporan['juara'];
?>
<div class="laporan-doc">
    <style>
        .laporan-doc { background: #ffffff; color: #182135; font-family: 'Inter', 'Segoe UI', sans-serif; font-size: 12px; line-height: 1.55; padding: 42px 46px; }
        .laporan-doc .doc-kop { text-align: center; border-bottom: 3px double #10243f; padding-bottom: 14px; margin-bottom: 18px; }
        .laporan-doc .doc-kop h1 { font-size: 16.5px; letter-spacing: 0.07em; text-transform: uppercase; margin: 0 0 5px; color: #0a1128; }
        .laporan-doc .doc-kop h2 { font-size: 12.5px; font-weight: 600; margin: 0 0 6px; color: #24344d; }
        .laporan-doc .doc-kop p { margin: 0; font-size: 11px; color: #5b6779; }
        .laporan-doc .doc-meta { width: 100%; border: none; border-collapse: collapse; margin-bottom: 8px; font-size: 11px; color: #41506b; }
        .laporan-doc .doc-meta td { border: none; padding: 1.5px 0; }
        .laporan-doc .doc-meta td:first-child { width: 150px; }
        .laporan-doc h3.sec { font-size: 12px; text-transform: uppercase; letter-spacing: 0.05em; color: #0a1128; margin: 20px 0 8px; border-left: 4px solid #0f9d6e; padding-left: 8px; }
        .laporan-doc table.data { width: 100%; border-collapse: collapse; }
        .laporan-doc table.data th, .laporan-doc table.data td { border: 1px solid #b9c2d0; padding: 6px 8px; font-size: 11px; text-align: left; vertical-align: top; }
        .laporan-doc table.data th { background: #eef3f9; color: #0a1128; font-weight: 700; }
        .laporan-doc table.data th.num, .laporan-doc table.data td.num { text-align: right; }
        .laporan-doc table.data th.ctr, .laporan-doc table.data td.ctr { text-align: center; }
        .laporan-doc table.data tr.winner td { background: #eafaf2; font-weight: 700; }
        .laporan-doc .doc-note { font-size: 10.5px; color: #5b6779; margin: 5px 0 0; }
        .laporan-doc .doc-kesimpulan p { margin: 0 0 6px; text-align: justify; }
        .laporan-doc .doc-ttd { width: 100%; border: none; border-collapse: collapse; margin-top: 36px; }
        .laporan-doc .doc-ttd td { border: none; width: 50%; text-align: center; font-size: 11.5px; padding: 0; color: #24344d; }
        .laporan-doc .ttd-space { height: 68px; }
    </style>

    <div class="doc-kop">
        <h1>Laporan Hasil Perhitungan</h1>
        <h2>Sistem Pendukung Keputusan Pemilihan Peralatan Produksi Hemat Energi untuk UMKM Makanan</h2>
        <p>Metode: ARAS (Additive Ratio Assessment)</p>
    </div>

    <table class="doc-meta">
        <tr><td>Tanggal Laporan</td><td>: <?= e($laporan['tanggal']) ?></td></tr>
        <tr><td>Jumlah Kriteria</td><td>: <?= count($kriteria) ?> kriteria</td></tr>
        <tr><td>Jumlah Alternatif</td><td>: <?= count($alternatif) ?> peralatan</td></tr>
    </table>

    <h3 class="sec">A. Kriteria Penilaian</h3>
    <table class="data">
        <thead>
            <tr>
                <th class="ctr" style="width:44px">Kode</th>
                <th>Nama Kriteria</th>
                <th class="ctr" style="width:70px">Tipe</th>
                <th class="num" style="width:70px">Bobot</th>
                <th style="width:90px">Satuan</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($kriteria as $kri): ?>
                <tr>
                    <td class="ctr"><?= e($kri['kode']) ?></td>
                    <td><?= e($kri['nama']) ?></td>
                    <td class="ctr"><?= ucfirst($kri['tipe']) ?></td>
                    <td class="num"><?= format_desimal((float) $kri['bobot'], 2) ?>%</td>
                    <td><?= e($kri['satuan'] ?? '-') ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <p class="doc-note">Tipe benefit: semakin besar nilai semakin baik. Tipe cost: semakin kecil nilai semakin baik.</p>

    <h3 class="sec">B. Matriks Penilaian</h3>
    <table class="data">
        <thead>
            <tr>
                <th class="ctr" style="width:44px">Kode</th>
                <th>Alternatif</th>
                <?php foreach ($kriteria as $kri): ?>
                    <th class="num"><?= e($kri['kode']) ?></th>
                <?php endforeach; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($alternatif as $alt): ?>
                <tr>
                    <td class="ctr"><?= e($alt['kode']) ?></td>
                    <td><?= e($alt['nama']) ?></td>
                    <?php foreach ($kriteria as $kri): ?>
                        <td class="num"><?= format_nilai((float) ($matriks[$alt['id']][$kri['id']] ?? 0)) ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <p class="doc-note">
        Keterangan kriteria:
        <?php foreach ($kriteria as $i => $kri): ?>
            <?= e($kri['kode']) ?> = <?= e($kri['nama']) ?><?= $i < count($kriteria) - 1 ? '; ' : '.' ?>
        <?php endforeach; ?>
    </p>

    <h3 class="sec">C. Hasil Perhitungan dan Peringkat</h3>
    <table class="data">
        <thead>
            <tr>
                <th class="ctr" style="width:60px">Peringkat</th>
                <th class="ctr" style="width:44px">Kode</th>
                <th>Alternatif</th>
                <th class="num" style="width:80px">Nilai S</th>
                <th class="num" style="width:80px">Nilai K</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($peringkat as $item): ?>
                <tr class="<?= $item['rank'] === 1 ? 'winner' : '' ?>">
                    <td class="ctr"><?= $item['rank'] ?></td>
                    <td class="ctr"><?= e($item['alt']['kode']) ?></td>
                    <td><?= e($item['alt']['nama']) ?></td>
                    <td class="num"><?= format_desimal($item['s']) ?></td>
                    <td class="num"><?= format_desimal($item['k']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <p class="doc-note">Nilai K (derajat kegunaan) = S alternatif dibagi S kondisi optimal; semakin mendekati 1 semakin layak dipilih.</p>

    <h3 class="sec">D. Kesimpulan</h3>
    <div class="doc-kesimpulan">
        <?php if ($juara !== null): ?>
            <p>
                Berdasarkan hasil perhitungan metode ARAS terhadap <?= count($alternatif) ?> alternatif peralatan produksi
                dengan <?= count($kriteria) ?> kriteria, peralatan <strong><?= e($juara['alt']['nama']) ?></strong>
                (<?= e($juara['alt']['kode']) ?>) menempati peringkat pertama dengan derajat kegunaan
                K = <?= format_desimal($juara['k']) ?> (<?= format_desimal($juara['k'] * 100, 2) ?>% dari kondisi optimal),
                sehingga direkomendasikan sebagai pilihan investasi peralatan produksi hemat energi.
            </p>
            <p>
                Alternatif peringkat berikutnya,
                <?php foreach (array_slice($peringkat, 1, 2) as $i => $item): ?>
                    <?= e($item['alt']['nama']) ?> (K = <?= format_desimal($item['k']) ?>)<?= $i === 0 ? ' dan ' : '' ?>
                <?php endforeach; ?>,
                dapat dipertimbangkan sebagai cadangan apabila ketersediaan anggaran berubah.
            </p>
        <?php endif; ?>
    </div>

    <table class="doc-ttd">
        <tr>
            <td>Mengetahui,<br>Pemilik UMKM</td>
            <td>............., <?= e($laporan['tanggal']) ?><br>Pengambil Keputusan</td>
        </tr>
        <tr>
            <td class="ttd-space"></td>
            <td class="ttd-space"></td>
        </tr>
        <tr>
            <td>(..............................)</td>
            <td>(..............................)</td>
        </tr>
    </table>
</div>
