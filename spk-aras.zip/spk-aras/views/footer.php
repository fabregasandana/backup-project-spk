        </main>

        <footer class="footer">
            <p>&copy; <?= date('Y') ?> <?= APP_NAME ?> &middot; Sistem Pendukung Keputusan Pemilihan Peralatan Produksi Hemat Energi untuk UMKM Makanan</p>
        </footer>
    </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/sweetalert2.all.min.js"></script>
<script>
    window.APP = {
        baseUrl: <?= json_encode(BASE_URL) ?>,
        flash: <?= json_encode(pull_flash()) ?>
    };
</script>
<script src="<?= BASE_URL ?>/assets/js/app.js"></script>
</body>
</html>
