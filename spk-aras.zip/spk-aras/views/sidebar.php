<?php
$menu = [
    'dashboard' => ['index.php', 'layout-dashboard', 'Dashboard'],
    'kriteria' => ['kriteria.php', 'sliders-horizontal', 'Data Kriteria'],
    'alternatif' => ['alternatif.php', 'boxes', 'Data Alternatif'],
    'penilaian' => ['penilaian.php', 'clipboard-list', 'Penilaian'],
    'hasil' => ['hasil.php', 'trophy', 'Hasil ARAS'],
    'laporan' => ['laporan.php', 'file-text', 'Laporan'],
];
$user = Auth::user();
?>
<div class="sidebar-backdrop" id="sidebarBackdrop"></div>
<aside class="sidebar glass" id="sidebar">
    <a class="brand" href="<?= BASE_URL ?>/index.php">
        <span class="brand-icon"><?= icon('zap', 22) ?></span>
        <span>
            <strong><?= APP_NAME ?></strong>
            <small>Peralatan Hemat Energi</small>
        </span>
    </a>

    <nav class="nav">
        <p class="nav-label">Menu Utama</p>
        <?php foreach ($menu as $key => [$href, $ikon, $label]): ?>
            <a class="nav-link <?= $active === $key ? 'active' : '' ?>" href="<?= BASE_URL ?>/<?= $href ?>">
                <?= icon($ikon, 19) ?>
                <span><?= $label ?></span>
            </a>
        <?php endforeach; ?>
    </nav>

    <div class="sidebar-foot">
        <div class="user-card">
            <span class="user-avatar"><?= icon('circle-user-round', 18) ?></span>
            <span class="user-info">
                <strong><?= e($user['nama'] ?? 'Pengguna') ?></strong>
                <small>@<?= e($user['username'] ?? '-') ?></small>
            </span>
            <a class="btn btn-icon btn-danger" href="<?= BASE_URL ?>/logout.php" title="Keluar" aria-label="Keluar">
                <?= icon('log-out', 16) ?>
            </a>
        </div>

        <div class="method-card">
            <p class="method-title"><?= icon('info', 14) ?> Tentang Metode</p>
            <p class="method-desc">
                ARAS membandingkan tiap alternatif terhadap nilai optimal
                untuk menghasilkan derajat kegunaan (K).
            </p>
        </div>
    </div>
</aside>
