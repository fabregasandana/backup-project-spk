<?php
$pageTitle = $pageTitle ?? 'Dashboard';
$active = $active ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> &middot; <?= APP_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="bg-decor" aria-hidden="true">
    <span class="orb orb-emerald"></span>
    <span class="orb orb-gold"></span>
    <span class="orb orb-navy"></span>
</div>

<div class="app-shell">
    <?php require ROOT_PATH . '/views/sidebar.php'; ?>
    <div class="main-area">
        <header class="topbar glass">
            <div class="topbar-left">
                <button type="button" class="hamburger" id="hamburger" aria-label="Buka menu">
                    <?= icon('menu', 22) ?>
                </button>
                <div>
                    <h1 class="page-title"><?= e($pageTitle) ?></h1>
                    <p class="page-subtitle">SPK Peralatan Produksi Hemat Energi &mdash; UMKM Makanan</p>
                </div>
            </div>
            <div class="topbar-right">
                <span class="chip chip-method"><?= icon('calculator', 15) ?> Metode ARAS</span>
                <a class="btn btn-gold btn-sm" href="<?= BASE_URL ?>/hasil.php">
                    <?= icon('trophy', 16) ?> Lihat Hasil
                </a>
            </div>
        </header>

        <main class="content">
