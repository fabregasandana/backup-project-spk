<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config/app.php';

Auth::requireLogin();

$laporan = Laporan::data();
if (!$laporan['lengkap']) {
    redirect('laporan.php');
}

$kriteria = $laporan['kriteria'];
$alternatif = $laporan['alternatif'];
$matriks = $laporan['matriks'];

header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
header('Content-Disposition: attachment; filename="laporan-spk-aras-' . date('Y-m-d') . '.xls"');
header('Pragma: no-cache');
header('Expires: 0');
?>
<html xmlns:x="urn:schemas-microsoft-com:office:excel">
<head><meta charset="UTF-8"></head>
<body>
<table border="1">
    <tr><th colspan="<?= 3 + count($kriteria) ?>">LAPORAN HASIL PERHITUNGAN SPK - PERALATAN PRODUKSI HEMAT ENERGI UNTUK UMKM MAKANAN</th></tr>
    <tr><th colspan="<?= 3 + count($kriteria) ?>">Metode: ARAS (Additive Ratio Assessment)</th></tr>
    <tr><td colspan="<?= 3 + count($kriteria) ?>">Tanggal Laporan: <?= e($laporan['tanggal']) ?></td></tr>
    <tr><td colspan="<?= 3 + count($kriteria) ?>"></td></tr>

    <tr><th colspan="<?= 3 + count($kriteria) ?>">A. KRITERIA PENILAIAN</th></tr>
    <tr>
        <th>Kode</th><th>Nama Kriteria</th><th>Tipe</th><th>Bobot (%)</th><th>Satuan</th>
        <th colspan="<?= max(0, count($kriteria) - 2) ?>"></th>
    </tr>
    <?php foreach ($kriteria as $kri): ?>
        <tr>
            <td><?= e($kri['kode']) ?></td>
            <td><?= e($kri['nama']) ?></td>
            <td><?= ucfirst($kri['tipe']) ?></td>
            <td><?= format_desimal((float) $kri['bobot'], 2) ?></td>
            <td><?= e($kri['satuan'] ?? '-') ?></td>
            <td colspan="<?= max(0, count($kriteria) - 2) ?>"></td>
        </tr>
    <?php endforeach; ?>
    <tr><td colspan="<?= 3 + count($kriteria) ?>"></td></tr>

    <tr><th colspan="<?= 3 + count($kriteria) ?>">B. MATRIKS PENILAIAN</th></tr>
    <tr>
        <th>Kode</th><th>Alternatif</th>
        <?php foreach ($kriteria as $kri): ?>
            <th><?= e($kri['kode']) ?> - <?= e($kri['nama']) ?></th>
        <?php endforeach; ?>
        <th colspan="<?= max(0, 3 - count($kriteria) + count($kriteria) - 3) ?>"></th>
    </tr>
    <?php foreach ($alternatif as $alt): ?>
        <tr>
            <td><?= e($alt['kode']) ?></td>
            <td><?= e($alt['nama']) ?></td>
            <?php foreach ($kriteria as $kri): ?>
                <td><?= format_nilai((float) ($matriks[$alt['id']][$kri['id']] ?? 0)) ?></td>
            <?php endforeach; ?>
        </tr>
    <?php endforeach; ?>
    <tr><td colspan="<?= 3 + count($kriteria) ?>"></td></tr>

    <tr><th colspan="<?= 3 + count($kriteria) ?>">C. HASIL PERHITUNGAN DAN PERINGKAT</th></tr>
    <tr>
        <th>Peringkat</th><th>Kode</th><th>Alternatif</th><th>Nilai S</th><th>Nilai K</th>
        <th colspan="<?= max(0, count($kriteria) - 2) ?>"></th>
    </tr>
    <?php foreach ($laporan['peringkat'] as $item): ?>
        <tr>
            <td><?= $item['rank'] ?></td>
            <td><?= e($item['alt']['kode']) ?></td>
            <td><?= e($item['alt']['nama']) ?></td>
            <td><?= format_desimal($item['s']) ?></td>
            <td><?= format_desimal($item['k']) ?></td>
            <td colspan="<?= max(0, count($kriteria) - 2) ?>"></td>
        </tr>
    <?php endforeach; ?>
    <tr><td colspan="<?= 3 + count($kriteria) ?>"></td></tr>

    <tr><th colspan="<?= 3 + count($kriteria) ?>">D. KESIMPULAN</th></tr>
    <?php if ($laporan['juara'] !== null): ?>
        <tr>
            <td colspan="<?= 3 + count($kriteria) ?>">
                Rekomendasi terbaik: <?= e($laporan['juara']['alt']['nama']) ?>
                (<?= e($laporan['juara']['alt']['kode']) ?>) dengan derajat kegunaan K =
                <?= format_desimal($laporan['juara']['k']) ?>
                (<?= format_desimal($laporan['juara']['k'] * 100, 2) ?>% dari kondisi optimal).
            </td>
        </tr>
    <?php endif; ?>
</table>
</body>
</html>
