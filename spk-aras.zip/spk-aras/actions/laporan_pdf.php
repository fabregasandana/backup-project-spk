<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config/app.php';

Auth::requireLogin();

use Dompdf\Dompdf;

$laporan = Laporan::data();
if (!$laporan['lengkap']) {
    redirect('laporan.php');
}

$dokumen = Laporan::renderHtml($laporan);
$html = '<!DOCTYPE html><html lang="id"><head><meta charset="utf-8">'
    . '<title>Laporan SPK ARAS</title></head><body>' . $dokumen . '</body></html>';

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream('laporan-spk-aras-' . date('Y-m-d') . '.pdf', ['Attachment' => true]);
