<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config/app.php';

Auth::requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('kriteria.php');
}
csrf_verify();

$aksi = $_POST['aksi'] ?? '';

if ($aksi === 'simpan') {
    $id = (int) ($_POST['id'] ?? 0);
    $data = [
        'kode' => $_POST['kode'] ?? '',
        'nama' => $_POST['nama'] ?? '',
        'tipe' => $_POST['tipe'] ?? 'benefit',
        'bobot' => (float) ($_POST['bobot'] ?? 0),
        'satuan' => $_POST['satuan'] ?? '',
        'keterangan' => $_POST['keterangan'] ?? '',
    ];

    $kode = strtoupper(trim($data['kode']));

    if ($kode === '' || trim($data['nama']) === '' || $data['bobot'] <= 0 || $data['bobot'] > 100) {
        flash('error', 'Data kriteria tidak valid. Kode dan nama wajib diisi, bobot harus 1-100.');
        redirect('kriteria.php');
    }

    if (Kriteria::kodeAda($kode, $id ?: null)) {
        flash('error', "Kode kriteria {$kode} sudah digunakan.");
        redirect('kriteria.php');
    }

    if ($id > 0) {
        Kriteria::update($id, $data);
        flash('success', "Kriteria {$kode} berhasil diperbarui.");
    } else {
        Kriteria::create($data);
        flash('success', "Kriteria {$kode} berhasil ditambahkan.");
    }
} elseif ($aksi === 'hapus') {
    $id = (int) ($_POST['id'] ?? 0);
    $kri = Kriteria::find($id);
    if ($kri !== null) {
        Kriteria::delete($id);
        flash('success', "Kriteria {$kri['kode']} beserta seluruh penilaiannya berhasil dihapus.");
    }
}

redirect('kriteria.php');
