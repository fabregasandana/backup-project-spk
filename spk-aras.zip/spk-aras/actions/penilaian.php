<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config/app.php';

Auth::requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('penilaian.php');
}
csrf_verify();

$nilai = $_POST['nilai'] ?? [];
if (!is_array($nilai) || $nilai === []) {
    flash('error', 'Tidak ada data penilaian yang dikirim.');
    redirect('penilaian.php');
}

$kriteriaIds = array_column(Kriteria::all(), 'id');
$alternatifIds = array_column(Alternatif::all(), 'id');
$tersimpan = 0;

foreach ($nilai as $idAlt => $baris) {
    if (!in_array((int) $idAlt, $alternatifIds, true) || !is_array($baris)) {
        continue;
    }
    foreach ($baris as $idKri => $v) {
        if (!in_array((int) $idKri, $kriteriaIds, true)) {
            continue;
        }
        Penilaian::simpan((int) $idAlt, (int) $idKri, max(0, (float) $v));
        $tersimpan++;
    }
}

flash('success', "{$tersimpan} nilai penilaian berhasil disimpan.");
redirect('penilaian.php');
