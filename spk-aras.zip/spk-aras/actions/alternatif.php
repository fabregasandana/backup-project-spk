<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config/app.php';

Auth::requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('alternatif.php');
}
csrf_verify();

$aksi = $_POST['aksi'] ?? '';

if ($aksi === 'simpan') {
    $id = (int) ($_POST['id'] ?? 0);
    $data = [
        'kode' => $_POST['kode'] ?? '',
        'nama' => $_POST['nama'] ?? '',
        'kategori' => $_POST['kategori'] ?? '',
        'keterangan' => $_POST['keterangan'] ?? '',
    ];

    $kode = strtoupper(trim($data['kode']));

    if ($kode === '' || trim($data['nama']) === '') {
        flash('error', 'Kode dan nama alternatif wajib diisi.');
        redirect('alternatif.php');
    }

    if (Alternatif::kodeAda($kode, $id ?: null)) {
        flash('error', "Kode alternatif {$kode} sudah digunakan.");
        redirect('alternatif.php');
    }

    if ($id > 0) {
        Alternatif::update($id, $data);
        flash('success', "Alternatif {$kode} berhasil diperbarui.");
    } else {
        Alternatif::create($data);
        flash('success', "Alternatif {$kode} berhasil ditambahkan.");
    }
} elseif ($aksi === 'hapus') {
    $id = (int) ($_POST['id'] ?? 0);
    $alt = Alternatif::find($id);
    if ($alt !== null) {
        Alternatif::delete($id);
        flash('success', "Alternatif {$alt['kode']} beserta seluruh penilaiannya berhasil dihapus.");
    }
}

redirect('alternatif.php');
