<?php

declare(strict_types=1);

require_once __DIR__ . '/config/app.php';

Auth::requireLogin();

$kriteria = Kriteria::all();
$alternatif = Alternatif::all();
$matriks = Penilaian::matrix();

$pageTitle = 'Penilaian';
$active = 'penilaian';
require ROOT_PATH . '/views/header.php';
?>

<div class="page-head">
    <div>
        <h2>Matriks Penilaian</h2>
        <p>
            Isi nilai setiap peralatan sesuai satuan aslinya — misalnya daya dalam watt, harga dalam rupiah,
            garansi dalam bulan, dan kriteria kualitatif dalam skor 1&ndash;5.
            Sistem akan menormalisasi skalanya secara otomatis.
        </p>
    </div>
</div>

<?php if ($kriteria === [] || $alternatif === []): ?>
    <section class="card glass">
        <div class="empty-state">
            <span class="empty-icon"><?= icon('clipboard-list', 26) ?></span>
            <h4>Data belum siap</h4>
            <p>
                Penilaian membutuhkan minimal satu kriteria dan satu alternatif.
                Lengkapi dulu pada menu <a href="<?= BASE_URL ?>/kriteria.php" style="color:var(--emerald-400)">Data Kriteria</a>
                dan <a href="<?= BASE_URL ?>/alternatif.php" style="color:var(--emerald-400)">Data Alternatif</a>.
            </p>
        </div>
    </section>
<?php else: ?>
    <section class="card glass">
        <div class="card-head">
            <h3 class="card-title">
                <span class="title-icon"><?= icon('clipboard-list', 17) ?></span>
                Nilai Alternatif terhadap Kriteria
            </h3>
            <div class="legend" style="margin:0">
                <span><span class="badge badge-benefit">Benefit</span> besar = baik</span>
                <span><span class="badge badge-cost">Cost</span> kecil = baik</span>
            </div>
        </div>

        <form method="post" action="<?= BASE_URL ?>/actions/penilaian.php" id="formPenilaian">
            <?= csrf_field() ?>
            <div class="table-wrap">
                <table style="min-width: <?= 190 + count($kriteria) * 140 ?>px">
                    <thead>
                        <tr>
                            <th style="min-width: 190px">Alternatif</th>
                            <?php foreach ($kriteria as $kri): ?>
                                <th class="th-kriteria t-right">
                                    <span class="kode-chip" style="margin-bottom:6px"><?= e($kri['kode']) ?></span>
                                    <span class="th-nama"><?= e($kri['nama']) ?></span>
                                    <span class="th-meta" style="justify-content:flex-end">
                                        <span class="badge badge-<?= $kri['tipe'] ?>"><?= ucfirst($kri['tipe']) ?></span>
                                        <?php if ($kri['satuan']): ?>
                                            <span class="satuan"><?= e($kri['satuan']) ?></span>
                                        <?php endif; ?>
                                    </span>
                                </th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($alternatif as $alt): ?>
                            <tr>
                                <td>
                                    <div class="td-main"><span class="kode-chip alt"><?= e($alt['kode']) ?></span> &nbsp;<?= e($alt['nama']) ?></div>
                                    <?php if ($alt['kategori']): ?>
                                        <div class="td-sub"><?= e($alt['kategori']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <?php foreach ($kriteria as $kri): ?>
                                    <?php $nilai = $matriks[$alt['id']][$kri['id']] ?? 0.0; ?>
                                    <td class="t-right">
                                        <input class="input-nilai" type="number"
                                               name="nilai[<?= (int) $alt['id'] ?>][<?= (int) $kri['id'] ?>]"
                                               value="<?= $nilai > 0 ? rtrim(rtrim(number_format($nilai, 2, '.', ''), '0'), '.') : '' ?>"
                                               min="0" step="any" placeholder="0"
                                               aria-label="Nilai <?= e($alt['kode']) ?> untuk <?= e($kri['nama']) ?>">
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="modal-actions" style="margin-top:20px">
                <button type="button" class="btn btn-ghost" id="btnResetPenilaian"><?= icon('rotate-ccw', 16) ?> Kembalikan Nilai Tersimpan</button>
                <button type="submit" class="btn btn-primary"><?= icon('check', 16) ?> Simpan Semua Penilaian</button>
            </div>
        </form>
        <p class="table-scroll-note"><?= icon('info', 13) ?> Geser tabel ke samping bila kolom tidak terlihat seluruhnya. Kosongkan sel berarti nilai 0.</p>
    </section>
<?php endif; ?>

<?php require ROOT_PATH . '/views/footer.php'; ?>
