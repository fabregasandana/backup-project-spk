<?php

declare(strict_types=1);

require_once __DIR__ . '/config/app.php';

Auth::requireLogin();

$kriteria = Kriteria::all();
$totalBobot = Kriteria::totalBobot();
$bobotSesuai = abs($totalBobot - 100) <= 0.001;

$pageTitle = 'Data Kriteria';
$active = 'kriteria';
require ROOT_PATH . '/views/header.php';
?>

<div class="page-head">
    <div>
        <h2>Kriteria Penilaian</h2>
        <p>
            Enam kriteria pembanding peralatan produksi: efisiensi listrik, kapasitas produksi,
            harga, garansi, kemudahan perawatan, dan dampak kualitas produk.
            Tipe <strong>benefit</strong> = semakin besar semakin baik, tipe <strong>cost</strong> = semakin kecil semakin baik.
        </p>
    </div>
    <button type="button" class="btn btn-primary" data-modal-open="modalKriteria" data-modal-heading="Tambah Kriteria">
        <?= icon('plus', 17) ?> Tambah Kriteria
    </button>
</div>

<?php if ($kriteria !== [] && !$bobotSesuai): ?>
    <div class="notice notice-warn">
        <?= icon('triangle-alert', 20) ?>
        <div>
            <strong>Total bobot saat ini <?= format_desimal($totalBobot, 2) ?>%</strong>
            <p>Usahakan total bobot seluruh kriteria tepat 100% agar pembobotan sesuai kaidah ARAS. Perhitungan tetap berjalan karena bobot akan dinormalisasi otomatis.</p>
        </div>
    </div>
<?php endif; ?>

<section class="card glass">
    <div class="card-head">
        <h3 class="card-title">
            <span class="title-icon"><?= icon('sliders-horizontal', 17) ?></span>
            Daftar Kriteria (<?= count($kriteria) ?>)
        </h3>
        <span class="badge <?= $bobotSesuai ? 'badge-ok' : 'badge-warn' ?>">
            <?= icon('percent', 13) ?> Total Bobot <?= format_desimal($totalBobot, 2) ?>%
        </span>
    </div>

    <?php if ($kriteria === []): ?>
        <div class="empty-state">
            <span class="empty-icon"><?= icon('sliders-horizontal', 26) ?></span>
            <h4>Belum ada kriteria</h4>
            <p>Klik tombol "Tambah Kriteria" untuk menambahkan kriteria penilaian pertama.</p>
        </div>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Nama Kriteria</th>
                        <th>Tipe</th>
                        <th style="min-width: 170px">Bobot</th>
                        <th>Satuan</th>
                        <th>Keterangan</th>
                        <th class="t-right">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($kriteria as $kri): ?>
                        <tr>
                            <td><span class="kode-chip"><?= e($kri['kode']) ?></span></td>
                            <td class="td-main"><?= e($kri['nama']) ?></td>
                            <td>
                                <span class="badge badge-<?= $kri['tipe'] ?>">
                                    <?= $kri['tipe'] === 'benefit' ? icon('trending-up', 12) : icon('trending-up', 12, 'badge-flip') ?>
                                    <?= ucfirst($kri['tipe']) ?>
                                </span>
                            </td>
                            <td>
                                <div class="weight-item-head">
                                    <span></span>
                                    <span class="weight-num"><?= format_desimal((float) $kri['bobot'], 2) ?>%</span>
                                </div>
                                <div class="weight-bar"><span style="width: <?= min(100, (float) $kri['bobot']) ?>%"></span></div>
                            </td>
                            <td class="td-sub" style="margin:0"><?= e($kri['satuan'] ?? '-') ?></td>
                            <td class="td-sub" style="margin:0; max-width: 260px"><?= e($kri['keterangan'] ?? '-') ?></td>
                            <td>
                                <div class="cell-actions">
                                    <button type="button" class="btn btn-icon btn-ghost btn-edit"
                                            data-modal-open="modalKriteria"
                                            data-modal-heading="Ubah Kriteria"
                                            data-edit='<?= e(json_encode([
                                                'id' => $kri['id'],
                                                'kode' => $kri['kode'],
                                                'nama' => $kri['nama'],
                                                'tipe' => $kri['tipe'],
                                                'bobot' => rtrim(rtrim(number_format((float) $kri['bobot'], 2, '.', ''), '0'), '.'),
                                                'satuan' => $kri['satuan'] ?? '',
                                                'keterangan' => $kri['keterangan'] ?? '',
                                            ], JSON_HEX_APOS)) ?>'
                                            aria-label="Ubah kriteria <?= e($kri['kode']) ?>">
                                        <?= icon('square-pen', 16) ?>
                                    </button>
                                    <form method="post" action="<?= BASE_URL ?>/actions/kriteria.php"
                                          data-confirm="Kriteria <?= e($kri['kode']) ?> (<?= e($kri['nama']) ?>) dan seluruh nilai penilaiannya akan dihapus permanen.">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="aksi" value="hapus">
                                        <input type="hidden" name="id" value="<?= (int) $kri['id'] ?>">
                                        <button type="submit" class="btn btn-icon btn-ghost btn-danger" aria-label="Hapus kriteria <?= e($kri['kode']) ?>">
                                            <?= icon('trash-2', 16) ?>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<div class="modal-overlay" id="modalKriteria">
    <div class="modal glass">
        <div class="modal-head">
            <h3 data-modal-title>Tambah Kriteria</h3>
            <button type="button" class="modal-close" data-modal-close aria-label="Tutup"><?= icon('x', 17) ?></button>
        </div>
        <form method="post" action="<?= BASE_URL ?>/actions/kriteria.php">
            <?= csrf_field() ?>
            <input type="hidden" name="aksi" value="simpan">
            <input type="hidden" name="id" value="">

            <div class="field-row">
                <div class="field">
                    <label for="kriKode">Kode Kriteria <span class="req">*</span></label>
                    <input type="text" id="kriKode" name="kode" maxlength="5" placeholder="C1" required>
                </div>
                <div class="field">
                    <label for="kriBobot">Bobot (%) <span class="req">*</span></label>
                    <input type="number" id="kriBobot" name="bobot" min="0.01" max="100" step="0.01" placeholder="25" required>
                </div>
            </div>

            <div class="field">
                <label for="kriNama">Nama Kriteria <span class="req">*</span></label>
                <input type="text" id="kriNama" name="nama" maxlength="100" placeholder="Efisiensi Listrik" required>
            </div>

            <div class="field-row">
                <div class="field">
                    <label for="kriTipe">Tipe Kriteria</label>
                    <select id="kriTipe" name="tipe">
                        <option value="benefit">Benefit (besar = baik)</option>
                        <option value="cost">Cost (kecil = baik)</option>
                    </select>
                </div>
                <div class="field">
                    <label for="kriSatuan">Satuan</label>
                    <input type="text" id="kriSatuan" name="satuan" maxlength="30" placeholder="watt, kg/jam, Rp">
                </div>
            </div>

            <div class="field">
                <label for="kriKeterangan">Keterangan</label>
                <textarea id="kriKeterangan" name="keterangan" maxlength="255" placeholder="Penjelasan singkat kriteria"></textarea>
            </div>

            <div class="modal-actions">
                <button type="button" class="btn btn-ghost" data-modal-close>Batal</button>
                <button type="submit" class="btn btn-primary"><?= icon('check', 16) ?> Simpan</button>
            </div>
        </form>
    </div>
</div>

<?php require ROOT_PATH . '/views/footer.php'; ?>
