<?php

declare(strict_types=1);

require_once __DIR__ . '/config/app.php';

Auth::requireLogin();

$kriteria = Kriteria::all();
$alternatif = Alternatif::all();
$matriks = Penilaian::matrix();
$lengkap = Aras::dataLengkap($kriteria, $alternatif, $matriks);

$hasil = null;
$altById = [];
$peringkat = [];
$juara = null;

if ($lengkap) {
    $hasil = Aras::hitung($kriteria, $alternatif, $matriks);
    $altById = array_column($alternatif, null, 'id');
    foreach ($hasil['k'] as $id => $nilaiK) {
        $peringkat[] = ['alt' => $altById[$id], 'k' => $nilaiK, 's' => $hasil['s'][$id], 'rank' => $hasil['peringkat'][$id]];
    }
    $juara = $peringkat[0] ?? null;
}

$pageTitle = 'Hasil Perhitungan ARAS';
$active = 'hasil';
require ROOT_PATH . '/views/header.php';
?>

<?php if (!$lengkap): ?>
    <section class="card glass">
        <div class="empty-state">
            <span class="empty-icon"><?= icon('triangle-alert', 26) ?></span>
            <h4>Data belum lengkap</h4>
            <p>
                Perhitungan ARAS membutuhkan minimal satu kriteria, satu alternatif,
                dan seluruh sel penilaian terisi nilai lebih dari 0.
                Lengkapi data terlebih dahulu.
            </p>
            <div class="hero-actions" style="justify-content:center">
                <a class="btn btn-primary btn-sm" href="<?= BASE_URL ?>/penilaian.php"><?= icon('clipboard-list', 15) ?> Isi Penilaian</a>
                <a class="btn btn-ghost btn-sm" href="<?= BASE_URL ?>/kriteria.php"><?= icon('sliders-horizontal', 15) ?> Data Kriteria</a>
                <a class="btn btn-ghost btn-sm" href="<?= BASE_URL ?>/alternatif.php"><?= icon('boxes', 15) ?> Data Alternatif</a>
            </div>
        </div>
    </section>
<?php else: ?>

    <div class="page-head">
        <div>
            <h2>Peringkat Kelayakan Peralatan</h2>
            <p>
                Hasil perhitungan metode ARAS atas <?= count($alternatif) ?> alternatif dan <?= count($kriteria) ?> kriteria.
                Derajat kegunaan (K) menunjukkan kedekatan alternatif terhadap kondisi optimal;
                nilai tertinggi adalah rekomendasi terbaik.
            </p>
        </div>
    </div>

    <!-- Podium tiga besar -->
    <section class="podium">
        <?php foreach (array_slice($peringkat, 0, 3) as $i => $item): ?>
            <div class="rank-card glass <?= $i === 0 ? 'champion' : '' ?>">
                <?php if ($i === 0): ?>
                    <span class="crown"><?= icon('crown', 22) ?></span>
                <?php endif; ?>
                <p class="rank-pos">
                    <span class="medal medal-<?= $i + 1 ?>"><?= $i + 1 ?></span>
                    <?= $i === 0 ? 'Rekomendasi Terbaik' : 'Peringkat ' . ($i + 1) ?>
                </p>
                <h3><?= e($item['alt']['nama']) ?></h3>
                <p class="rank-cat"><?= e($item['alt']['kode']) ?><?= $item['alt']['kategori'] ? ' &middot; ' . e($item['alt']['kategori']) : '' ?></p>
                <div class="rank-k">
                    <strong><?= format_desimal($item['k']) ?></strong>
                    <span>derajat kegunaan<br>(<?= format_desimal($item['k'] * 100, 2) ?>% dari optimal)</span>
                </div>
            </div>
        <?php endforeach; ?>
    </section>

    <?php if ($juara !== null): ?>
        <section class="card glass conclusion">
            <span class="con-icon"><?= icon('award', 24) ?></span>
            <div>
                <h3>Kesimpulan</h3>
                <p>
                    Berdasarkan perhitungan metode ARAS, peralatan
                    <strong><?= e($juara['alt']['nama']) ?></strong> (<?= e($juara['alt']['kode']) ?>)
                    menempati peringkat pertama dengan derajat kegunaan
                    <strong>K = <?= format_desimal($juara['k']) ?></strong>
                    (<?= format_desimal($juara['k'] * 100, 2) ?>% dari kondisi optimal),
                    sehingga paling layak dipilih sebagai investasi peralatan produksi hemat energi.
                    <?= count($peringkat) > 1 ? 'Alternatif peringkat kedua dan ketiga dapat menjadi cadangan bila anggaran memungkinkan.' : '' ?>
                </p>
            </div>
        </section>
    <?php endif; ?>

    <!-- Peringkat lengkap + chart -->
    <div class="grid-2" style="margin-bottom:22px">
        <section class="card glass" style="margin:0">
            <div class="card-head">
                <h3 class="card-title">
                    <span class="title-icon gold"><?= icon('trophy', 17) ?></span>
                    Peringkat Lengkap
                </h3>
            </div>
            <div class="table-wrap">
                <table style="min-width:520px">
                    <thead>
                        <tr>
                            <th class="t-center">Rank</th>
                            <th>Alternatif</th>
                            <th class="t-right">S&#7522;</th>
                            <th class="t-right">K&#7522;</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($peringkat as $item): ?>
                            <tr class="<?= $item['rank'] === 1 ? 'row-winner' : '' ?>">
                                <td class="t-center"><span class="medal medal-<?= $item['rank'] <= 3 ? $item['rank'] : 'n' ?>"><?= $item['rank'] ?></span></td>
                                <td>
                                    <div class="td-main"><span class="kode-chip alt"><?= e($item['alt']['kode']) ?></span> &nbsp;<?= e($item['alt']['nama']) ?></div>
                                    <div class="k-bar" style="margin-top:7px; max-width:220px">
                                        <span style="width:<?= min(100, $item['k'] * 100) ?>%"></span>
                                    </div>
                                </td>
                                <td class="td-num"><?= format_desimal($item['s']) ?></td>
                                <td class="td-num" style="font-weight:700; color:<?= $item['rank'] === 1 ? 'var(--gold-400)' : 'var(--emerald-400)' ?>">
                                    <?= format_desimal($item['k']) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="card glass" style="margin:0">
            <div class="card-head">
                <h3 class="card-title">
                    <span class="title-icon"><?= icon('chart-column', 17) ?></span>
                    Derajat Kegunaan (K&#7522;)
                </h3>
            </div>
            <div class="k-chart">
                <?php foreach ($peringkat as $item): ?>
                    <div class="k-row <?= $item['rank'] === 1 ? 'champion' : '' ?>">
                        <span class="k-name">
                            <?= e($item['alt']['nama']) ?>
                            <small><?= e($item['alt']['kode']) ?></small>
                        </span>
                        <span class="k-bar"><span style="width:<?= min(100, $item['k'] * 100) ?>%"></span></span>
                        <span class="k-val"><?= format_desimal($item['k'] * 100, 1) ?>%</span>
                    </div>
                <?php endforeach; ?>
            </div>
            <p class="table-scroll-note" style="margin-top:18px">
                <?= icon('info', 13) ?> K&#7522; = S&#7522; / S&#8320;. Nilai 100% berarti alternatif menyamai kombinasi nilai optimal seluruh kriteria.
            </p>
        </section>
    </div>

    <!-- Rincian perhitungan -->
    <div class="page-head" style="margin-top:8px">
        <div>
            <h2>Rincian Perhitungan</h2>
            <p>Uraian setiap tahap metode ARAS, dapat dibuka untuk keperluan verifikasi dan dokumentasi.</p>
        </div>
    </div>

    <?php
    $lebarTabel = 200 + count($kriteria) * 115;

    $renderMatriks = function (array $dataBaris, callable $formatSel, string $labelKolom = 'Alternatif') use ($kriteria, $lebarTabel) {
        ?>
        <div class="table-wrap">
            <table style="min-width:<?= $lebarTabel ?>px">
                <thead>
                    <tr>
                        <th><?= $labelKolom ?></th>
                        <?php foreach ($kriteria as $kri): ?>
                            <th class="t-right"><?= e($kri['kode']) ?> &middot; <?= e($kri['nama']) ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <tr class="row-optimal">
                        <td><span class="kode-chip optimal">A0</span> &nbsp;Nilai Optimal</td>
                        <?php foreach ($kriteria as $kri): ?>
                            <td class="td-num"><?= $formatSel($dataBaris[Aras::BARIS_OPTIMAL][(int) $kri['id']] ?? 0.0) ?></td>
                        <?php endforeach; ?>
                    </tr>
                    <?php foreach ($dataBaris as $baris => $kolom): ?>
                        <?php if ($baris === Aras::BARIS_OPTIMAL) {
                            continue;
                        } ?>
                        <tr>
                            <td><?= e($kolom['_alt_kode'] ?? '') ?></td>
                            <?php foreach ($kriteria as $kri): ?>
                                <td class="td-num"><?= $formatSel($kolom[(int) $kri['id']] ?? 0.0) ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    };

    // Sisipkan kode alternatif ke baris matriks agar mudah dirender.
    $denganLabel = function (array $data) use ($alternatif): array {
        foreach ($alternatif as $alt) {
            $id = (int) $alt['id'];
            if (isset($data[$id])) {
                $data[$id]['_alt_kode'] = $alt['kode'] . ' · ' . $alt['nama'];
            }
        }
        return $data;
    };

    $formatAsli = fn($v) => format_nilai((float) $v);
    $formatEmpat = fn($v) => format_desimal((float) $v, 4);
    ?>

    <details class="calc-step glass" open>
        <summary>
            <span class="step-badge">1</span>
            <span class="summary-text">
                <h3>Matriks Keputusan</h3>
                <p>Nilai asli setiap alternatif per kriteria beserta baris nilai optimal (A0)</p>
            </span>
            <span class="chev"><?= icon('chevron-down', 18) ?></span>
        </summary>
        <div class="step-content">
            <span class="formula">A0: x&#8320;&#395; = maks x&#7522;&#395; (benefit) &nbsp;&middot;&nbsp; x&#8320;&#395; = min x&#7522;&#395; (cost)</span>
            <?= $renderMatriks($denganLabel($hasil['nilai']), $formatAsli) ?>
        </div>
    </details>

    <details class="calc-step glass">
        <summary>
            <span class="step-badge">2</span>
            <span class="summary-text">
                <h3>Matriks Ternormalisasi</h3>
                <p>Penyamaan skala nilai antar kriteria (r)</p>
            </span>
            <span class="chev"><?= icon('chevron-down', 18) ?></span>
        </summary>
        <div class="step-content">
            <span class="formula">benefit: r&#7522;&#395; = x&#7522;&#395; / &Sigma;&#7522; x&#7522;&#395; &nbsp;&middot;&nbsp; cost: r&#7522;&#395; = (1/x&#7522;&#395;) / &Sigma;&#7522; (1/x&#7522;&#395;)</span>
            <?= $renderMatriks($denganLabel($hasil['normalisasi']), $formatEmpat) ?>
        </div>
    </details>

    <details class="calc-step glass">
        <summary>
            <span class="step-badge">3</span>
            <span class="summary-text">
                <h3>Matriks Ternormalisasi Terbobot</h3>
                <p>Nilai normalisasi dikalikan bobot kriteria (v = w &times; r)</p>
            </span>
            <span class="chev"><?= icon('chevron-down', 18) ?></span>
        </summary>
        <div class="step-content">
            <span class="formula">v&#7522;&#395; = w&#395; &times; r&#7522;&#395;</span>
            <div class="legend">
                <?php foreach ($kriteria as $kri): ?>
                    <span><span class="kode-chip"><?= e($kri['kode']) ?></span> w = <?= format_desimal($hasil['bobot'][(int) $kri['id']]) ?></span>
                <?php endforeach; ?>
            </div>
            <?= $renderMatriks($denganLabel($hasil['terbobot']), $formatEmpat) ?>
        </div>
    </details>

    <details class="calc-step glass">
        <summary>
            <span class="step-badge">4</span>
            <span class="summary-text">
                <h3>Fungsi Optimalitas (S)</h3>
                <p>Penjumlahan nilai terbobot tiap alternatif</p>
            </span>
            <span class="chev"><?= icon('chevron-down', 18) ?></span>
        </summary>
        <div class="step-content">
            <span class="formula">S&#7522; = &Sigma;&#395; v&#7522;&#395;</span>
            <div class="table-wrap">
                <table style="min-width:340px">
                    <thead>
                        <tr><th>Baris</th><th class="t-right">S (fungsi optimalitas)</th></tr>
                    </thead>
                    <tbody>
                        <tr class="row-optimal">
                            <td><span class="kode-chip optimal">A0</span> &nbsp;Nilai Optimal</td>
                            <td class="td-num"><strong>S&#8320; = <?= format_desimal($hasil['s0']) ?></strong></td>
                        </tr>
                        <?php foreach ($alternatif as $alt): ?>
                            <tr>
                                <td><span class="kode-chip alt"><?= e($alt['kode']) ?></span> &nbsp;<?= e($alt['nama']) ?></td>
                                <td class="td-num">S<sub><?= e($alt['kode']) ?></sub> = <?= format_desimal($hasil['s'][(int) $alt['id']]) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </details>

    <details class="calc-step glass">
        <summary>
            <span class="step-badge">5</span>
            <span class="summary-text">
                <h3>Derajat Kegunaan (K) &amp; Peringkat</h3>
                <p>Perbandingan S tiap alternatif terhadap nilai optimal S&#8320;</p>
            </span>
            <span class="chev"><?= icon('chevron-down', 18) ?></span>
        </summary>
        <div class="step-content">
            <span class="formula">K&#7522; = S&#7522; / S&#8320;</span>
            <div class="table-wrap">
                <table style="min-width:460px">
                    <thead>
                        <tr>
                            <th>Alternatif</th>
                            <th class="t-right">S&#7522;</th>
                            <th class="t-right">K&#7522; = S&#7522; / <?= format_desimal($hasil['s0']) ?></th>
                            <th class="t-center">Peringkat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($peringkat as $item): ?>
                            <tr class="<?= $item['rank'] === 1 ? 'row-winner' : '' ?>">
                                <td><span class="kode-chip alt"><?= e($item['alt']['kode']) ?></span> &nbsp;<?= e($item['alt']['nama']) ?></td>
                                <td class="td-num"><?= format_desimal($item['s']) ?></td>
                                <td class="td-num"><strong><?= format_desimal($item['k']) ?></strong></td>
                                <td class="t-center"><?= $item['rank'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </details>

<?php endif; ?>

<?php require ROOT_PATH . '/views/footer.php'; ?>
