<?php

declare(strict_types=1);

require_once __DIR__ . '/config/app.php';

Auth::requireLogin();

$laporan = Laporan::data();

$pageTitle = 'Laporan';
$active = 'laporan';
require ROOT_PATH . '/views/header.php';
?>

<div class="page-head">
    <div>
        <h2>Laporan Hasil Perhitungan</h2>
        <p>
            Dokumen resmi hasil perhitungan ARAS: kriteria, matriks penilaian, peringkat,
            dan kesimpulan. Pratinjau di bawah sama dengan hasil cetak, PDF, maupun Excel.
        </p>
    </div>
</div>

<?php if (!$laporan['lengkap']): ?>
    <section class="card glass">
        <div class="empty-state">
            <span class="empty-icon"><?= icon('file-text', 26) ?></span>
            <h4>Laporan belum dapat dibuat</h4>
            <p>Lengkapi seluruh data kriteria, alternatif, dan penilaian terlebih dahulu agar laporan dapat disusun.</p>
            <div class="hero-actions" style="justify-content:center">
                <a class="btn btn-primary btn-sm" href="<?= BASE_URL ?>/penilaian.php"><?= icon('clipboard-list', 15) ?> Isi Penilaian</a>
            </div>
        </div>
    </section>
<?php else: ?>
    <section class="glass report-actions">
        <div class="report-buttons">
            <a class="btn btn-primary" href="<?= BASE_URL ?>/cetak.php" target="_blank" rel="noopener">
                <?= icon('printer', 17) ?> Cetak
            </a>
            <a class="btn btn-gold" href="<?= BASE_URL ?>/actions/laporan_pdf.php">
                <?= icon('file-down', 17) ?> Simpan PDF
            </a>
            <a class="btn btn-ghost" href="<?= BASE_URL ?>/actions/laporan_excel.php">
                <?= icon('file-spreadsheet', 17) ?> Simpan Excel
            </a>
        </div>
        <span class="card-note">
            <?= icon('info', 13) ?> Tombol Cetak membuka dialog printer browser; tombol Simpan mengunduh berkas ke perangkat.
        </span>
    </section>

    <div class="paper-frame">
        <?php require ROOT_PATH . '/views/laporan_dokumen.php'; ?>
    </div>
<?php endif; ?>

<?php require ROOT_PATH . '/views/footer.php'; ?>
