# SPK Pemilihan Relawan Inti — Program Tanggap Bencana

Sistem pendukung keputusan untuk memilih relawan inti organisasi sosial menggunakan metode **MABAC** (Multi-Attributive Borderline Area Comparison). Dibangun dengan PHP native, MySQL, SweetAlert2, php-lucide, dan CSS native bergaya glassmorphism (soft teal + soft coral).

## Kriteria

| Kode | Kriteria | Tipe | Bobot |
| --- | --- | --- | --- |
| C1 | Pengalaman Lapangan | benefit | 30% |
| C2 | Pelatihan Dasar | benefit | 25% |
| C3 | Kesiapan Waktu | benefit | 20% |
| C4 | Kemampuan Komunikasi | benefit | 15% |
| C5 | Risiko Kesehatan | cost | 10% |

## Instalasi

1. Tempatkan proyek di `htdocs` (XAMPP), misalnya `htdocs/spk-mabac`.
2. Impor basis data: `mysql -u root < database/spk_mabac.sql` (atau lewat phpMyAdmin). Berkas ini membuat database `spk_mabac` beserta data contoh 8 relawan.
3. Sesuaikan kredensial pada `config/database.php` bila MySQL Anda memakai kata sandi.
4. Buka `http://localhost/spk-mabac/` di peramban.

## Alur Penggunaan

1. **Kriteria** — atur kode, nama, tipe (benefit/cost), dan bobot tiap kriteria.
2. **Relawan & Penilaian** — daftarkan relawan dan isi nilai 1–5 untuk setiap kriteria.
3. **Perhitungan MABAC** — lihat enam langkah metode: matriks keputusan, normalisasi, matriks terbobot, area batas, jarak dari area batas, dan skor akhir.
4. **Hasil & Ranking** — peringkat relawan beserta rekomendasi relawan inti.
5. **Laporan** — lembar laporan resmi (kriteria, matriks penilaian, peringkat, blok tanda tangan) dengan tiga tombol terpisah: **Cetak** (dialog printer), **Simpan PDF** (unduh langsung), dan **Simpan Excel** (unduh `.xls` lewat `export_excel.php`).

## Struktur

```
config/database.php   koneksi PDO
src/Mabac.php         mesin perhitungan MABAC
includes/             helper, header, footer
database/             skema + data contoh
assets/               CSS dan JS
laporan.php           lembar laporan + tombol cetak/PDF
export_excel.php      unduhan laporan format Excel
```
