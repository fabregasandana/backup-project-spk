<?php
require __DIR__ . '/includes/helpers.php';

$data = dataset();

if (!$data) {
    flash('error', 'Laporan belum dapat diekspor karena data belum lengkap.');
    header('Location: laporan.php');
    exit;
}

$peringkat = $data['mabac']->peringkat();

$namaBulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
$tanggal = date('j') . ' ' . $namaBulan[(int) date('n') - 1] . ' ' . date('Y');

header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename="laporan-pemilihan-relawan-inti.xls"');
header('Cache-Control: max-age=0');
?>
<html>

<head>
    <meta charset="utf-8">
</head>

<body>
    <table>
        <tr>
            <td colspan="6"><strong>Laporan Hasil Pemilihan Relawan Inti</strong></td>
        </tr>
        <tr>
            <td colspan="6">Program Tanggap Bencana Organisasi Sosial — Metode MABAC</td>
        </tr>
        <tr>
            <td colspan="6">Disusun pada <?= $tanggal ?></td>
        </tr>
        <tr></tr>
        <tr>
            <td colspan="6"><strong>A. Kriteria dan Bobot</strong></td>
        </tr>
        <tr>
            <th>Kode</th>
            <th>Kriteria</th>
            <th>Tipe</th>
            <th>Bobot (%)</th>
        </tr>
        <?php foreach ($data['kriteria'] as $k): ?>
            <tr>
                <td><?= e($k['kode']) ?></td>
                <td><?= e($k['nama']) ?></td>
                <td><?= ucfirst($k['tipe']) ?></td>
                <td><?= fmt((float) $k['bobot']) ?></td>
            </tr>
        <?php endforeach; ?>
        <tr></tr>
        <tr>
            <td colspan="6"><strong>B. Matriks Penilaian Relawan</strong></td>
        </tr>
        <tr>
            <th>Kode</th>
            <th>Nama Relawan</th>
            <?php foreach ($data['kriteria'] as $k): ?>
                <th><?= e($k['kode']) ?></th>
            <?php endforeach; ?>
        </tr>
        <?php foreach ($data['matrix'] as $i => $baris): ?>
            <tr>
                <td><?= e($data['alternatif'][$i]['kode']) ?></td>
                <td><?= e($data['alternatif'][$i]['nama']) ?></td>
                <?php foreach ($baris as $nilai): ?>
                    <td><?= fmt($nilai) ?></td>
                <?php endforeach; ?>
            </tr>
        <?php endforeach; ?>
        <tr></tr>
        <tr>
            <td colspan="6"><strong>C. Peringkat Akhir</strong></td>
        </tr>
        <tr>
            <th>Peringkat</th>
            <th>Kode</th>
            <th>Nama Relawan</th>
            <th>Skor MABAC</th>
            <th>Rekomendasi</th>
        </tr>
        <?php foreach ($peringkat as $item): ?>
            <tr>
                <td><?= $item['rank'] ?></td>
                <td><?= e($item['alternatif']['kode']) ?></td>
                <td><?= e($item['alternatif']['nama']) ?></td>
                <td><?= fmt($item['skor']) ?></td>
                <td><?= $item['rank'] <= 3 ? 'Relawan Inti' : 'Kandidat Pendukung' ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>

</html>
