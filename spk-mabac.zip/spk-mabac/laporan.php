<?php
require __DIR__ . '/includes/helpers.php';

$page = 'laporan';
$judul = 'Laporan';

$data = dataset();
$peringkat = $data ? $data['mabac']->peringkat() : [];

$namaBulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
$tanggal = date('j') . ' ' . $namaBulan[(int) date('n') - 1] . ' ' . date('Y');

$skripHalaman = <<<'JS'
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
    document.getElementById('tombol-cetak').addEventListener('click', () => window.print());

    document.getElementById('tombol-pdf').addEventListener('click', () => {
        Swal.fire({
            title: 'Menyiapkan PDF...',
            allowOutsideClick: false,
            allowEscapeKey: false,
            didOpen: () => Swal.showLoading(),
        });

        html2pdf().set({
            margin: 10,
            filename: 'laporan-pemilihan-relawan-inti.pdf',
            html2canvas: { scale: 2, useCORS: true },
            jsPDF: { unit: 'mm', format: 'a4' },
            pagebreak: { mode: ['css', 'legacy'] },
        }).from(document.getElementById('area-laporan')).save()
            .then(() => Swal.close())
            .catch(() => {
                Swal.close();
                Swal.fire({ icon: 'error', title: 'Gagal membuat PDF', text: 'Coba ulangi beberapa saat lagi.' });
            });
    });
</script>
JS;

require __DIR__ . '/includes/header.php';
?>

<?php if (!$data): ?>
    <div class="kartu">
        <div class="kosong">
            <?= icon('alert-triangle', '', 44) ?>
            <p>Laporan tersedia setelah data kriteria dan penilaian seluruh relawan lengkap.</p>
            <br>
            <a class="tombol tombol-utama" href="<?= BASE_URL ?>/alternatif.php"><?= icon('users', '', 16) ?> Lengkapi Data</a>
        </div>
    </div>
<?php else: ?>
    <div class="kartu toolbar-aksi">
        <div>
            <h2><span class="ikon-bulat"><?= icon('printer', '', 18) ?></span> Ekspor Laporan</h2>
            <p>Cetak lembar laporan ke printer, atau simpan sebagai berkas PDF dan Excel.</p>
        </div>
        <div class="toolbar-tombol">
            <button type="button" class="tombol tombol-utama" id="tombol-cetak">
                <?= icon('printer', '', 16) ?> Cetak
            </button>
            <button type="button" class="tombol tombol-koral" id="tombol-pdf">
                <?= icon('file-down', '', 16) ?> Simpan PDF
            </button>
            <a class="tombol tombol-netral" href="<?= BASE_URL ?>/export_excel.php">
                <?= icon('file-spreadsheet', '', 16) ?> Simpan Excel
            </a>
        </div>
    </div>

    <div class="lembar" id="area-laporan">
        <div class="lembar-kop">
            <h2>Laporan Hasil Pemilihan Relawan Inti</h2>
            <p>Program Tanggap Bencana Organisasi Sosial — Metode MABAC</p>
            <p class="lembar-tanggal">Disusun pada <?= $tanggal ?></p>
        </div>

        <h3>A. Kriteria dan Bobot</h3>
        <table class="tabel-laporan">
            <thead>
                <tr>
                    <th>Kode</th>
                    <th>Kriteria</th>
                    <th>Tipe</th>
                    <th class="num">Bobot</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data['kriteria'] as $k): ?>
                    <tr>
                        <td><?= e($k['kode']) ?></td>
                        <td><?= e($k['nama']) ?></td>
                        <td><?= ucfirst($k['tipe']) ?></td>
                        <td class="num"><?= fmt((float) $k['bobot']) ?>%</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h3>B. Matriks Penilaian Relawan</h3>
        <table class="tabel-laporan">
            <thead>
                <tr>
                    <th>Kode</th>
                    <th>Nama Relawan</th>
                    <?php foreach ($data['kriteria'] as $k): ?>
                        <th class="num"><?= e($k['kode']) ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data['matrix'] as $i => $baris): ?>
                    <tr>
                        <td><?= e($data['alternatif'][$i]['kode']) ?></td>
                        <td><?= e($data['alternatif'][$i]['nama']) ?></td>
                        <?php foreach ($baris as $nilai): ?>
                            <td class="num"><?= fmt($nilai) ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h3>C. Peringkat Akhir</h3>
        <table class="tabel-laporan">
            <thead>
                <tr>
                    <th class="num">Peringkat</th>
                    <th>Kode</th>
                    <th>Nama Relawan</th>
                    <th class="num">Skor MABAC</th>
                    <th>Rekomendasi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($peringkat as $item): ?>
                    <tr>
                        <td class="num"><?= $item['rank'] ?></td>
                        <td><?= e($item['alternatif']['kode']) ?></td>
                        <td><?= e($item['alternatif']['nama']) ?></td>
                        <td class="num"><?= fmt($item['skor']) ?></td>
                        <td><?= $item['rank'] <= 3 ? 'Relawan Inti' : 'Kandidat Pendukung' ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <p class="lembar-catatan">
            Relawan peringkat 1–<?= min(3, count($peringkat)) ?> direkomendasikan sebagai relawan inti program tanggap bencana.
            Peringkat selanjutnya dapat dilibatkan sebagai kandidat pendukung sesuai kebutuhan lapangan.
        </p>

        <div class="lembar-ttd">
            <div class="ttd">
                <p><?= $tanggal ?></p>
                <p>Ketua Organisasi,</p>
                <div class="ttd-ruang"></div>
                <p>(________________________)</p>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
