<?php

final class Mabac
{
    private array $bobot;
    private int $jumlahAlternatif;
    private int $jumlahKriteria;

    public function __construct(
        private array $kriteria,
        private array $alternatif,
        private array $matrix
    ) {
        $total = array_sum(array_column($kriteria, 'bobot'));
        $this->bobot = array_map(
            fn($k) => $total > 0 ? $k['bobot'] / $total : 0,
            $kriteria
        );
        $this->jumlahAlternatif = count($alternatif);
        $this->jumlahKriteria = count($kriteria);
    }

    public function normalisasi(): array
    {
        $hasil = array_fill(0, $this->jumlahAlternatif, array_fill(0, $this->jumlahKriteria, 0.0));

        foreach ($this->kriteria as $j => $kriteria) {
            $kolom = array_column($this->matrix, $j);
            $max = max($kolom);
            $min = min($kolom);

            foreach ($kolom as $i => $nilai) {
                if ($max == $min) {
                    $hasil[$i][$j] = 0.0;
                    continue;
                }
                $hasil[$i][$j] = $kriteria['tipe'] === 'benefit'
                    ? ($nilai - $min) / ($max - $min)
                    : ($nilai - $max) / ($min - $max);
            }
        }

        return $hasil;
    }

    public function terbobot(array $normalisasi): array
    {
        $hasil = [];

        foreach ($normalisasi as $i => $baris) {
            foreach ($baris as $j => $nilai) {
                $hasil[$i][$j] = $this->bobot[$j] * ($nilai + 1);
            }
        }

        return $hasil;
    }

    public function batas(array $terbobot): array
    {
        $hasil = [];

        for ($j = 0; $j < $this->jumlahKriteria; $j++) {
            $produk = 1.0;
            for ($i = 0; $i < $this->jumlahAlternatif; $i++) {
                $produk *= $terbobot[$i][$j];
            }
            $hasil[$j] = $produk ** (1 / $this->jumlahAlternatif);
        }

        return $hasil;
    }

    public function jarak(array $terbobot, array $batas): array
    {
        $hasil = [];

        foreach ($terbobot as $i => $baris) {
            foreach ($baris as $j => $nilai) {
                $hasil[$i][$j] = $nilai - $batas[$j];
            }
        }

        return $hasil;
    }

    public function peringkat(): array
    {
        $normalisasi = $this->normalisasi();
        $terbobot = $this->terbobot($normalisasi);
        $batas = $this->batas($terbobot);
        $jarak = $this->jarak($terbobot, $batas);

        $peringkat = [];
        foreach ($jarak as $i => $baris) {
            $peringkat[] = [
                'alternatif' => $this->alternatif[$i],
                'skor' => array_sum($baris),
            ];
        }

        usort($peringkat, fn($a, $b) => $b['skor'] <=> $a['skor']);

        foreach ($peringkat as $urutan => &$item) {
            $item['rank'] = $urutan + 1;
        }

        return $peringkat;
    }

    public function langkah(): array
    {
        $normalisasi = $this->normalisasi();
        $terbobot = $this->terbobot($normalisasi);
        $batas = $this->batas($terbobot);
        $jarak = $this->jarak($terbobot, $batas);

        $skor = array_map(fn($baris) => array_sum($baris), $jarak);

        return compact('normalisasi', 'terbobot', 'batas', 'jarak', 'skor');
    }

    public function bobot(): array
    {
        return $this->bobot;
    }
}
