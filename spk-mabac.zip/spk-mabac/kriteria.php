<?php
require __DIR__ . '/includes/helpers.php';

$page = 'kriteria';
$judul = 'Kriteria Penilaian';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';
    $kode = trim($_POST['kode'] ?? '');
    $nama = trim($_POST['nama'] ?? '');
    $tipe = $_POST['tipe'] ?? 'benefit';
    $bobot = (float) ($_POST['bobot'] ?? 0);
    $keterangan = trim($_POST['keterangan'] ?? '');

    if ($aksi === 'hapus' && isset($_POST['id'])) {
        db()->prepare('DELETE FROM kriteria WHERE id = ?')->execute([(int) $_POST['id']]);
        flash('success', 'Kriteria berhasil dihapus.');
        header('Location: kriteria.php');
        exit;
    }

    if ($aksi === 'simpan' && $kode !== '' && $nama !== '' && in_array($tipe, ['benefit', 'cost'], true)) {
        $cek = db()->prepare('SELECT id FROM kriteria WHERE kode = ? AND id != ?');
        $cek->execute([$kode, (int) ($_POST['id'] ?? 0)]);

        if ($cek->fetch()) {
            flash('error', "Kode $kode sudah dipakai kriteria lain.");
        } else {
            if (!empty($_POST['id'])) {
                $sql = 'UPDATE kriteria SET kode = ?, nama = ?, tipe = ?, bobot = ?, keterangan = ? WHERE id = ?';
                db()->prepare($sql)->execute([$kode, $nama, $tipe, $bobot, $keterangan, (int) $_POST['id']]);
                flash('success', 'Kriteria berhasil diperbarui.');
            } else {
                $sql = 'INSERT INTO kriteria (kode, nama, tipe, bobot, keterangan) VALUES (?, ?, ?, ?, ?)';
                db()->prepare($sql)->execute([$kode, $nama, $tipe, $bobot, $keterangan]);
                flash('success', 'Kriteria berhasil ditambahkan.');
            }
            header('Location: kriteria.php');
            exit;
        }
    } elseif ($aksi === 'simpan') {
        flash('error', 'Kode, nama, dan tipe kriteria wajib diisi.');
    }
}

$kriteria = semua_kriteria();
$edit = null;
if (isset($_GET['edit'])) {
    $stmt = db()->prepare('SELECT * FROM kriteria WHERE id = ?');
    $stmt->execute([(int) $_GET['edit']]);
    $edit = $stmt->fetch() ?: null;
}
$totalBobot = array_sum(array_column($kriteria, 'bobot'));

require __DIR__ . '/includes/header.php';
?>

<?php if ($totalBobot > 0 && abs($totalBobot - 100) > 0.01): ?>
    <div class="pesan pesan-info">
        <?= icon('info', '', 18) ?>
        Total bobot saat ini <?= fmt($totalBobot) ?>%. Sistem tetap menghitung normal berdasarkan proporsi bobot yang ada.
    </div>
<?php endif; ?>

<div class="grid grid-2">
    <div class="kartu">
        <div class="kartu-judul">
            <div>
                <h2><span class="ikon-bulat"><?= icon('list-checks', '', 18) ?></span> Daftar Kriteria</h2>
                <p>Kriteria benefit bernilai makin baik jika makin tinggi, kriteria cost sebaliknya.</p>
            </div>
        </div>
        <div class="tabel-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Kriteria</th>
                        <th>Tipe</th>
                        <th class="num">Bobot</th>
                        <th class="num">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($kriteria as $k): ?>
                        <tr>
                            <td><strong><?= e($k['kode']) ?></strong></td>
                            <td>
                                <?= e($k['nama']) ?>
                                <?php if ($k['keterangan']): ?>
                                    <br><small style="color:var(--teks-tipis)"><?= e($k['keterangan']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge badge-<?= $k['tipe'] ?>">
                                    <?= icon($k['tipe'] === 'benefit' ? 'trending-up' : 'shield-alert', '', 13) ?>
                                    <?= ucfirst($k['tipe']) ?>
                                </span>
                            </td>
                            <td class="num"><?= fmt((float) $k['bobot']) ?>%</td>
                            <td class="num" style="white-space:nowrap">
                                <a class="tombol-kecil tombol-ubah" href="kriteria.php?edit=<?= $k['id'] ?>" title="Ubah">
                                    <?= icon('pencil', '', 15) ?>
                                </a>
                                <form method="post" style="display:inline" data-hapus="Kriteria <?= e($k['nama']) ?> dan seluruh penilaian terkait akan dihapus.">
                                    <input type="hidden" name="aksi" value="hapus">
                                    <input type="hidden" name="id" value="<?= $k['id'] ?>">
                                    <button type="submit" class="tombol-kecil tombol-hapus" title="Hapus"><?= icon('trash-2', '', 15) ?></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$kriteria): ?>
                        <tr>
                            <td colspan="5" class="kosong">
                                <?= icon('inbox', '', 40) ?>
                                <p>Belum ada kriteria.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="kartu">
        <div class="kartu-judul">
            <div>
                <h2>
                    <span class="ikon-bulat"><?= icon($edit ? 'pencil-line' : 'plus-circle', '', 18) ?></span>
                    <?= $edit ? 'Ubah Kriteria' : 'Tambah Kriteria' ?>
                </h2>
                <p><?= $edit ? "Sedang mengubah kriteria {$edit['kode']}." : 'Lengkapi formulir untuk menambah kriteria baru.' ?></p>
            </div>
        </div>
        <form method="post" class="form-grid">
            <input type="hidden" name="aksi" value="simpan">
            <?php if ($edit): ?>
                <input type="hidden" name="id" value="<?= $edit['id'] ?>">
            <?php endif; ?>
            <div class="form-grup">
                <label for="kode">Kode</label>
                <input type="text" id="kode" name="kode" maxlength="10" placeholder="C6" required value="<?= e($edit['kode'] ?? '') ?>">
            </div>
            <div class="form-grup">
                <label for="bobot">Bobot (%)</label>
                <input type="number" id="bobot" name="bobot" step="0.01" min="0" max="100" placeholder="20" required value="<?= e($edit['bobot'] ?? '') ?>">
            </div>
            <div class="form-grup lebar">
                <label for="nama">Nama Kriteria</label>
                <input type="text" id="nama" name="nama" maxlength="100" placeholder="Contoh: Kesiapan Fisik" required value="<?= e($edit['nama'] ?? '') ?>">
            </div>
            <div class="form-grup lebar">
                <label for="tipe">Tipe Kriteria</label>
                <select id="tipe" name="tipe">
                    <option value="benefit" <?= ($edit['tipe'] ?? 'benefit') === 'benefit' ? 'selected' : '' ?>>Benefit — makin tinggi makin baik</option>
                    <option value="cost" <?= ($edit['tipe'] ?? '') === 'cost' ? 'selected' : '' ?>>Cost — makin rendah makin baik</option>
                </select>
            </div>
            <div class="form-grup lebar">
                <label for="keterangan">Keterangan</label>
                <textarea id="keterangan" name="keterangan" rows="3" placeholder="Penjelasan singkat kriteria"><?= e($edit['keterangan'] ?? '') ?></textarea>
            </div>
            <div class="form-aksi">
                <button type="submit" class="tombol tombol-utama">
                    <?= icon($edit ? 'check' : 'plus', '', 16) ?>
                    <?= $edit ? 'Simpan Perubahan' : 'Tambah Kriteria' ?>
                </button>
                <?php if ($edit): ?>
                    <a class="tombol" href="kriteria.php" style="background:rgba(63,167,150,.12);color:var(--teal-tua)">Batal</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
