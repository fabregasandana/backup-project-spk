CREATE DATABASE IF NOT EXISTS spk_mabac CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE spk_mabac;

DROP TABLE IF EXISTS pengguna;
DROP TABLE IF EXISTS penilaian;
DROP TABLE IF EXISTS alternatif;
DROP TABLE IF EXISTS kriteria;

CREATE TABLE pengguna (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    dibuat_pada TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE = InnoDB;

INSERT INTO pengguna (username, nama, password) VALUES
('admin', 'Administrator', '$2y$10$3UDQEy2tM8Rcje2Y59DwpOD3EU2Gd.LbVXMJ7zwyq3J1AdM4H.QDi');

CREATE TABLE kriteria (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(10) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    tipe ENUM('benefit', 'cost') NOT NULL DEFAULT 'benefit',
    bobot DECIMAL(5,2) NOT NULL,
    keterangan VARCHAR(255) DEFAULT NULL
) ENGINE = InnoDB;

CREATE TABLE alternatif (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(10) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    kontak VARCHAR(50) DEFAULT NULL,
    alamat VARCHAR(255) DEFAULT NULL
) ENGINE = InnoDB;

CREATE TABLE penilaian (
    id INT AUTO_INCREMENT PRIMARY KEY,
    alternatif_id INT NOT NULL,
    kriteria_id INT NOT NULL,
    nilai DECIMAL(6,2) NOT NULL,
    UNIQUE KEY uniq_penilaian (alternatif_id, kriteria_id),
    FOREIGN KEY (alternatif_id) REFERENCES alternatif (id) ON DELETE CASCADE,
    FOREIGN KEY (kriteria_id) REFERENCES kriteria (id) ON DELETE CASCADE
) ENGINE = InnoDB;

INSERT INTO kriteria (kode, nama, tipe, bobot, keterangan) VALUES
('C1', 'Pengalaman Lapangan', 'benefit', 30, 'Jumlah misi tanggap bencana yang pernah diikuti'),
('C2', 'Pelatihan Dasar', 'benefit', 25, 'Sertifikasi pelatihan kebencanaan dan P3K yang dimiliki'),
('C3', 'Kesiapan Waktu', 'benefit', 20, 'Ketersediaan waktu selama masa program berlangsung'),
('C4', 'Kemampuan Komunikasi', 'benefit', 15, 'Koordinasi tim dan komunikasi dengan penyintas'),
('C5', 'Risiko Kesehatan', 'cost', 10, 'Riwayat kondisi kesehatan di lingkungan kerja berat');

INSERT INTO alternatif (kode, nama, kontak, alamat) VALUES
('A1', 'Bagas Prasetyo', '0812-3456-7801', 'Kel. Sukamaju, Bandung'),
('A2', 'Siti Nurhaliza', '0812-3456-7802', 'Kel. Cipadung, Bandung'),
('A3', 'Rizky Ramadhan', '0812-3456-7803', 'Kel. Arcamanik, Bandung'),
('A4', 'Dewi Anggraini', '0812-3456-7804', 'Kel. Antapani, Bandung'),
('A5', 'Fajar Nugroho', '0812-3456-7805', 'Kel. Ujungberung, Bandung'),
('A6', 'Rani Puspita', '0812-3456-7806', 'Kel. Cicadas, Bandung'),
('A7', 'Dimas Saputra', '0812-3456-7807', 'Kel. Cicaheum, Bandung'),
('A8', 'Ayu Lestari', '0812-3456-7808', 'Kel. Kiaracondong, Bandung');

INSERT INTO penilaian (alternatif_id, kriteria_id, nilai) VALUES
(1, 1, 4), (1, 2, 5), (1, 3, 3), (1, 4, 4), (1, 5, 2),
(2, 1, 3), (2, 2, 4), (2, 3, 5), (2, 4, 5), (2, 5, 1),
(3, 1, 5), (3, 2, 3), (3, 3, 4), (3, 4, 3), (3, 5, 3),
(4, 1, 2), (4, 2, 4), (4, 3, 4), (4, 4, 5), (4, 5, 2),
(5, 1, 4), (5, 2, 4), (5, 3, 2), (5, 4, 3), (5, 5, 4),
(6, 1, 3), (6, 2, 5), (6, 3, 4), (6, 4, 4), (6, 5, 1),
(7, 1, 5), (7, 2, 2), (7, 3, 3), (7, 4, 2), (7, 5, 3),
(8, 1, 2), (8, 2, 3), (8, 3, 5), (8, 4, 4), (8, 5, 1);
