import json
import copy

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_SECTION_START
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

DATA = json.load(open('.laporan/data.json', encoding='utf-8'))
VALIDASI = json.load(open('.laporan/validasi.json', encoding='utf-8'))
IMG = '.laporan/img/'

doc = Document()

# ---------- halaman & gaya dasar ----------
sec = doc.sections[0]
sec.page_width, sec.page_height = Cm(21), Cm(29.7)
sec.top_margin, sec.left_margin = Cm(4), Cm(4)
sec.bottom_margin, sec.right_margin = Cm(3), Cm(3)

normal = doc.styles['Normal']
normal.font.name = 'Times New Roman'
normal.font.size = Pt(12)
normal.font.color.rgb = RGBColor(0, 0, 0)
normal.element.rPr.rFonts.set(qn('w:eastAsia'), 'Times New Roman')
pf = normal.paragraph_format
pf.line_spacing = 2.0
pf.space_before = Pt(0)
pf.space_after = Pt(0)
pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

for nama, size in [('Heading 1', 12), ('Heading 2', 12)]:
    st = doc.styles[nama]
    st.font.name = 'Times New Roman'
    st.font.size = Pt(size)
    st.font.bold = True
    st.font.color.rgb = RGBColor(0, 0, 0)
    st.element.rPr.rFonts.set(qn('w:eastAsia'), 'Times New Roman')
    st.paragraph_format.line_spacing = 1.0
    st.paragraph_format.space_before = Pt(12)
    st.paragraph_format.space_after = Pt(6)

gaya_kode = doc.styles.add_style('KodeProgram', 1)
gaya_kode.base_style = doc.styles['Normal']
gaya_kode.font.name = 'Courier New'
gaya_kode.font.size = Pt(10)
gaya_kode.paragraph_format.line_spacing = 1.0
gaya_kode.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT

gaya_caption = doc.styles.add_style('CaptionGambar', 1)
gaya_caption.base_style = doc.styles['Normal']
gaya_caption.font.name = 'Times New Roman'
gaya_caption.font.size = Pt(11)
gaya_caption.paragraph_format.line_spacing = 1.0
gaya_caption.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
gaya_caption.paragraph_format.space_before = Pt(6)
gaya_caption.paragraph_format.space_after = Pt(12)

for nama_toc in ('TOC 1', 'TOC 2'):
    try:
        st_toc = doc.styles[nama_toc]
    except KeyError:
        st_toc = doc.styles.add_style(nama_toc, 1)
        st_toc.base_style = doc.styles['Normal']
    st_toc.font.name = 'Times New Roman'
    st_toc.font.size = Pt(12)
    st_toc.element.rPr.rFonts.set(qn('w:eastAsia'), 'Times New Roman')
    st_toc.paragraph_format.line_spacing = 1.15
    st_toc.paragraph_format.space_before = Pt(0)
    st_toc.paragraph_format.space_after = Pt(2)


def cover(p, teks='', bold=False, size=12, before=0, after=0):
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.space_after = Pt(after)
    if teks:
        r = p.add_run(teks)
        r.bold = bold
        r.font.size = Pt(size)
    return p


def par(teks='', style=None, align=None, spacing=None):
    p = doc.add_paragraph(style=style)
    if align is not None:
        p.paragraph_format.alignment = align
    if spacing is not None:
        p.paragraph_format.line_spacing = spacing
    if teks:
        p.add_run(teks)
    return p


def rumus(teks, nomor):
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.tab_stops.add_tab_stop(Cm(7.5), WD_ALIGN_PARAGRAPH.CENTER)
    p.paragraph_format.tab_stops.add_tab_stop(Cm(15.0), WD_ALIGN_PARAGRAPH.RIGHT)
    p.add_run('\t' + teks + '\t(' + nomor + ')')
    return p


def gambar(nama_file, lebar_cm, caption):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.space_before = Pt(6)
    p.add_run().add_picture(IMG + nama_file, width=Cm(lebar_cm))
    par(caption, style='CaptionGambar')


def isi_sel(sel, teks, bold=False, size=11):
    sel.paragraphs[0].text = ''
    p = sel.paragraphs[0]
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(str(teks))
    r.bold = bold
    r.font.name = 'Times New Roman'
    r.font.size = Pt(size)


def tabel(headers, rows, header_bold=True):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = 'Table Grid'
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        isi_sel(t.rows[0].cells[i], h, bold=header_bold)
    for row in rows:
        cells = t.add_row().cells
        for i, val in enumerate(row):
            isi_sel(cells[i], val)
    par('', spacing=1.0)
    return t


def field(paragraf, instruksi, placeholder=''):
    r1 = paragraf.add_run()
    fld = OxmlElement('w:fldChar'); fld.set(qn('w:fldCharType'), 'begin'); r1._r.append(fld)
    r2 = paragraf.add_run()
    instr = OxmlElement('w:instrText'); instr.set(qn('xml:space'), 'preserve'); instr.text = instruksi
    r2._r.append(instr)
    r3 = paragraf.add_run()
    fld2 = OxmlElement('w:fldChar'); fld2.set(qn('w:fldCharType'), 'separate'); r3._r.append(fld2)
    r4 = paragraf.add_run(placeholder)
    r5 = paragraf.add_run()
    fld3 = OxmlElement('w:fldChar'); fld3.set(qn('w:fldCharType'), 'end'); r5._r.append(fld3)


def nomor_halaman(section, fmt, mulai=None, taut=False):
    section.footer.is_linked_to_previous = taut
    p = section.footer.paragraphs[0]
    p.text = ''
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    field(p, ' PAGE ')
    for r in p.runs:
        r.font.name = 'Times New Roman'
        r.font.size = Pt(11)
    sectPr = section._sectPr
    el = sectPr.find(qn('w:pgNumType'))
    if el is None:
        el = OxmlElement('w:pgNumType'); sectPr.append(el)
    el.set(qn('w:fmt'), fmt)
    if mulai:
        el.set(qn('w:start'), str(mulai))


# ---------- COVER ----------
for judul in [
    'LAPORAN PROJECT SISTEM PENDUKUNG KEPUTUSAN',
    'SPK PEMILIHAN RELAWAN INTI PROGRAM TANGGAP BENCANA',
    'PADA TAGANA KOTA BANDUNG',
    'MENGGUNAKAN METODE MABAC',
]:
    cover(doc.add_paragraph(), judul, bold=True, size=14, after=6)

cover(doc.add_paragraph())
cover(doc.add_paragraph())
p_logo = cover(doc.add_paragraph())
p_logo.add_run().add_picture(IMG + 'logo.png', height=Cm(4.5))
cover(doc.add_paragraph())
cover(doc.add_paragraph())
cover(doc.add_paragraph(), 'Disusun Oleh :', size=12)
cover(doc.add_paragraph())
cover(doc.add_paragraph(), 'Fabregas Andana', bold=True, size=12)
cover(doc.add_paragraph(), 'NIM 2024020163', bold=True, size=12)
cover(doc.add_paragraph())
cover(doc.add_paragraph())
cover(doc.add_paragraph(), 'SISTEM INFORMASI', bold=True, size=13)
cover(doc.add_paragraph(), 'SEKOLAH TINGGI MANAJEMEN INFORMATIKA', bold=True, size=13)
cover(doc.add_paragraph(), 'TRIGUNA DHARMA', bold=True, size=13)
cover(doc.add_paragraph(), '2026', bold=True, size=13)

# footer section 1: romawi, cover tanpa nomor
sec.different_first_page_header_footer = True
nomor_halaman(sec, 'lowerRoman', mulai=1)

# ---------- DAFTAR ISI ----------
doc.add_page_break()
cover(doc.add_paragraph(), 'DAFTAR ISI', bold=True, size=14, after=6)
p_toc = doc.add_paragraph()
field(p_toc, ' TOC \\o "1-2" \\h \\z \\u ', 'Daftar isi akan diperbarui otomatis oleh Word.')

# ---------- ISI (section 2, angka arab mulai 1) ----------
sec2 = doc.add_section(WD_SECTION_START.NEW_PAGE)
sec2.page_width, sec2.page_height = Cm(21), Cm(29.7)
sec2.top_margin, sec2.left_margin = Cm(4), Cm(4)
sec2.bottom_margin, sec2.right_margin = Cm(3), Cm(3)
nomor_halaman(sec2, 'decimal', mulai=1)

# ===== 1. IDENTITAS =====
doc.add_heading('1. IDENTITAS PROJECT', level=1)
tabel(['Komponen', 'Isi'], [
    ['Nama Mahasiswa', 'Fabregas Andana'],
    ['NIM', '2024020163'],
    ['Program Studi', 'Sistem Informasi — STMIK Triguna Dharma'],
    ['Judul Project', 'SPK Pemilihan Relawan Inti untuk Program Tanggap Bencana pada TAGANA Kota Bandung Menggunakan Metode MABAC'],
    ['Objek/Kasus', 'TAGANA (Taruna Siaga Bencana) Kota Bandung — organisasi relawan kebencanaan binaan Kementerian Sosial RI — yang membutuhkan mekanisme objektif untuk memilih relawan inti program tanggap bencana dari 8 kandidat relawan aktif'],
    ['Metode SPK', 'Multi-Attributive Borderline Area Comparison (MABAC)'],
    ['Bahasa Pemrograman/Framework', 'PHP 8 (native, tanpa framework), HTML, CSS, JavaScript'],
    ['Database', 'MySQL/MariaDB (paket XAMPP), basis data: spk_mabac'],
    ['Jumlah Alternatif', '8 alternatif relawan'],
    ['Jumlah Kriteria', '5 kriteria (4 benefit, 1 cost), total bobot 100%'],
    ['Output Utama Program', 'Perangkingan alternatif berdasarkan skor MABAC (S) beserta rekomendasi 3 besar relawan inti'],
])

# ===== 2. RINGKASAN =====
doc.add_heading('2. RINGKASAN PROGRAM', level=1)
doc.add_heading('2.1 Tujuan Program', level=2)
par('Program ini bertujuan membantu pengurus TAGANA Kota Bandung memilih relawan inti untuk program tanggap bencana secara objektif dan terukur menggunakan metode MABAC terhadap delapan kandidat relawan aktif. Selama ini penentuan relawan inti lebih banyak mengandalkan senioritas dan penilaian subjektif koordinator, sehingga program hadir agar keputusan mempertimbangkan pengalaman lapangan, pelatihan dasar, kesiapan waktu, kemampuan komunikasi, dan risiko kesehatan secara bersamaan.')
doc.add_heading('2.2 Permasalahan yang Diselesaikan', level=2)
par('TAGANA Kota Bandung menghadapi permasalahan pemilihan relawan inti yang tidak sederhana: setiap kandidat unggul di aspek berbeda, dan lima aspek penilaiannya memiliki arah preferensi yang tidak seragam — empat kriteria bersifat benefit (makin tinggi makin baik) sedangkan risiko kesehatan bersifat cost (makin rendah makin baik). Kondisi kesehatan relawan yang berisiko tinggi justru menjadi pengurang kelayakan, sehingga tidak dapat diperlakukan sama dengan kriteria keuntungan. Tanpa alat bantu keputusan, kriteria cost semacam ini sering terabaikan dan hasil pemilihan rawan bias.')
doc.add_heading('2.3 Pengguna Program', level=2)
par('Pengguna program adalah pengurus TAGANA Kota Bandung yang menangani keanggotaan dan penugasan relawan (koordinator TAGANA dan petugas sekretariat). Program diakses melalui browser dan dilindungi halaman login, sehingga hanya pengurus dengan akun aktif yang dapat mengelola data kriteria, data relawan, penilaian, serta melihat hasil perhitungan dan laporan.')
doc.add_heading('2.4 Manfaat Program', level=2)
par('Program memberikan tiga manfaat utama bagi organisasi. Pertama, keputusan menjadi transparan dan dapat ditelusuri karena seluruh langkah perhitungan MABAC — mulai dari matriks keputusan hingga skor akhir — ditampilkan lengkap pada halaman perhitungan. Kedua, proses seleksi menjadi cepat karena penilaian ulang cukup mengubah data, perhitungan berjalan otomatis. Ketiga, hasil dapat langsung dipertanggungjawabkan dalam bentuk laporan resmi yang siap dicetak maupun diekspor ke PDF dan Excel.')
doc.add_heading('2.5 Output Keputusan yang Dihasilkan', level=2)
par('Program menghasilkan perangkingan delapan relawan berdasarkan skor MABAC (S) beserta rekomendasi tiga besar sebagai relawan inti. Untuk data studi kasus ini, program merekomendasikan Siti Nurhaliza (A2) sebagai relawan inti utama dengan skor S = 0,1941, disusul Rani Puspita (A6) dan Bagas Prasetyo (A1) dengan skor 0,1608.')

# ===== 3. KESESUAIAN SPK =====
doc.add_heading('3. KESESUAIAN PROGRAM DENGAN KONSEP SPK', level=1)
par('Bagian ini menjelaskan bagaimana program memenuhi konsep Sistem Pendukung Keputusan.')
doc.add_heading('3.1 Konsep Dasar SPK pada Program', level=2)
par('Program ini memenuhi konsep Sistem Pendukung Keputusan karena memadukan tiga unsur utama SPK: (1) data, berupa delapan alternatif relawan dan lima kriteria beserta bobot dan nilai penilaiannya yang tersimpan dalam basis data MySQL; (2) model, berupa metode MABAC yang diimplementasikan pada kelas Mabac.php untuk mengolah data menjadi perangkingan; serta (3) antarmuka, berupa menu interaktif untuk mengelola data, menjalankan perhitungan, dan membaca hasil. Program tidak sekadar menyimpan data relawan, melainkan menghasilkan rekomendasi keputusan berupa ranking beserta seluruh jejak perhitungannya.')
doc.add_heading('3.2 Karakteristik SPK pada Program', level=2)
tabel(['Karakteristik SPK', 'Bukti pada Program'], [
    ['Interaktif', 'Pengguna memasukkan dan mengubah data kriteria, relawan, dan penilaian melalui form, lalu melihat hasil perangkingan secara langsung di menu Hasil & Ranking.'],
    ['Fleksibel', 'Kriteria dan alternatif dapat ditambah, diubah, dan dihapus; bobot serta tipe benefit/cost setiap kriteria dapat disesuaikan tanpa mengubah kode program.'],
    ['Adaptif', 'Perhitungan tidak terikat pada delapan relawan ini saja; relawan atau kriteria baru otomatis ikut dinormalisasi dan diranking dengan rumus yang sama.'],
    ['Berbasis data dan model', 'Data tersimpan di MySQL (tabel kriteria, alternatif, penilaian, pengguna); model perhitungan MABAC diimplementasikan pada kelas Mabac.php.'],
    ['Mendukung, bukan menggantikan keputusan', 'Hasil perangkingan bersifat rekomendasi; keputusan akhir tetap berada di tangan koordinator TAGANA yang dapat mempertimbangkan faktor lain di luar model.'],
    ['Transparan/dapat ditelusuri', 'Halaman Perhitungan MABAC menampilkan enam langkah perhitungan secara utuh: matriks keputusan, normalisasi, matriks terbobot, area batas, jarak, dan skor akhir.'],
])
doc.add_heading('3.3 Komponen Utama SPK pada Program', level=2)
tabel(['Komponen Utama SPK', 'Implementasi dalam Program'], [
    ['Subsistem Data / Data Management', 'Basis data MySQL spk_mabac dengan tabel kriteria (kode, nama, tipe, bobot), alternatif (kode, nama, kontak, alamat), penilaian (matriks keputusan), dan pengguna. Dikelola melalui menu Kriteria serta Relawan & Penilaian.'],
    ['Subsistem Model / Model Management', 'Metode MABAC pada src/Mabac.php: normalisasi min-max benefit/cost, matriks terbobot v = w(n+1), area batas g sebagai akar geometrik kolom, jarak q = v − g, dan skor S = Σq.'],
    ['Subsistem Dialog / User Interface', 'Antarmuka web bergaya glassmorphism (soft teal + soft coral) dengan navigasi sidebar, notifikasi SweetAlert2, ikon php-lucide, form penilaian terintegrasi, serta halaman laporan siap cetak.'],
    ['Basis Pengetahuan / Aturan Penilaian', 'Aturan penilaian skala 1–5 untuk seluruh kriteria; kriteria risiko kesehatan diperlakukan sebagai cost sehingga nilainya dibalik saat normalisasi; bobot kriteria dijumlahkan dan diperingkas menjadi bobot ternormalisasi.'],
])
doc.add_heading('3.4 Ketercapaian Target Capaian Pembelajaran SPK', level=2)
tabel(['Target Capaian', 'Bukti pada Program/Laporan'], [
    ['Memahami konsep SPK', 'Program menerapkan struktur data–model–antarmuka SPK (Bab 3.1–3.3) dan menghasilkan rekomendasi, bukan sekadar penyimpanan data.'],
    ['Memahami data dan pembobotan', 'Delapan alternatif dan lima kriteria dengan tipe benefit/cost serta bobot total 100% dikelola langsung dari aplikasi (Bab 5).'],
    ['Menerapkan metode SPK', 'Enam langkah MABAC diimplementasikan dan ditampilkan utuh pada halaman Perhitungan MABAC (Bab 6.6).'],
    ['Menghasilkan keputusan/ranking', 'Perangkingan delapan alternatif dengan skor S dan rekomendasi tiga besar relawan inti (Bab 7).'],
    ['Memvalidasi hasil keputusan', 'Hasil program dibandingkan dengan perhitungan manual berbasis spreadsheet dan menghasilkan nilai yang sama persis (Bab 9.2).'],
])

# ===== 4. SPESIFIKASI =====
doc.add_heading('4. SPESIFIKASI PROGRAM', level=1)
doc.add_heading('4.1 Spesifikasi Teknis', level=2)
tabel(['Komponen', 'Keterangan'], [
    ['Bahasa Pemrograman', 'PHP 8.2 (native, arsitektur modular tanpa framework)'],
    ['Framework/Library', 'SweetAlert2 (notifikasi & konfirmasi), php-lucide via Composer (ikon SVG), html2pdf.js (ekspor PDF laporan)'],
    ['Database', 'MySQL/MariaDB (paket XAMPP), basis data spk_mabac'],
    ['Tools Editor', 'Visual Studio Code'],
    ['Browser/Runtime', 'Google Chrome / Microsoft Edge'],
    ['Sistem Operasi', 'Microsoft Windows (XAMPP sebagai server lokal)'],
    ['Antarmuka', 'Native CSS bergaya glassmorphism, warna utama soft teal (#3fa796) dan soft coral (#f98877)'],
])
doc.add_heading('4.2 Struktur Folder Program', level=2)
struktur = [
    'spk-mabac/',
    '├── assets/              CSS (style.css) dan JavaScript (app.js)',
    '├── config/              Konfigurasi koneksi basis data (database.php)',
    '├── database/            Skrip skema + data kasus (spk_mabac.sql)',
    '├── includes/            Fungsi bantu (helpers.php) dan layout (header, footer)',
    '├── src/                 Kelas perhitungan MABAC (Mabac.php)',
    '├── vendor/              Library Composer (php-lucide)',
    '├── index.php            Dashboard',
    '├── login.php            Autentikasi pengguna',
    '├── logout.php           Pengakhiran sesi',
    '├── kriteria.php         Menu data kriteria',
    '├── alternatif.php       Menu data relawan dan penilaian',
    '├── perhitungan.php      Menu langkah perhitungan MABAC',
    '├── hasil.php            Menu hasil ranking',
    '├── laporan.php          Halaman laporan (cetak, PDF, Excel)',
    '└── export_excel.php     Unduhan laporan format Excel',
]
for baris in struktur:
    par(baris, style='KodeProgram')
par('')

# ===== 5. DATA =====
doc.add_heading('5. DATA YANG DIGUNAKAN DALAM PROGRAM', level=1)
doc.add_heading('5.1 Data Alternatif', level=2)
par('Alternatif adalah delapan relawan aktif TAGANA Kota Bandung yang diusulkan mengikuti seleksi relawan inti program tanggap bencana. Data diperoleh dari hasil penilaian koordinator terhadap rekam jejak anggota (studi kasus), kemudian diinput ke dalam program.')
tabel(['Kode', 'Nama Relawan', 'Domisili'],
      [[a['kode'], a['nama'], a['alamat']] for a in DATA['alternatif']])
doc.add_heading('5.2 Data Kriteria', level=2)
par('Lima kriteria digunakan dengan total bobot 100%. Bobot terbesar diberikan pada pengalaman lapangan karena relawan inti harus mampu bekerja di lokasi bencana yang menekan, sementara risiko kesehatan menjadi satu-satunya kriteria cost.')
tabel(['Kode', 'Nama Kriteria', 'Bobot', 'Jenis', 'Keterangan'],
      [[k['kode'], k['nama'], f"{float(k['bobot']):g}%", k['tipe'].capitalize(), k['keterangan']] for k in DATA['kriteria']])
doc.add_heading('5.3 Matriks Keputusan', level=2)
par('Nilai penilaian seluruh alternatif dinyatakan dalam skala 1–5 sesuai matriks keputusan berikut (nilai 5 berarti sangat baik untuk kriteria benefit, dan sangat berisiko untuk kriteria cost C5).')
tabel(['Alternatif'] + [k['kode'] for k in DATA['kriteria']],
      [[DATA['alternatif'][i]['kode'] + ' ' + DATA['alternatif'][i]['nama']] +
       [f"{v:g}" for v in baris] for i, baris in enumerate(DATA['matrix'])])

# ===== 6. CARA KERJA =====
doc.add_heading('6. CARA KERJA DAN PENGGUNAAN PROGRAM', level=1)
doc.add_heading('6.1 Halaman Login / Akses Awal Program', level=2)
gambar('6-1-login.png', 13.5, 'Gambar 6.1 untuk Halaman Login')
par('Program diakses melalui browser pada alamat localhost/spk-mabac. Pengunjung yang belum memiliki sesi aktif otomatis diarahkan ke halaman login seperti pada gambar. Username dan password diperiksa terhadap tabel pengguna dengan verifikasi hash (password_verify), dan setelah login berhasil pengguna diarahkan ke dashboard dengan sesi yang di-regenerate untuk mencegah session fixation.')
doc.add_heading('6.2 Dashboard / Halaman Utama', level=2)
gambar('6-2-dashboard.png', 15, 'Gambar 6.2 untuk Dashboard')
par('Dashboard merangkum jumlah kriteria, jumlah relawan, jumlah penilaian, dan total bobot dalam kartu statistik, menampilkan daftar kriteria beserta tipenya, serta pratinjau tiga relawan teratas lengkap dengan grafik skornya. Dari halaman ini pengguna langsung mengetahui apakah data sudah siap dihitung.')
doc.add_heading('6.3 Menu Data Kriteria', level=2)
gambar('6-3-kriteria.png', 15, 'Gambar 6.3 untuk Menu Data Kriteria')
par('Menu ini menampilkan daftar kriteria beserta kode, nama, tipe benefit/cost, dan bobot. Kriteria dapat ditambah, diubah, dan dihapus melalui formulir di sisi kanan; setiap penghapusan dikonfirmasi dengan dialog SweetAlert2. Sistem memvalidasi keunikan kode kriteria dan menampilkan peringatan otomatis bila total bobot tidak genap 100% — perhitungan tetap berjalan karena bobot diperingkas secara proporsional.')
doc.add_heading('6.4 Menu Data Alternatif', level=2)
gambar('6-4-alternatif.png', 15, 'Gambar 6.4 untuk Menu Data Alternatif')
par('Menu Relawan & Penilaian mengelola delapan kandidat relawan. Tabel daftar relawan menampilkan kode, nama, domisili, kontak, serta nilai setiap kriteria (kolom C1–C5) sehingga kelengkapan penilaian terlihat sekilas. Data alternatif inilah yang menjadi baris matriks keputusan program.')
doc.add_heading('6.5 Menu Penilaian Alternatif', level=2)
gambar('6-5-penilaian.png', 15, 'Gambar 6.5 untuk Form Penilaian Alternatif')
par('Penilaian terintegrasi pada formulir yang sama dengan data relawan: setiap relawan diberi nilai 1–5 pada seluruh kriteria. Saat relawan baru ditambahkan, nilainya diwajibkan lengkap untuk semua kriteria; saat data diubah, nilai disimpan melalui perintah INSERT ... ON DUPLICATE KEY UPDATE sehingga tidak pernah terjadi duplikasi baris penilaian.')
doc.add_heading('6.6 Menu Proses Perhitungan', level=2)
par('Sebelum melihat hasil, berikut rumus lengkap metode MABAC yang diimplementasikan program. Dengan m banyaknya alternatif, n banyaknya kriteria, xᵢⱼ nilai alternatif i pada kriteria j, dan bⱼ bobot kriteria j:')
rumus('wⱼ = bⱼ / Σ bⱼ', '1')
rumus('nᵢⱼ = (xᵢⱼ − min xⱼ) / (max xⱼ − min xⱼ), kriteria benefit', '2')
rumus('nᵢⱼ = (xᵢⱼ − max xⱼ) / (min xⱼ − max xⱼ), kriteria cost', '3')
rumus('vᵢⱼ = wⱼ · (nᵢⱼ + 1)', '4')
rumus('gⱼ = (∏ vᵢⱼ)^(1/m)', '5')
rumus('qᵢⱼ = vᵢⱼ − gⱼ', '6')
rumus('Sᵢ = Σ qᵢⱼ', '7')
par('Halaman Perhitungan MABAC menampilkan keenam langkah tersebut secara berurutan dan dapat dibuka tanpa menekan tombol apa pun karena hasil dihitung ulang setiap kali halaman dimuat.')
gambar('6-6-perhitungan.png', 15, 'Gambar 6.6 untuk Langkah Perhitungan MABAC')
par('Langkah 1 menampilkan matriks keputusan X beserta bobot ternormalisasi setiap kriteria (rumus 1). Langkah 2 menampilkan nilai min/max per kriteria lalu matriks ternormalisasi N hasil rumus (2) dan (3). Langkah 3 menghitung matriks terbobot V dengan rumus (4). Langkah 4 menghitung area batas G dengan akar geometrik per kolom sesuai rumus (5). Langkah 5 menampilkan matriks jarak Q = V − G dengan pewarnaan: nilai positif (teal) berarti relawan berada di atas area batas, negatif (koral) di bawahnya. Langkah 6 menjumlahkan baris Q menjadi skor S (rumus 7) sekaligus tabel peringkat.')
doc.add_heading('6.7 Menu Hasil Ranking / Laporan', level=2)
gambar('6-7-hasil.png', 15, 'Gambar 6.7 untuk Halaman Hasil Ranking')
par('Halaman Hasil & Ranking menampilkan kartu rekomendasi relawan peringkat pertama, tabel peringkat akhir dengan keterangan tiga besar sebagai relawan inti, serta grafik batang perbandingan skor seluruh relawan yang dianimasikan saat halaman dibuka.')
gambar('6-8-laporan.png', 15, 'Gambar 6.8 untuk Halaman Laporan dan Ekspor')
par('Halaman Laporan menyajikan lembar resmi berisi kop laporan, tabel kriteria, matriks penilaian, peringkat akhir, dan blok tanda tangan. Tersedia tiga tombol terpisah: Cetak membuka dialog cetak browser dengan tata letak khusus cetak, Simpan PDF mengunduh berkas PDF langsung dari lembar laporan, dan Simpan Excel mengunduh berkas .xls yang memuat tabel kriteria, matriks, dan peringkat.')

# ===== 7. HASIL =====
doc.add_heading('7. HASIL PROGRAM DAN PENJELASAN OUTPUT', level=1)
par('Berdasarkan perhitungan MABAC terhadap matriks keputusan pada Bab 5.3 dengan bobot ternormalisasi w = (0,30; 0,25; 0,20; 0,15; 0,10), program menghasilkan perangkingan berikut.')
tabel(['Peringkat', 'Kode', 'Nama Relawan', 'Skor (S)', 'Rekomendasi'],
      [[p['rank'], p['kode'], p['nama'], f"{p['skor']:.4f}", 'Relawan Inti' if p['rank'] <= 3 else 'Kandidat Pendukung']
       for p in DATA['peringkat']])
par('Program merekomendasikan Siti Nurhaliza (A2) sebagai relawan inti utama dengan skor S = 0,1941. Relawan ini unggul karena kombinasi yang seimbang di seluruh kriteria: kesiapan waktu dan kemampuan komunikasi tertinggi (skala 5), pelatihan dasar kuat (4), pengalaman lapangan menengah-atas (3), serta risiko kesehatan terendah (1). Rani Puspita (A6) dan Bagas Prasetyo (A1) berada pada posisi kedua dan ketiga dengan skor identik 0,1608 — A6 menonjol pada pelatihan dasar (5) dan risiko kesehatan rendah (1), sedangkan A1 menonjol pada pengalaman lapangan dan komunikasi (4). Sebaliknya, Dimas Saputra (A7) menempati peringkat terakhir (S = −0,1225) karena meskipun pengalaman lapangannya tinggi (5), pelatihan dasar (2) dan komunikasi (2) lemah; Fajar Nugroho (A5) juga tertahan oleh kesiapan waktu rendah (2) dan risiko kesehatan tertinggi (4). Relawan dengan skor S negatif berada di bawah area batas secara keseluruhan sehingga belum layak ditetapkan sebagai relawan inti.')

# ===== 8. LISTING =====
doc.add_heading('8. LISTING PROGRAM DAN PENJELASAN FUNGSI KODE', level=1)
par('Bagian ini menampilkan kode inti program: koneksi basis data, pengelolaan data, perhitungan metode MABAC, dan penyajian hasil ranking.')
doc.add_heading('8.1 Kode Koneksi Database (config/database.php)', level=2)
for baris in [
    "<?php",
    "",
    "function db(): PDO",
    "{",
    "    static $pdo = null;",
    "",
    "    if ($pdo === null) {",
    "        $pdo = new PDO(",
    "            'mysql:host=localhost;dbname=spk_mabac;charset=utf8mb4',",
    "            'root',",
    "            '',",
    "            [",
    "                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,",
    "                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,",
    "            ]",
    "        );",
    "    }",
    "",
    "    return $pdo;",
    "}",
]:
    par(baris, style='KodeProgram')
par('Fungsi db() membuka satu koneksi PDO ke basis data spk_mabac dan menyimpannya pada variabel static sehingga seluruh halaman memakai koneksi yang sama (pola singleton). Mode ERRMODE_EXCEPTION membuat setiap kesalahan query langsung dilempar sebagai exception, dan hasil fetch otomatis berupa array asosiatif.')
doc.add_heading('8.2 Kode Input Data Kriteria dan Penilaian (kriteria.php, alternatif.php)', level=2)
for baris in [
    "// menyimpan / mengubah kriteria (kriteria.php)",
    "if (!empty($_POST['id'])) {",
    "    $sql = 'UPDATE kriteria SET kode = ?, nama = ?, tipe = ?, bobot = ?, keterangan = ? WHERE id = ?';",
    "    db()->prepare($sql)->execute([$kode, $nama, $tipe, $bobot, $keterangan, (int) $_POST['id']]);",
    "} else {",
    "    $sql = 'INSERT INTO kriteria (kode, nama, tipe, bobot, keterangan) VALUES (?, ?, ?, ?, ?)';",
    "    db()->prepare($sql)->execute([$kode, $nama, $tipe, $bobot, $keterangan]);",
    "}",
    "",
    "// menyimpan nilai penilaian relawan (alternatif.php)",
    "$stmtNilai = db()->prepare(",
    "    'INSERT INTO penilaian (alternatif_id, kriteria_id, nilai) VALUES (?, ?, ?)",
    "     ON DUPLICATE KEY UPDATE nilai = VALUES(nilai)'",
    ");",
    "foreach ($kriteria as $k) {",
    "    $stmtNilai->execute([$id, $k['id'], (float) $nilai[$k['id']]]);",
    "}",
]:
    par(baris, style='KodeProgram')
par('Seluruh penyimpanan memakai prepared statement dengan placeholder (?) sehingga aman dari SQL injection. Perintah INSERT ... ON DUPLICATE KEY UPDATE pada tabel penilaian memanfaatkan unique key (alternatif_id, kriteria_id): jika relawan dinilai ulang, baris lamanya diperbarui, bukan diduplikasi.')
doc.add_heading('8.3 Kode Perhitungan Metode MABAC (src/Mabac.php)', level=2)
for baris in [
    "public function normalisasi(): array",
    "{",
    "    foreach ($this->kriteria as $j => $kriteria) {",
    "        $kolom = array_column($this->matrix, $j);",
    "        $max = max($kolom);",
    "        $min = min($kolom);",
    "",
    "        foreach ($kolom as $i => $nilai) {",
    "            $hasil[$i][$j] = $kriteria['tipe'] === 'benefit'",
    "                ? ($nilai - $min) / ($max - $min)",
    "                : ($nilai - $max) / ($min - $max);",
    "        }",
    "    }",
    "",
    "    return $hasil;",
    "}",
    "",
    "public function batas(array $terbobot): array",
    "{",
    "    for ($j = 0; $j < $this->jumlahKriteria; $j++) {",
    "        $produk = 1.0;",
    "        for ($i = 0; $i < $this->jumlahAlternatif; $i++) {",
    "            $produk *= $terbobot[$i][$j];",
    "        }",
    "        $hasil[$j] = $produk ** (1 / $this->jumlahAlternatif);",
    "    }",
    "",
    "    return $hasil;",
    "}",
]:
    par(baris, style='KodeProgram')
par('Metode normalisasi() menerapkan rumus (2) dan (3): kriteria benefit memakai (x−min)/(max−min) dan kriteria cost memakai (x−max)/(min−max), sehingga arah preferensi C5 otomatis dibalik. Metode batas() menghitung area batas g dengan akar geometrik kolom matriks terbobot sesuai rumus (5). Bersama terbobot() [rumus (4)] dan jarak() [rumus (6)], kelas ini menghasilkan matriks Q yang dijumlahkan menjadi skor S [rumus (7)].')
doc.add_heading('8.4 Kode Hasil Ranking (src/Mabac.php, hasil.php)', level=2)
for baris in [
    "public function peringkat(): array",
    "{",
    "    $jarak = $this->jarak($this->terbobot($this->normalisasi()), ...);",
    "",
    "    foreach ($jarak as $i => $baris) {",
    "        $peringkat[] = [",
    "            'alternatif' => $this->alternatif[$i],",
    "            'skor' => array_sum($baris),",
    "        ];",
    "    }",
    "",
    "    usort($peringkat, fn($a, $b) => $b['skor'] <=> $a['skor']);",
    "}",
    "",
    "// penyajian di halaman hasil (hasil.php)",
    "$data = dataset();",
    "$peringkat = $data ? $data['mabac']->peringkat() : [];",
    "$juara = $peringkat[0] ?? null;",
]:
    par(baris, style='KodeProgram')
par('Fungsi peringkat() menjumlahkan setiap baris matriks jarak menjadi skor S, lalu mengurutkan alternatif dari skor tertinggi ke terendah (usort) dan memberi nomor peringkat. Halaman hasil mengambil elemen pertama sebagai rekomendasi utama (kartu juara) dan menandai tiga besar sebagai relawan inti.')

# ===== 9. PENGUJIAN =====
doc.add_heading('9. PENGUJIAN DAN VALIDASI PROGRAM', level=1)
doc.add_heading('9.1 Pengujian Fungsional', level=2)
tabel(['No', 'Fungsi yang Diuji', 'Skenario Pengujian', 'Hasil yang Diharapkan', 'Status'], [
    ['1', 'Login', 'Masuk dengan password salah lalu password benar', 'Login ditolak dengan peringatan, lalu berhasil dan diarahkan ke dashboard', 'Berhasil'],
    ['2', 'Input kriteria', 'Menambah kriteria baru dengan kode duplikat lalu kode unik', 'Kode duplikat ditolak; kode unik tersimpan dan tampil pada tabel', 'Berhasil'],
    ['3', 'Input alternatif', 'Menambah, mengedit, dan menghapus relawan', 'Data tersimpan; penilaian relawan ikut terhapus (cascade)', 'Berhasil'],
    ['4', 'Penilaian', 'Mengisi nilai 1–5 seluruh kriteria lalu menyimpan', '40 nilai tersimpan tanpa duplikat melalui mekanisme upsert', 'Berhasil'],
    ['5', 'Proses hitung', 'Membuka halaman Perhitungan MABAC dengan data lengkap', 'Enam langkah perhitungan tampil tanpa kesalahan', 'Berhasil'],
    ['6', 'Hasil ranking', 'Membaca peringkat dan kartu rekomendasi', 'Ranking terurut sesuai skor S tertinggi', 'Berhasil'],
    ['7', 'Laporan & ekspor', 'Menekan Cetak, Simpan PDF, dan Simpan Excel', 'Dialog cetak muncul; berkas PDF dan .xls terunduh berisi data yang sama', 'Berhasil'],
])
doc.add_heading('9.2 Validasi Hasil Perhitungan', level=2)
par('Validasi dilakukan dengan menghitung ulang seluruh langkah MABAC secara manual menggunakan spreadsheet. Contoh perhitungan untuk relawan A1 (Bagas Prasetyo) dengan nilai x = (4, 5, 3, 4, 2): hasil normalisasi menurut rumus (2)–(3) adalah n = (0,6667; 1; 0,3333; 0,6667; 0,6667); matriks terbobot menurut rumus (4) menjadi v = (0,5; 0,5; 0,2667; 0,25; 0,1667); dengan area batas g = (0,4356; 0,3869; 0,3095; 0,2322; 0,1583) hasil rumus (5), jarak q = v − g = (0,0644; 0,1131; −0,0429; 0,0178; 0,0083) menurut rumus (6); sehingga skor S = 0,1608 sesuai rumus (7) — sama dengan output program.')
tabel(['Alternatif', 'Skor Program', 'Skor Manual', 'Selisih'],
      [[r['kode'] + ' ' + r['nama'], f"{r['program']:.4f}", f"{r['manual']:.4f}", f"{r['selisih']:.4f}"]
       for r in VALIDASI['banding']])
par('Hasil perhitungan program dan perhitungan manual sama persis (selisih 0 pada seluruh alternatif), sehingga validitas perhitungan program terbukti.')

# ===== 10. KENDALA =====
doc.add_heading('10. KENDALA DAN PENGEMBANGAN PROGRAM', level=1)
par('Kendala: (1) kriteria risiko kesehatan bersifat cost sehingga penanganannya berbeda dari kriteria lain — pada pengembangan awal nilainya sempat diperlakukan benefit sehingga relawan dengan risiko tinggi justru unggul, kendala ini diperbaiki dengan pemisahan tipe benefit/cost saat normalisasi; (2) dua relawan memperoleh skor seri (0,1608) sehingga urutan peringkat perlu penanda yang jelas pada tampilan; (3) efek glassmorphism dengan backdrop-filter tidak konsisten pada browser lama sehingga diperlukan fallback warna; (4) penentuan bobot kriteria yang wajar menuntut diskusi dengan koordinator organisasi karena bersifat kualitatif.')
par('Saran pengembangan: (1) riwayat penugasan relawan agar penilaian tidak hanya berdasarkan skor tunggal; (2) perbandingan antarmetode (SAW, TOPSIS, MABAC) untuk analisis sensitivitas; (3) ekspor laporan dengan tanda tangan elektronik; (4) notifikasi hasil ke relawan melalui WhatsApp/email; dan (5) dukungan multi-cabang organisasi dengan satu basis data terpusat.')

# ===== 11. KESIMPULAN =====
doc.add_heading('11. KESIMPULAN', level=1)
par('Program SPK Pemilihan Relawan Inti untuk Program Tanggap Bencana berhasil dibangun menggunakan PHP native dan MySQL dengan metode MABAC. Program membantu TAGANA Kota Bandung mengambil keputusan seleksi secara objektif, transparan, dan dapat ditelusuri atas delapan kandidat relawan terhadap lima kriteria (empat benefit, satu cost) dengan total bobot 100%. Hasil perhitungan menempatkan Siti Nurhaliza (A2) sebagai rekomendasi relawan inti utama dengan skor S = 0,1941, disusul Rani Puspita (A6) dan Bagas Prasetyo (A1) dengan skor 0,1608 yang bersama-sama membentuk tiga besar relawan inti. Validasi terhadap perhitungan manual menunjukkan hasil yang identik tanpa selisih, sehingga program layak digunakan sebagai alat bantu pengambilan keputusan pengelolaan relawan di lingkungan organisasi sosial kebencanaan.')

# ===== 12. DAFTAR PUSTAKA =====
doc.add_heading('12. DAFTAR PUSTAKA', level=1)
pustaka = [
    'Kementerian Sosial Republik Indonesia. (t.t.). Taruna Siaga Bencana (TAGANA): profil dan tugas pokok. https://kemensos.go.id',
    'Kusumadewi, S., Hartati, S., Harjoko, A., & Wardoyo, R. (2006). Fuzzy Multi-Attribute Decision Making (Fuzzy MADM). Yogyakarta: Graha Ilmu.',
    'Pamučar, D., & Ćirović, G. (2015). The selection of transport and handling resources in logistics centers using Multi-Attributive Borderline Area Comparison (MABAC). Expert Systems with Applications, 42(6), 3018–3032. https://doi.org/10.1016/j.eswa.2014.11.057',
    'PHP Documentation Project. (t.t.). PHP: PDO statements. https://www.php.net/manual/en/book.pdo.php',
    'Republik Indonesia. (2007). Undang-Undang Nomor 24 Tahun 2007 tentang Penanggulangan Bencana. Lembaran Negara Republik Indonesia Tahun 2007 Nomor 66.',
    'SweetAlert2 Contributors. (t.t.). SweetAlert2 — beautiful, responsive, customizable JavaScript popups. https://sweetalert2.github.io',
    'Turban, E., Aronson, J. E., & Liang, T. P. (2005). Decision Support Systems and Intelligent Systems (7th ed.). Upper Saddle River: Pearson Education.',
    'Wiebe, N. (t.t.). php-lucide: PHP library for Lucide icons (Version 1.0) [pustaka Composer]. https://github.com/natewiebe13/php-lucide',
    'Lucide Icons Contributors. (t.t.). Lucide — beautiful & consistent icon toolkit. https://lucide.dev',
    'Badan Nasional Penanggulangan Bencana. (t.t.). Relawan dan peran masyarakat dalam penanggulangan bencana. https://bnpb.go.id',
]
for ref in pustaka:
    p = doc.add_paragraph(ref)
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.space_after = Pt(12)
    p.paragraph_format.left_indent = Cm(1.25)
    p.paragraph_format.first_line_indent = Cm(-1.25)

doc.save('Laporan_Project_SPK_Fabregas_Andana.docx')
print('TERSIMPAN')
