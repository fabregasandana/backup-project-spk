import os
import time
import win32com.client as win32

BASE = os.path.abspath('.')
DOCX = os.path.join(BASE, 'Laporan_Project_SPK_Fabregas_Andana.docx')
PDF = os.path.join(BASE, 'Laporan_Project_SPK_Fabregas_Andana.pdf')

word = win32.gencache.EnsureDispatch('Word.Application')
word.Visible = False
word.DisplayAlerts = 0
try:
    doc = word.Documents.Open(DOCX)
    doc.Repaginate()
    doc.TablesOfContents.Item(1).Update()
    doc.Fields.Update()

    for nm in ('TOC 1', 'TOC 2'):
        pf = doc.Styles.Item(nm).ParagraphFormat
        pf.LineSpacingRule = 0  # wdLineSpaceSingle
        pf.SpaceBefore = 0
        pf.SpaceAfter = 4
    doc.TablesOfContents.Item(1).Update()

    # pastikan entri TOC benar-benar satu spasi (format langsung)
    toc = doc.TablesOfContents.Item(1)
    paras = toc.Range.Paragraphs
    for k in range(1, paras.Count + 1):
        f = paras.Item(k).Format
        f.LineSpacingRule = 0
        f.SpaceBefore = 0
        f.SpaceAfter = 4

    doc.Repaginate()
    time.sleep(2)
    pages = doc.ComputeStatistics(2)  # wdStatisticPages
    doc.Save()
    doc.ExportAsFixedFormat(PDF, 17)  # wdExportFormatPDF
    doc.Close(False)
    with open(os.path.join(BASE, '.laporan/toc_update.log'), 'w', encoding='utf-8') as f_:
        f_.write('OK pages=%d\n' % pages)
finally:
    word.Quit()
