import json
import math

d = json.load(open('.laporan/data.json', encoding='utf-8'))
X = d['matrix']
tipe = [k['tipe'] for k in d['kriteria']]
bobot = [float(k['bobot']) for k in d['kriteria']]
total = sum(bobot)
w = [b / total for b in bobot]
m = len(X)
n = len(X[0])

N = [[0.0] * n for _ in range(m)]
for j in range(n):
    col = [X[i][j] for i in range(m)]
    mn, mx = min(col), max(col)
    for i in range(m):
        if mx == mn:
            N[i][j] = 0.0
        elif tipe[j] == 'benefit':
            N[i][j] = (X[i][j] - mn) / (mx - mn)
        else:
            N[i][j] = (X[i][j] - mx) / (mn - mx)

V = [[w[j] * (N[i][j] + 1) for j in range(n)] for i in range(m)]
G = [math.prod(V[i][j] for i in range(m)) ** (1 / m) for j in range(n)]
Q = [[V[i][j] - G[j] for j in range(n)] for i in range(m)]
S = [sum(Q[i]) for i in range(m)]

manual_per_kode = {d['alternatif'][i]['kode']: S[i] for i in range(m)}
out = []
for p in d['peringkat']:
    manual = manual_per_kode[p['kode']]
    out.append({
        'kode': p['kode'], 'nama': p['nama'],
        'program': round(p['skor'], 4), 'manual': round(manual, 4),
        'selisih': round(abs(p['skor'] - manual), 4),
    })

contoh = {
    'A1_normalisasi': [round(v, 4) for v in N[0]],
    'A1_terbobot': [round(v, 4) for v in V[0]],
    'G': [round(v, 4) for v in G],
    'A1_jarak': [round(v, 4) for v in Q[0]],
    'A1_S': round(S[0], 4),
    'bobot_ternormalisasi': [round(v, 4) for v in w],
}

with open('.laporan/validasi.json', 'w', encoding='utf-8') as f:
    json.dump({'banding': out, 'contoh': contoh}, f, ensure_ascii=False, indent=1)
print('sesuai:', all(r['selisih'] == 0 for r in out))
