import re
from pypdf import PdfReader

r = PdfReader('Laporan_Project_SPK_Fabregas_Andana.pdf')
out = []
out.append('total halaman: %d' % len(r.pages))
box = r.pages[0].mediabox
out.append('hal1 mediabox: %s x %s (A4=595.3x841.9)' % (float(box.width), float(box.height)))

for idx in (1, 2):
    t = r.pages[idx].extract_text() or ''
    out.append('--- halaman indeks %d (pdf page %d) ---' % (idx, idx + 1))
    out.append(t)

# footer page numbers: last line of a few pages
for idx in (0, 2, 3, len(r.pages) - 1):
    t = (r.pages[idx].extract_text() or '').strip().splitlines()
    out.append('halaman pdf %d baris terakhir: %r' % (idx + 1, t[-1] if t else ''))

# gambar count per page (images)
img_pages = []
for i, p in enumerate(r.pages):
    try:
        n = len(p.images)
    except Exception:
        n = -1
    if n:
        img_pages.append((i + 1, n))
out.append('halaman berisi gambar: %s' % img_pages)

open('.laporan/verify_pdf.txt', 'w', encoding='utf-8').write('\n'.join(out))
print('SELESAI')
