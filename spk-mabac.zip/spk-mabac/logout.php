<?php

define('BEBAS_LOGIN', true);
require __DIR__ . '/includes/helpers.php';

$_SESSION = [];
session_destroy();

header('Location: ' . BASE_URL . '/login.php');
exit;
