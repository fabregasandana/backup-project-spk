document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    const tombolMenu = document.getElementById('tombolMenu');

    tombolMenu?.addEventListener('click', () => {
        sidebar.classList.add('buka');
        overlay.classList.add('tampil');
    });

    overlay?.addEventListener('click', () => {
        sidebar.classList.remove('buka');
        overlay.classList.remove('tampil');
    });

    const { flash } = window.APP;
    if (flash) {
        Swal.fire({
            toast: true,
            position: 'top-end',
            icon: flash.type,
            title: flash.pesan,
            showConfirmButton: false,
            timer: 2800,
            timerProgressBar: true,
        });
    }

    document.querySelectorAll('[data-hapus]').forEach((form) => {
        form.addEventListener('submit', (event) => {
            event.preventDefault();
            Swal.fire({
                title: 'Hapus data ini?',
                text: form.dataset.hapus,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, hapus',
                cancelButtonText: 'Batal',
                confirmButtonColor: '#e2695a',
                cancelButtonColor: '#3fa796',
            }).then((hasil) => {
                if (hasil.isConfirmed) form.submit();
            });
        });
    });

    document.querySelectorAll('.grafik-isi[data-lebar]').forEach((bar) => {
        setTimeout(() => {
            bar.style.width = bar.dataset.lebar + '%';
        }, 150);
    });
});
