<?php
require __DIR__ . '/includes/helpers.php';

$page = 'perhitungan';
$judul = 'Perhitungan MABAC';

$data = dataset();

require __DIR__ . '/includes/header.php';

function tabel_matriks(array $isi, array $alternatif, array $kriteria, bool $warna = false, int $desimal = 4): void
{
    echo '<div class="tabel-wrap"><table><thead><tr><th></th>';
    foreach ($kriteria as $k) {
        echo '<th class="num">' . e($k['kode']) . '</th>';
    }
    echo '</tr></thead><tbody>';
    foreach ($isi as $i => $baris) {
        echo '<tr><td><strong>' . e($alternatif[$i]['kode']) . '</strong></td>';
        foreach ($baris as $nilai) {
            $gaya = '';
            if ($warna) {
                $gaya = $nilai >= 0 ? ' style="color:var(--teal-tua);font-weight:700"' : ' style="color:var(--coral-tua);font-weight:700"';
            }
            echo '<td class="num"' . $gaya . '>' . fmt($nilai, $desimal) . '</td>';
        }
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}

function langkah_header(int $nomor, string $judul, string $penjelasan): void
{
    echo '<div class="kartu">';
    echo '<div class="kartu-judul"><div><h2><span class="langkah-badge">' . $nomor . '</span> ' . e($judul) . '</h2>';
    echo '<p>' . $penjelasan . '</p></div></div>';
}
?>

<?php if (!$data): ?>
    <div class="kartu">
        <div class="kosong">
            <?= icon('alert-triangle', '', 44) ?>
            <p>Data belum lengkap. Pastikan kriteria terisi dan setiap relawan memiliki nilai pada seluruh kriteria.</p>
            <br>
            <a class="tombol tombol-utama" href="<?= BASE_URL ?>/alternatif.php"><?= icon('users', '', 16) ?> Lengkapi Data</a>
        </div>
    </div>
<?php else: ?>
    <?php
    $mabac = $data['mabac'];
    $kriteria = $data['kriteria'];
    $alternatif = $data['alternatif'];
    $langkah = $mabac->langkah();
    $bobot = $mabac->bobot();
    ?>

    <div class="pesan pesan-teal">
        <?= icon('info', '', 18) ?>
        Nilai penilaian berskala 1–5. Q positif (teal) berarti relawan berada di atas area batas, Q negatif (koral) berarti di bawahnya.
    </div>

    <?php
    langkah_header(1, 'Matriks Keputusan (X)', 'Nilai awal penilaian setiap relawan terhadap seluruh kriteria beserta bobot ternormalisasi.');
    echo '<div class="tabel-wrap"><table><thead><tr><th></th>';
    foreach ($kriteria as $j => $k) {
        echo '<th class="num">' . e($k['kode']) . '<br><small>' . fmt($bobot[$j] * 100, 2) . '% (' . $k['tipe'] . ')</small></th>';
    }
    echo '</tr></thead><tbody>';
    foreach ($data['matrix'] as $i => $baris) {
        echo '<tr><td><strong>' . e($alternatif[$i]['kode']) . '</strong> ' . e($alternatif[$i]['nama']) . '</td>';
        foreach ($baris as $nilai) {
            echo '<td class="num">' . fmt($nilai) . '</td>';
        }
        echo '</tr>';
    }
    echo '</tbody></table></div></div>';

    langkah_header(2, 'Normalisasi Matriks (N)', 'Benefit: <span class="rumus">n = (x − min) / (max − min)</span> &nbsp;•&nbsp; Cost: <span class="rumus">n = (x − max) / (min − max)</span>');
    $minMax = array_map(fn($j) => array_column($data['matrix'], $j), array_keys($kriteria));
    echo '<div class="tabel-wrap" style="margin-bottom:12px"><table style="min-width:auto"><thead><tr><th></th>';
    foreach ($kriteria as $k) {
        echo '<th class="num">' . e($k['kode']) . '</th>';
    }
    echo '</tr></thead><tbody>';
    echo '<tr><td><strong>Nilai min</strong></td>';
    foreach ($minMax as $kolom) {
        echo '<td class="num">' . fmt(min($kolom)) . '</td>';
    }
    echo '</tr><tr><td><strong>Nilai max</strong></td>';
    foreach ($minMax as $kolom) {
        echo '<td class="num">' . fmt(max($kolom)) . '</td>';
    }
    echo '</tr></tbody></table></div>';
    tabel_matriks($langkah['normalisasi'], $alternatif, $kriteria);
    echo '</div>';

    langkah_header(3, 'Matriks Terbobot (V)', 'Bobot ternormalisasi dikalikan hasil normalisasi yang digeser satu: <span class="rumus">v = w × (n + 1)</span>');
    tabel_matriks($langkah['terbobot'], $alternatif, $kriteria);
    echo '</div>';

    langkah_header(4, 'Area Batas (G)', 'Nilai pembatas setiap kriteria dihitung dari akar geometrik kolom matriks terbobot: <span class="rumus">g = (∏ v)^(1/m)</span> dengan m = ' . count($alternatif) . ' relawan.');
    echo '<div class="tabel-wrap"><table><thead><tr><th>Kriteria</th>';
    foreach ($kriteria as $k) {
        echo '<th class="num">' . e($k['kode']) . '</th>';
    }
    echo '</tr></thead><tbody><tr><td><strong>G (Area Batas)</strong></td>';
    foreach ($langkah['batas'] as $g) {
        echo '<td class="num"><strong>' . fmt($g) . '</strong></td>';
    }
    echo '</tr></tbody></table></div></div>';

    langkah_header(5, 'Jarak dari Area Batas (Q)', 'Selisih nilai terbobot terhadap area batas: <span class="rumus">q = v − g</span>');
    tabel_matriks($langkah['jarak'], $alternatif, $kriteria, true);
    echo '</div>';

    langkah_header(6, 'Skor Akhir (S)', 'Penjumlahan seluruh nilai Q per relawan: <span class="rumus">S = Σ q</span>. Makin tinggi S, makin layak relawan dipilih sebagai relawan inti.');
    $peringkat = $mabac->peringkat();
    echo '<div class="tabel-wrap"><table><thead><tr><th>Rank</th><th>Kode</th><th>Nama</th><th class="num">Skor (S)</th></tr></thead><tbody>';
    foreach ($peringkat as $item) {
        $menang = $item['rank'] === 1 ? ' class="baris-menang"' : '';
        echo '<tr' . $menang . '><td><span class="badge-rank' . ($item['rank'] === 1 ? ' juara' : '') . '">' . $item['rank'] . '</span></td>';
        echo '<td><strong>' . e($item['alternatif']['kode']) . '</strong></td>';
        echo '<td>' . e($item['alternatif']['nama']) . '</td>';
        echo '<td class="num">' . fmt($item['skor']) . '</td></tr>';
    }
    echo '</tbody></table></div>';
    echo '<br><a class="tombol tombol-koral" href="' . BASE_URL . '/hasil.php">' . icon('trophy', '', 16) . ' Lihat Hasil Akhir</a>';
    echo '</div>';
    ?>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
