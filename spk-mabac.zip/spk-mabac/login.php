<?php

define('BEBAS_LOGIN', true);
require __DIR__ . '/includes/helpers.php';

if (!empty($_SESSION['pengguna_id'])) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = db()->prepare('SELECT * FROM pengguna WHERE username = ?');
    $stmt->execute([$username]);
    $pengguna = $stmt->fetch();

    if ($pengguna && password_verify($password, $pengguna['password'])) {
        session_regenerate_id(true);
        $_SESSION['pengguna_id'] = (int) $pengguna['id'];
        $_SESSION['pengguna_nama'] = $pengguna['nama'];
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }

    flash('error', 'Username atau password salah.');
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$flash = ambil_flash();
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk — SPK Relawan Bencana</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>

<body>
    <div class="blob blob-teal"></div>
    <div class="blob blob-coral"></div>

    <div class="login-wrap">
        <div class="login-kartu">
            <div class="brand">
                <span class="brand-ikon"><?= icon('life-buoy', '', 24) ?></span>
                <div>
                    <strong>RelawanTanggap</strong>
                    <small>SPK MABAC</small>
                </div>
            </div>
            <h2>Selamat Datang Kembali</h2>
            <p class="login-sub">Masuk untuk mengelola pemilihan relawan inti program tanggap bencana.</p>

            <form method="post" autocomplete="off">
                <div class="form-grup">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Masukkan username" required autofocus>
                </div>
                <div class="form-grup">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Masukkan password" required>
                </div>
                <button type="submit" class="tombol tombol-utama login-tombol">
                    <?= icon('log-in', '', 18) ?>
                    Masuk
                </button>
            </form>
        </div>
        <p class="footer">SPK Pemilihan Relawan Inti &mdash; Program Tanggap Bencana Organisasi Sosial &copy; <?= date('Y') ?></p>
    </div>

    <script>
        window.APP = {
            flash: <?= json_encode($flash) ?>,
        };
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?= BASE_URL ?>/assets/js/app.js"></script>
</body>

</html>
