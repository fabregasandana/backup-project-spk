<?php
require __DIR__ . '/includes/helpers.php';

$page = 'alternatif';
$judul = 'Relawan & Penilaian';

$kriteria = semua_kriteria();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';

    if ($aksi === 'hapus' && isset($_POST['id'])) {
        db()->prepare('DELETE FROM alternatif WHERE id = ?')->execute([(int) $_POST['id']]);
        flash('success', 'Data relawan berhasil dihapus.');
        header('Location: alternatif.php');
        exit;
    }

    if ($aksi === 'simpan') {
        $kode = trim($_POST['kode'] ?? '');
        $nama = trim($_POST['nama'] ?? '');
        $kontak = trim($_POST['kontak'] ?? '');
        $alamat = trim($_POST['alamat'] ?? '');
        $nilai = $_POST['nilai'] ?? [];

        if ($kode === '' || $nama === '') {
            flash('error', 'Kode dan nama relawan wajib diisi.');
        } else {
            $cek = db()->prepare('SELECT id FROM alternatif WHERE kode = ? AND id != ?');
            $cek->execute([$kode, (int) ($_POST['id'] ?? 0)]);

            if ($cek->fetch()) {
                flash('error', "Kode $kode sudah dipakai relawan lain.");
            } else {
                $lengkap = true;
                foreach ($kriteria as $k) {
                    if (!isset($nilai[$k['id']]) || $nilai[$k['id']] === '') {
                        $lengkap = false;
                        break;
                    }
                }
                if ($kriteria && !$lengkap) {
                    flash('error', 'Nilai penilaian wajib diisi untuk semua kriteria.');
                } else {
                    db()->beginTransaction();
                    if (!empty($_POST['id'])) {
                        $id = (int) $_POST['id'];
                        $sql = 'UPDATE alternatif SET kode = ?, nama = ?, kontak = ?, alamat = ? WHERE id = ?';
                        db()->prepare($sql)->execute([$kode, $nama, $kontak, $alamat, $id]);
                        $pesan = 'Data relawan berhasil diperbarui.';
                    } else {
                        $sql = 'INSERT INTO alternatif (kode, nama, kontak, alamat) VALUES (?, ?, ?, ?)';
                        db()->prepare($sql)->execute([$kode, $nama, $kontak, $alamat]);
                        $id = (int) db()->lastInsertId();
                        $pesan = 'Relawan baru berhasil ditambahkan.';
                    }

                    $stmtNilai = db()->prepare(
                        'INSERT INTO penilaian (alternatif_id, kriteria_id, nilai) VALUES (?, ?, ?)
                         ON DUPLICATE KEY UPDATE nilai = VALUES(nilai)'
                    );
                    foreach ($kriteria as $k) {
                        $stmtNilai->execute([$id, $k['id'], (float) $nilai[$k['id']]]);
                    }
                    db()->commit();

                    flash('success', $pesan);
                    header('Location: alternatif.php');
                    exit;
                }
            }
        }
    }
}

$alternatif = semua_alternatif();
$penilaian = [];
foreach (semua_penilaian() as $p) {
    $penilaian[$p['alternatif_id']][$p['kriteria_id']] = (float) $p['nilai'];
}

$edit = null;
if (isset($_GET['edit'])) {
    $stmt = db()->prepare('SELECT * FROM alternatif WHERE id = ?');
    $stmt->execute([(int) $_GET['edit']]);
    $edit = $stmt->fetch() ?: null;
}

require __DIR__ . '/includes/header.php';
?>

<?php if (!$kriteria): ?>
    <div class="pesan pesan-info">
        <?= icon('alert-triangle', '', 18) ?>
        Tambahkan <a href="kriteria.php" style="color:inherit">kriteria</a> terlebih dahulu agar penilaian relawan dapat diisi.
    </div>
<?php endif; ?>

<div class="kartu">
    <div class="kartu-judul">
        <div>
            <h2><span class="ikon-bulat"><?= icon('users', '', 18) ?></span> Daftar Relawan</h2>
            <p>Kandidat relawan inti beserta kelengkapan penilaian pada setiap kriteria.</p>
        </div>
    </div>
    <div class="tabel-wrap">
        <table>
            <thead>
                <tr>
                    <th>Kode</th>
                    <th>Nama</th>
                    <th>Kontak</th>
                    <?php foreach ($kriteria as $k): ?>
                        <th class="num" title="<?= e($k['nama']) ?>"><?= e($k['kode']) ?></th>
                    <?php endforeach; ?>
                    <th class="num">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($alternatif as $a): ?>
                    <tr>
                        <td><strong><?= e($a['kode']) ?></strong></td>
                        <td>
                            <?= e($a['nama']) ?>
                            <?php if ($a['alamat']): ?>
                                <br><small style="color:var(--teks-tipis)"><?= e($a['alamat']) ?></small>
                            <?php endif; ?>
                        </td>
                        <td><?= e($a['kontak'] ?: '-') ?></td>
                        <?php foreach ($kriteria as $k): ?>
                            <td class="num"><?= isset($penilaian[$a['id']][$k['id']]) ? fmt($penilaian[$a['id']][$k['id']]) : '-' ?></td>
                        <?php endforeach; ?>
                        <td class="num" style="white-space:nowrap">
                            <a class="tombol-kecil tombol-ubah" href="alternatif.php?edit=<?= $a['id'] ?>" title="Ubah">
                                <?= icon('pencil', '', 15) ?>
                            </a>
                            <form method="post" style="display:inline" data-hapus="Data <?= e($a['nama']) ?> beserta penilaiannya akan dihapus.">
                                <input type="hidden" name="aksi" value="hapus">
                                <input type="hidden" name="id" value="<?= $a['id'] ?>">
                                <button type="submit" class="tombol-kecil tombol-hapus" title="Hapus"><?= icon('trash-2', '', 15) ?></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$alternatif): ?>
                    <tr>
                        <td colspan="<?= 4 + count($kriteria) ?>" class="kosong">
                            <?= icon('inbox', '', 40) ?>
                            <p>Belum ada data relawan.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="kartu" id="form-penilaian">
    <div class="kartu-judul">
        <div>
            <h2>
                <span class="ikon-bulat"><?= icon($edit ? 'pencil-line' : 'user-plus', '', 18) ?></span>
                <?= $edit ? 'Ubah Relawan & Penilaian' : 'Tambah Relawan & Penilaian' ?>
            </h2>
            <p>Isi identitas relawan lalu beri nilai 1–5 pada setiap kriteria.</p>
        </div>
    </div>
    <form method="post" class="form-grid">
        <input type="hidden" name="aksi" value="simpan">
        <?php if ($edit): ?>
            <input type="hidden" name="id" value="<?= $edit['id'] ?>">
        <?php endif; ?>
        <div class="form-grup">
            <label for="kode">Kode</label>
            <input type="text" id="kode" name="kode" maxlength="10" placeholder="A9" required value="<?= e($edit['kode'] ?? '') ?>">
        </div>
        <div class="form-grup">
            <label for="nama">Nama Relawan</label>
            <input type="text" id="nama" name="nama" maxlength="100" placeholder="Nama lengkap" required value="<?= e($edit['nama'] ?? '') ?>">
        </div>
        <div class="form-grup">
            <label for="kontak">Kontak</label>
            <input type="text" id="kontak" name="kontak" maxlength="50" placeholder="Nomor telepon" value="<?= e($edit['kontak'] ?? '') ?>">
        </div>
        <div class="form-grup">
            <label for="alamat">Alamat</label>
            <input type="text" id="alamat" name="alamat" maxlength="255" placeholder="Domisili" value="<?= e($edit['alamat'] ?? '') ?>">
        </div>

        <?php foreach ($kriteria as $k): ?>
            <div class="form-grup">
                <label for="nilai-<?= $k['id'] ?>"><?= e($k['kode']) ?> — <?= e($k['nama']) ?></label>
                <input type="number" id="nilai-<?= $k['id'] ?>" name="nilai[<?= $k['id'] ?>]" min="1" max="5" step="1" required
                    value="<?= isset($edit, $penilaian[$edit['id']][$k['id']]) ? fmt($penilaian[$edit['id']][$k['id']]) : '' ?>">
            </div>
        <?php endforeach; ?>

        <div class="form-aksi">
            <button type="submit" class="tombol tombol-utama" <?= $kriteria ? '' : 'disabled' ?>>
                <?= icon($edit ? 'check' : 'plus', '', 16) ?>
                <?= $edit ? 'Simpan Perubahan' : 'Tambah Relawan' ?>
            </button>
            <?php if ($edit): ?>
                <a class="tombol" href="alternatif.php" style="background:rgba(63,167,150,.12);color:var(--teal-tua)">Batal</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
