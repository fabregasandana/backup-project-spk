<?php
require __DIR__ . '/includes/helpers.php';

$page = 'dashboard';
$judul = 'Dashboard';

$kriteria = semua_kriteria();
$alternatif = semua_alternatif();
$totalPenilaian = (int) db()->query('SELECT COUNT(*) FROM penilaian')->fetchColumn();
$totalBobot = array_sum(array_column($kriteria, 'bobot'));

$data = dataset();
$top = $data ? array_slice($data['mabac']->peringkat(), 0, 3) : [];

require __DIR__ . '/includes/header.php';
?>

<div class="grid grid-4">
    <div class="kartu stat">
        <span class="stat-ikon teal"><?= icon('list-checks', '', 26) ?></span>
        <div>
            <div class="stat-angka"><?= count($kriteria) ?></div>
            <div class="stat-label">Kriteria</div>
        </div>
    </div>
    <div class="kartu stat">
        <span class="stat-ikon coral"><?= icon('users', '', 26) ?></span>
        <div>
            <div class="stat-angka"><?= count($alternatif) ?></div>
            <div class="stat-label">Relawan</div>
        </div>
    </div>
    <div class="kartu stat">
        <span class="stat-ikon teal"><?= icon('clipboard-list', '', 26) ?></span>
        <div>
            <div class="stat-angka"><?= $totalPenilaian ?></div>
            <div class="stat-label">Penilaian</div>
        </div>
    </div>
    <div class="kartu stat">
        <span class="stat-ikon coral"><?= icon('scale', '', 26) ?></span>
        <div>
            <div class="stat-angka"><?= fmt($totalBobot) ?>%</div>
            <div class="stat-label">Total Bobot</div>
        </div>
    </div>
</div>

<div class="grid grid-2">
    <div class="kartu">
        <div class="kartu-judul">
            <div>
                <h2><span class="ikon-bulat"><?= icon('scale', '', 18) ?></span> Kriteria Penilaian</h2>
                <p>Lima aspek pembanding relawan, termasuk risiko kesehatan sebagai kriteria biaya.</p>
            </div>
            <a class="tombol tombol-utama" href="<?= BASE_URL ?>/kriteria.php">Kelola</a>
        </div>
        <div class="tabel-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Kriteria</th>
                        <th>Tipe</th>
                        <th class="num">Bobot</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($kriteria as $k): ?>
                        <tr>
                            <td><strong><?= e($k['kode']) ?></strong></td>
                            <td><?= e($k['nama']) ?></td>
                            <td>
                                <span class="badge badge-<?= $k['tipe'] ?>">
                                    <?= icon($k['tipe'] === 'benefit' ? 'trending-up' : 'shield-alert', '', 13) ?>
                                    <?= ucfirst($k['tipe']) ?>
                                </span>
                            </td>
                            <td class="num"><?= fmt((float) $k['bobot']) ?>%</td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$kriteria): ?>
                        <tr>
                            <td colspan="4" class="kosong">Belum ada kriteria. Tambahkan terlebih dahulu.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="kartu">
        <div class="kartu-judul">
            <div>
                <h2><span class="ikon-bulat"><?= icon('sparkles', '', 18) ?></span> Relawan Teratas</h2>
                <p>Pratinjau tiga peringkat tertinggi berdasarkan perhitungan MABAC.</p>
            </div>
            <a class="tombol tombol-koral" href="<?= BASE_URL ?>/hasil.php">Lihat Semua</a>
        </div>
        <?php if ($top): ?>
            <div class="grafik">
                <?php $maks = max(array_column($top, 'skor')) ?: 1; ?>
                <?php foreach ($top as $i => $item): ?>
                    <div class="grafik-baris <?= $i === 0 ? 'pertama' : '' ?>">
                        <strong><?= e($item['alternatif']['nama']) ?></strong>
                        <div class="grafik-lajur">
                            <div class="grafik-isi" data-lebar="<?= max(0, round($item['skor'] / $maks * 100)) ?>"></div>
                        </div>
                        <span class="grafik-skor"><?= fmt($item['skor'], 3) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="kosong">
                <?= icon('inbox', '', 42) ?>
                <p>Data belum lengkap. Isi kriteria dan penilaian seluruh relawan untuk melihat hasil.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
