<?php
// Helper sementara untuk screenshot (dihapus setelah dipakai).
$halaman = $_GET['p'] ?? 'index';
$boleh = ['index', 'kriteria', 'alternatif', 'perhitungan', 'hasil', 'laporan', 'login'];
if (!in_array($halaman, $boleh, true)) {
    http_response_code(404);
    exit;
}
if ($halaman !== 'login') {
    session_start();
    $_SESSION['pengguna_id'] = 1;
    $_SESSION['pengguna_nama'] = 'Administrator';
}
$_SERVER['SCRIPT_NAME'] = '/' . $halaman . '.php';
chdir(__DIR__);
include __DIR__ . '/' . $halaman . '.php';
