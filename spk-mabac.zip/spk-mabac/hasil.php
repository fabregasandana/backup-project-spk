<?php
require __DIR__ . '/includes/helpers.php';

$page = 'hasil';
$judul = 'Hasil & Ranking';

$data = dataset();
$peringkat = $data ? $data['mabac']->peringkat() : [];
$juara = $peringkat[0] ?? null;

require __DIR__ . '/includes/header.php';
?>

<?php if (!$data): ?>
    <div class="kartu">
        <div class="kosong">
            <?= icon('alert-triangle', '', 44) ?>
            <p>Data belum lengkap. Hasil ranking muncul setelah semua relawan memiliki nilai pada setiap kriteria.</p>
            <br>
            <a class="tombol tombol-utama" href="<?= BASE_URL ?>/alternatif.php"><?= icon('users', '', 16) ?> Lengkapi Data</a>
        </div>
    </div>
<?php else: ?>
    <div class="kartu juara-kartu">
        <span class="juara-medali"><?= icon('award', '', 36) ?></span>
        <div>
            <h3><?= e($juara['alternatif']['nama']) ?> <small style="font-weight:600;color:var(--teks-tipis)">(<?= e($juara['alternatif']['kode']) ?>)</small></h3>
            <p>
                Direkomendasikan sebagai <strong>relawan inti</strong> program tanggap bencana dengan skor MABAC tertinggi
                <strong><?= fmt($juara['skor']) ?></strong>. Peringkat 1–<?= min(3, count($peringkat)) ?> selanjutnya dapat menjadi kandidat pendukung.
            </p>
        </div>
    </div>

    <div class="grid grid-2">
        <div class="kartu">
            <div class="kartu-judul">
                <div>
                    <h2><span class="ikon-bulat"><?= icon('trophy', '', 18) ?></span> Peringkat Akhir</h2>
                    <p>Diurutkan dari skor S tertinggi ke terendah.</p>
                </div>
            </div>
            <div class="tabel-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Relawan</th>
                            <th class="num">Skor (S)</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($peringkat as $item): ?>
                            <tr <?= $item['rank'] === 1 ? 'class="baris-menang"' : '' ?>>
                                <td><span class="badge-rank <?= $item['rank'] === 1 ? 'juara' : '' ?>"><?= $item['rank'] ?></span></td>
                                <td>
                                    <strong><?= e($item['alternatif']['nama']) ?></strong>
                                    <br><small style="color:var(--teks-tipis)"><?= e($item['alternatif']['kode']) ?><?= $item['alternatif']['alamat'] ? ' — ' . e($item['alternatif']['alamat']) : '' ?></small>
                                </td>
                                <td class="num"><?= fmt($item['skor']) ?></td>
                                <td>
                                    <?php if ($item['rank'] <= 3): ?>
                                        <span class="badge badge-benefit"><?= icon('check-circle', '', 13) ?> Relawan Inti</span>
                                    <?php else: ?>
                                        <span class="badge badge-cost"><?= icon('user-check', '', 13) ?> Kandidat Pendukung</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="kartu">
            <div class="kartu-judul">
                <div>
                    <h2><span class="ikon-bulat"><?= icon('bar-chart-3', '', 18) ?></span> Grafik Skor</h2>
                    <p>Perbandingan skor akhir MABAC seluruh relawan.</p>
                </div>
            </div>
            <?php
            $skor = array_column($peringkat, 'skor');
            $maks = max($skor);
            $min = min($skor);
            $rentang = ($maks - $min) ?: 1;
            ?>
            <div class="grafik">
                <?php foreach ($peringkat as $i => $item): ?>
                    <div class="grafik-baris <?= $i === 0 ? 'pertama' : '' ?>">
                        <strong><?= e($item['alternatif']['nama']) ?></strong>
                        <div class="grafik-lajur">
                            <div class="grafik-isi" data-lebar="<?= round(($item['skor'] - $min) / $rentang * 100) ?>"></div>
                        </div>
                        <span class="grafik-skor"><?= fmt($item['skor'], 3) ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
            <br>
            <a class="tombol tombol-utama" href="<?= BASE_URL ?>/perhitungan.php">
                <?= icon('calculator', '', 16) ?> Telusuri Perhitungan
            </a>
        </div>
    </div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
