        </main>

        <footer class="footer">
            <p>SPK Pemilihan Relawan Inti — Program Tanggap Bencana Organisasi Sosial &copy; <?= date('Y') ?></p>
        </footer>
    </div>

    <script>
        window.APP = {
            flash: <?= json_encode($flash) ?>,
        };
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?= BASE_URL ?>/assets/js/app.js"></script>
    <?= $skripHalaman ?? '' ?>
</body>

</html>
