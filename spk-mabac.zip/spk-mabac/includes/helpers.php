<?php

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../src/Mabac.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!defined('BASE_URL')) {
    define('BASE_URL', rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/'));
}

function e(?string $teks): string
{
    return htmlspecialchars((string) $teks, ENT_QUOTES, 'UTF-8');
}

function icon(string $nama, string $class = '', int $ukuran = 20): string
{
    static $manager = null;

    $alias = [
        'alert-triangle' => 'triangle-alert',
        'plus-circle' => 'circle-plus',
        'bar-chart-3' => 'chart-column',
        'check-circle' => 'circle-check-big',
    ];
    $nama = $alias[$nama] ?? $nama;

    if ($manager === null) {
        $manager = new \Lucide\IconManager();
        $manager->setAttribute('stroke-width', '2');
    }

    $ikon = $manager->getIcon($nama)->setSize($ukuran);
    if ($class !== '') {
        $ikon->addCssClass($class);
    }

    return $ikon->render();
}

function flash(string $type, string $pesan): void
{
    $_SESSION['flash'] = ['type' => $type, 'pesan' => $pesan];
}

function ambil_flash(): ?array
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);

    return $flash;
}

function fmt(float $nilai, int $desimal = 4): string
{
    return rtrim(rtrim(number_format($nilai, $desimal, '.', ''), '0'), '.') ?: '0';
}

function semua_kriteria(): array
{
    return db()->query('SELECT * FROM kriteria ORDER BY kode')->fetchAll();
}

function semua_alternatif(): array
{
    return db()->query('SELECT * FROM alternatif ORDER BY kode')->fetchAll();
}

function semua_penilaian(): array
{
    return db()
        ->query('SELECT alternatif_id, kriteria_id, nilai FROM penilaian')
        ->fetchAll();
}

function wajib_login(): void
{
    if (empty($_SESSION['pengguna_id'])) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function dataset(): ?array
{
    $kriteria = semua_kriteria();
    $alternatif = semua_alternatif();
    $penilaian = semua_penilaian();

    if (!$kriteria || !$alternatif) {
        return null;
    }

    $nilai = [];
    foreach ($penilaian as $p) {
        $nilai[$p['alternatif_id']][$p['kriteria_id']] = (float) $p['nilai'];
    }

    $indexKriteria = array_column($kriteria, 'id');
    $matrix = [];
    foreach ($alternatif as $a) {
        $baris = [];
        foreach ($indexKriteria as $idKriteria) {
            if (!isset($nilai[$a['id']][$idKriteria])) {
                return null;
            }
            $baris[] = $nilai[$a['id']][$idKriteria];
        }
        $matrix[] = $baris;
    }

    return [
        'mabac' => new Mabac($kriteria, $alternatif, $matrix),
        'kriteria' => $kriteria,
        'alternatif' => $alternatif,
        'matrix' => $matrix,
    ];
}

// Semua halaman wajib login kecuali yang mendefinisikan BEBAS_LOGIN sebelum memuat file ini.
if (!defined('BEBAS_LOGIN')) {
    wajib_login();
}
