<?php
$page = $page ?? 'dashboard';
$judul = $judul ?? 'Dashboard';
$flash = ambil_flash();

$menu = [
    'dashboard' => ['label' => 'Dashboard', 'ikon' => 'layout-dashboard', 'url' => 'index.php'],
    'kriteria' => ['label' => 'Kriteria', 'ikon' => 'list-checks', 'url' => 'kriteria.php'],
    'alternatif' => ['label' => 'Relawan & Penilaian', 'ikon' => 'users', 'url' => 'alternatif.php'],
    'perhitungan' => ['label' => 'Perhitungan MABAC', 'ikon' => 'calculator', 'url' => 'perhitungan.php'],
    'hasil' => ['label' => 'Hasil & Ranking', 'ikon' => 'trophy', 'url' => 'hasil.php'],
    'laporan' => ['label' => 'Laporan', 'ikon' => 'printer', 'url' => 'laporan.php'],
];
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($judul) ?> — SPK Relawan Bencana</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>

<body>
    <div class="blob blob-teal"></div>
    <div class="blob blob-coral"></div>

    <aside class="sidebar" id="sidebar">
        <div class="brand">
            <span class="brand-ikon"><?= icon('life-buoy', '', 24) ?></span>
            <div>
                <strong>RelawanTanggap</strong>
                <small>SPK MABAC</small>
            </div>
        </div>
        <nav class="menu">
            <?php foreach ($menu as $key => $item): ?>
                <a href="<?= BASE_URL ?>/<?= $item['url'] ?>" class="menu-item <?= $page === $key ? 'aktif' : '' ?>">
                    <?= icon($item['ikon'], '', 18) ?>
                    <span><?= $item['label'] ?></span>
                </a>
            <?php endforeach; ?>
        </nav>
        <div class="sidebar-pengguna">
            <span class="pengguna-avatar"><?= icon('user-round', '', 16) ?></span>
            <div>
                <strong><?= e($_SESSION['pengguna_nama'] ?? 'Pengguna') ?></strong>
                <a href="<?= BASE_URL ?>/logout.php"><?= icon('log-out', '', 14) ?> Keluar</a>
            </div>
        </div>
        <div class="sidebar-catatan">
            <?= icon('heart-handshake', '', 18) ?>
            <p>Pemilihan relawan inti untuk program tanggap bencana organisasi sosial.</p>
        </div>
    </aside>
    <div class="overlay" id="overlay"></div>

    <div class="wrapper">
        <header class="topbar">
            <button class="tombol-ikon" id="tombolMenu" aria-label="Buka menu"><?= icon('menu', '', 22) ?></button>
            <div>
                <h1><?= e($judul) ?></h1>
                <p>Metode MABAC — Multi-Attributive Borderline Area Comparison</p>
            </div>
        </header>

        <main>
